# Dati, misure e rapporto

## Registro minimo

Usare una tabella per profilo: handle/link, ruolo nel confronto, pubblico, lingua, follower osservati e data, periodo analizzato, numero di Reel realmente osservati, accesso completo/parziale, fonte.

Usare una tabella per Reel quando sono disponibili dati: link o file, data pubblicazione, data rilevazione, età, tema, formato, durata, gancio osservato, CTA, visualizzazioni, reach, like, commenti, salvataggi, condivisioni, follow attribuiti e note su sponsorizzazione/collaborazione. Conservare N/D per ogni dato assente. Non richiedere tutti i campi per un'analisi qualitativa.

## Formule e limiti

| Misura | Calcolo | Limite |
| --- | --- | --- |
| Reel/settimana osservati | totale Reel nel periodo / giorni del periodo × 7 | Solo con elenco completo del periodo |
| Interazioni pubbliche/follower | (like + commenti) / follower osservati × 100 | Proxy descrittivo; follower attuali, like nascosti => N/D |
| Interazioni/reach | somma delle interazioni disponibili / reach × 100 | Specificare quali azioni sono comprese; usare la stessa definizione nei confronti |
| Visualizzazioni/follower | visualizzazioni / follower osservati | Non reach, non probabilità di conversione; possibili ripetizioni |
| Salvataggi o condivisioni/reach | singola azione / reach × 100 | Insights richiesti; denominatore uguale per confrontare |
| Follow attribuiti/reach | follow attribuiti al Reel / reach × 100 | Solo se attribuzione disponibile; non variazione totale follower |
| Tempo medio/durata | tempo medio di visione / durata × 100 | Rapporto descrittivo; possibili replay, non tasso completamento |
| Conversione visita-follow | follow attribuibili / visite profilo coerentemente attribuite × 100 | Se disponibili soltanto totali periodo, segnalarli come proxy aggregato |

Non dividere per zero: restituire N/D e motivo. Riportare mediana, numerosità e dispersione semplice quando utile. Non mescolare play, views, account raggiunti e impression. Non annualizzare campioni limitati. Verificare definizioni metriche attuali sulle fonti ufficiali se servono all'interpretazione.

Per un account nuovo senza baseline proporre una prima raccolta dati; evitare percentuali di crescita da zero. Per un campione minuscolo o disomogeneo mantenere conclusioni esplorative. Distinguere frequenza di pubblicazione e orario: la prima non dimostra il secondo.

## Struttura del rapporto

1. **Decisioni immediate:** tre modifiche, frequenza proposta, obiettivo e copertura reale.
2. **Evidenze:** fonti, periodo, profili, campione e limiti; evitare il muro di disclaimer.
3. **Confronto:** tabella profilo proprio/competitor su posizionamento, bio, contenuti, format e metriche comparabili disponibili.
4. **Modifiche prioritarie:** situazione verificata, proposta concreta, evidenza, priorità, sforzo, controllo; distinguere ipotesi.
5. **Profilo pronto da aggiornare:** campo nome, tre bio, CTA/link, tre post fissati, storie in evidenza.
6. **Differenziazione:** tre-cinque opportunità e motivazione riferita alla nicchia.
7. **Piano di 30 giorni:** frequenza, calcolo capacità e calendario Reel con i campi richiesti in SKILL.md. Dividere per settimane se la tabella diventa illeggibile; mettere script e caption sotto le rispettive voci.
8. **Primi tre Reel:** script completi, ganci alternativi, riprese e stima produzione. Evitare duplicazione integrale col calendario.
9. **Misurazione:** baseline, indicatori, due esperimenti al massimo per ciclo e decisioni al giorno 14/30.
10. **Prossimo passo:** un'azione eseguibile subito o i soli dati ancora necessari.

Se non è leggibile alcun contenuto dei profili, consegnare solo raccolta input e, se utile, una bozza esplicitamente ipotetica. Non riempire il confronto con conclusioni non osservate.
