---
name: sbobina-audio-video
description: Trascrivere audio e video caricati, soprattutto MP3 e MP4, con FFmpeg e faster-whisper. Usare per sbobinare il parlato, creare trascrizioni con tempi o sottotitoli e, su richiesta, riassumere o riscrivere in tono ironico, naturale e social.
---

# Sbobina Audio e Video

## Procedura

1. Individuare il percorso reale del file caricato nel workspace. Non chiedere all'utente di trascriverlo. Per file esterni usare il connettore pertinente. Per URL recuperare solo contenuti accessibili e autorizzati, senza aggirare login o restrizioni.
2. Controllare FFmpeg e FFprobe e gli import Python `numpy`, `faster_whisper`. Usare l'interprete disponibile nell'ambiente corrente, senza presumere percorsi di vecchie sessioni. Se necessario installare con lo stesso interprete `python -m pip install faster-whisper socksio`. Il pacchetto socksio risolve l'errore HTTPX con proxy SOCKS. Rispettare proxy, certificati e policy di rete; non esporre credenziali.
3. Eseguire `python <skill_dir>/scripts/transcribe_media.py <file> --output-dir <temporary_output_dir> --language it`. Omettere language per rilevamento automatico. Usare small su CPU int8 come default. Per passaggi difficili usare medium se possibile; usare base se le risorse sono insufficienti, dichiarando il compromesso.
4. Attendere download e riconoscimento aggiornando l'utente sui progressi effettivi. Non confondere un'operazione in corso con un fallimento. Leggere gli errori prima di scegliere il rimedio.
5. Leggere la trascrizione completa e confrontare la copertura con la durata del file. Verificare segmenti mancanti, ripetizioni e silenzi. Riesaminare i punti dubbi con start/duration e, se utile, un modello migliore. Non dichiarare completo un intervallo parziale.

## Strategia collaudata

- Convertire con FFmpeg in PCM mono float32 a 16 kHz e passare direttamente un array NumPy a Whisper. Evitare la decodifica interna PyAV: alcune versioni producono l'errore `open() got an unexpected keyword argument 'metadata_errors'`.
- Usare CPU, int8, beam_size 5, VAD attivo. Se il VAD esclude parlato riprovare il tratto con `--no-vad`.
- Elaborare file lunghi in blocchi limitati, aggiungendo gli offset ai timestamp. Lo script salva checkpoint JSON per blocco e risultati TXT/SRT temporanei al completamento. Non riprende automaticamente un lavoro interrotto: leggere il checkpoint e usare --start con una directory diversa, poi unire i risultati senza duplicare i tempi. La completezza del processo non garantisce che il VAD abbia riconosciuto tutto il parlato. Ai confini dei blocchi una parola può essere interrotta: riesaminare un intervallo che attraversi il confine quando necessario.
- Conservare lingua originale e distinguere i parlanti solo quando possibile. Non identificare persone dalla voce. Non dedurre il contenuto dal nome del file.
- Il primo utilizzo richiede accesso ai modelli; l'installazione della skill non rende disponibili strumenti o modelli in ogni ambiente. Non promettere qualsiasi file senza limiti: rumore, musica, voci sovrapposte, dialetti, corruzione del file e limiti delle risorse possono ridurre l'accuratezza.

## Consegna

Fornire la trascrizione fedele con punteggiatura leggibile. Conservare significato, attribuzioni, negazioni e incertezze. Segnalare `[incomprensibile]` con tempo quando necessario. Non inventare parole e non dichiarare verifica parola per parola dall'ascolto se si dispone solo di ASR.

Se richiesta una riscrittura, presentarla separatamente: testo condensato e naturale, gancio concreto, ironia pertinente, eventuale domanda autentica. Non aggiungere fatti, accuse o citazioni inesistenti; attribuire le opinioni del parlante. Non promettere viralità.

Per trascrizioni lunghe salvare il risultato completo secondo le regole di archiviazione attive e sintetizzare in chat. Esportare sottotitoli o altri formati solo su richiesta; mantenere temporanei gli intermedi. Non fermarsi al primo errore di formato o dipendenze. Se le alternative disponibili falliscono, spiegare il limite concreto e chiedere solo l'elemento necessario a proseguire.
