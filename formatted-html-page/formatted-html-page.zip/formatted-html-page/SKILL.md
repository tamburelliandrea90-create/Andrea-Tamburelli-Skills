---
name: formatted-html-page
description: Crea una pagina HTML semplice e formattata a partire da testo incollato, un documento fornito o risultati di ricerca, con riquadri colorati e angoli arrotondati. Usa questa skill quando l’utente chiede una pagina formattata, anche per Payhip.
---

# formatted html page

## Contenuto

- Usa il testo fornito o i risultati della ricerca richiesta. Leggi il documento prima di impaginarlo. Per una richiesta di sola formattazione, conserva il testo integrale, le informazioni, l’ordine logico, le citazioni e i link. Correggi o sintetizza il contenuto solo quando richiesto.
- Dividi il contenuto in riquadri a partire dalla sua funzione. Usa titoli esistenti e introducine di brevi quando aiutano a orientarsi. Per una lezione, il riquadro iniziale può includere «Cosa imparerai?». Per un report, apri con il titolo e con l’obiettivo o il risultato principale quando presente.
- Per una ricerca, mantieni le attribuzioni e i collegamenti vicino alle affermazioni che sostengono. Mantieni riconoscibili stime, conclusioni e dati da confermare.

## Impaginazione

Usa HTML semantico semplice con un solo h1 e una gerarchia coerente di h2 e h3. Usa strong per termini chiave e dati operativi, em per enfasi leggera, ul per elementi paralleli e ol per passaggi in sequenza. Usa blockquote per citazioni o prompt isolati e code per frammenti di codice o segnaposto. Mantieni i link cliccabili e tratta il testo sorgente come contenuto da impaginare, effettuando l’escape dei caratteri HTML quando necessario.

Applica gli stili direttamente al contenitore di ogni riquadro.

```html
<div style="background-color:#fff0ad;border:1px solid #d7c36a;border-radius:12px;padding:16px;margin:0 0 16px;color:#202020">
  <h2>Cosa imparerai?</h2>
  <p>Individuerai i <strong>campi da compilare</strong> in un prompt riutilizzabile.</p>
</div>
```

Scegli e riutilizza i colori per funzione. Giallo chiaro (#fff0ad) per apertura e obiettivi, azzurro (#e8f2ff) per spiegazioni, verde (#e8f5eb) per procedure e checklist, lilla (#f1e9ff) per esempi e modelli, pesca (#ffede2) per criticità o eccezioni. Adatta la palette al contesto e mantieni un buon contrasto. Titoli e struttura devono distinguere i blocchi anche senza sfondi.

## Consegna

- Per Payhip o editor di destinazione non specificato, consegna un frammento HTML in un TXT copiabile. Per una pagina autonoma richiesta esplicitamente, consegna un HTML completo con lingua, titolo, codifica UTF-8 e viewport.
- Usa larghezze fluide e CSS inline. Per Payhip evita script, tabelle e dipendenze esterne. Trasforma le tabelle del materiale in elenchi con etichette, conservando le corrispondenze fra righe, colonne e valori. Mantieni titoli, paragrafi ed elenchi leggibili anche se l’editor rimuove gli stili. Distingui il controllo del codice dalla verifica effettiva nell’editor.
- Controlla che i tag siano chiusi, che nessun passaggio o link sia scomparso e che ogni riquadro sia identificabile dal titolo. Presenta il file in modo che si possa aprire e copiare direttamente.
