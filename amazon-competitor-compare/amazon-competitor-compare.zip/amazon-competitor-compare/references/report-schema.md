# Schema del rapporto

Adattare lunghezza e dettaglio alle prove. Evitare tabelle piene di valutazioni non sostenute.

## Verdetto commerciale

Aprire con dove il concorrente appare più convincente, dove l'utente ha vantaggi dimostrabili e quale opportunità testare. Dare un verdetto provvisorio se le prove non bastano. Riportare input, variante/edizione e copertura effettiva di PDF, anteprime e recensioni.

## Matrice di confronto

| Area | Tuo prodotto: prova | Concorrente: prova | Pro/contro e implicazione per l'acquirente | Stato/confidenza |
|---|---|---|---|---|

Usare una riga per differenza significativa. Citare pagine PDF e fonti vicino alle prove. Includere, secondo i materiali, target, problema, promessa, contenuti, facilità d'uso, differenziazione, cover, immagini, descrizione, prezzo/valore e recensioni. Separare parità e non valutabile dai vantaggi. Non equiparare accesso all'intero PDF dell'utente e al solo titolo altrui.

## Voce del cliente

| Bisogno o obiezione | Evidenza nel campione | Cosa offre/comunica il concorrente | Opportunità verificabile per te |
|---|---|---|---|

Senza recensioni disponibili, dichiararlo e omettere la tabella. Non inventare recensioni tipiche. Separare eventuali ipotesi da approfondire.

## Modifiche prioritarie

| Priorità | Modifica concreta | Prova o problema | Risultato da verificare | Impatto ipotizzato | Confidenza | Sforzo | Test |
|---|---|---|---|---|---|---|---|

Dare prima tre interventi, poi altri se sostenuti. Indicare dipendenze e distinguere prodotto e scheda. Specificare cosa conservare.

## Posizionamento e bozze

Formulare: «Per [lettore/bisogno], [prodotto] offre [beneficio], grazie a [caratteristica/prova presente]». Proporre, quando utile, titolo/sottotitolo, prime righe della descrizione e brief visivo. Non aggiungere bonus, risultati o caratteristiche inesistenti; etichettare eventuali sviluppi come da realizzare.

## Piano e limiti

Indicare azioni a 7 e 30 giorni, metrica e criterio di decisione per ogni test. Dichiarare dati mancanti, effetto sul verdetto e come ottenerli. Chiudere con una prossima azione, senza garanzie di vendite.
