# Ricerca, teoria e misurazione

## Riferimenti di base

Usare questi riferimenti storici come orientamento e attribuzione, non dichiarare di averli consultati in una nuova esecuzione se non sono stati aperti. Le applicazioni al caso dell'utente sono proposte editoriali, non effetti scientificamente garantiti.

- Jonah Berger e Katherine L. Milkman (2012), What Makes Online Content Viral?, Journal of Marketing Research. Emozioni, attivazione e condivisione in articoli del New York Times ed esperimenti; non un algoritmo per ogni social. https://doi.org/10.1509/jmr.10.0353
- Jonah Berger, quadro STEPPS, blog dell'autore; è anche una fonte promozionale del suo libro. Social Currency, Triggers, Emotion, Public, Practical Value, Stories. https://jonahberger.com/virals-secret-formula/
- Sharad Goel, Ashton Anderson, Jake Hofman, Duncan J. Watts (2016, online 2015), The Structural Virality of Online Diffusion, Management Science. Distinguere popolarità da struttura della diffusione. https://www.microsoft.com/en-us/research/publication/the-structural-virality-of-online-diffusion/
- Matthew J. Salganik, Peter Sheridan Dodds, Duncan J. Watts (2006), Experimental Study of Inequality and Unpredictability in an Artificial Cultural Market, Science. Influenza sociale e imprevedibilità nell'esperimento Music Lab. https://pubmed.ncbi.nlm.nih.gov/16469928/
- Damon Centola e Michael Macy (2007), Complex Contagions and the Weakness of Long Ties, American Journal of Sociology. Modelli di adozione con rinforzo da più fonti; effetti dipendenti dalle condizioni della rete. https://ics.uci.edu/~projects/dissemination/papers/centola.macy.2007-ajs.pdf
- Steve Rathje e Jay J. Van Bavel (2025), The psychology of virality, Trends in Cognitive Sciences. Interazione tra psicologia e strutture; diffusione e gradimento distinti; limiti della letteratura anglofona occidentale. https://pubmed.ncbi.nlm.nih.gov/40675888/
- Emanuele Sangiorgio et al. (2025), Evaluating the effect of viral posts on social media engagement, Scientific Reports. Picchi e crescita nel contesto di testate europee su Facebook e YouTube; non una misurazione delle vendite KDP. https://pubmed.ncbi.nlm.nih.gov/39753870/
- Henry Jenkins, Sam Ford e Joshua Green, Spreadable Media, estratto USC. Partecipazione, riformulazione e motivazioni del pubblico. https://annenberg.usc.edu/news/published/defining-spreadability
- Gabriele Marino (2022), Semiotics of virality, Signata. Distinguere diffusione dell'originale e generazione di varianti. https://journals.openedition.org/signata/3936

## Scheda delle evidenze

Per ogni fonte essenziale riportare, quando utile, titolo/autore, URL, data nota o non confermata, tipo di evidenza, popolazione/piattaforma, risultato e limite. Non confondere causalità sperimentale e associazione osservata. Non presentare una sintesi editoriale come ricerca primaria.

Per i post di riferimento registrare metriche e data di rilevazione solo se effettivamente visibili. Considerare selezione dei soli vincitori, mancanza del denominatore, differenze tra pubblici e confondenti. Senza un campione adeguato descrivere esempi, non percentuali universali. Reddit può rivelare lessico e bisogni, ma numeri e credenziali dichiarati dagli utenti richiedono verifica.

## Un test interpretabile

Formulare: «Se cambiamo X mantenendo il resto il più possibile comparabile, ci aspettiamo Y nella metrica Z, perché…».

- Scegliere una sola variabile principale: ad esempio apertura diretta contro apertura con esempio. Mostrare le due formulazioni effettive di quella parte per rendere il test eseguibile.
- Definire metrica primaria coerente con l'obiettivo e realmente disponibile, condizioni di confronto, finestra proposta e base storica quando esiste. Non presentare una finestra proposta come legge di piattaforma.
- Per diffusione considerare condivisioni rispetto a copertura o visualizzazioni, dichiarando il denominatore e se si contano eventi o persone uniche. Il tasso eventi/copertura non è automaticamente la probabilità individuale di condividere.
- Per lettura o visione usare soltanto segnali disponibili: durata e completamento video, ad esempio, quando presenti. Like e commenti non misurano la lettura completa di un post testuale.
- Per contatti e vendite usare dati effettivamente tracciabili; non presumere attribuzione causale da semplici coincidenze temporali.
- Confrontare periodi ed esposizioni per quanto possibile; chiamare indicativo un confronto organico non randomizzato. Non usare due pubblicazioni in momenti diversi come prova causale certa.
- Non proclamare un vincitore con pochi dati, denominatori mancanti o oscillazioni minime. Dichiarare «risultato inconcludente» e specificare la lacuna.

## Apertura, lettura, comprensione e memoria

Distinguere le metriche per fase. Per video, se si usa «thumbstop rate», dichiarare la convenzione e verificare lo strumento: spesso visualizzazioni di almeno 3 secondi / impression × 100. Non usarla per post statici. Né like, né commenti, né clic su «altro» dimostrano lettura integrale. Per comprensione proporre una parafrasi; per memoria un richiamo dopo un intervallo dichiarato. Non presentare questi controlli come eseguiti senza averli svolti.

Dichiarare metrica primaria, denominatore, finestra e criterio decisionale prima del confronto. Non confondere aumento dei clic con qualità delle visite o vendite. Consultare [fonti-attenzione.md](fonti-attenzione.md) per gli studi e i limiti del modulo.

## Registro di apprendimento

Restituire, quando l'utente porta risultati, una scheda con: contenuto/variante, contesto e periodo, metrica e denominatore, osservazione, spiegazioni alternative, decisione e prossimo test. Salvare soltanto con strumenti disponibili e autorizzati; non promettere memoria permanente. Non trasformare una singola osservazione in una regola universale.
