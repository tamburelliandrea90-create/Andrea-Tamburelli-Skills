# Fonti del modulo attenzione e leggibilità

Base di ricerca consultata il 7 novembre 2026. Non presentare come ricerca appena svolta le letture precedenti. Verificare aggiornamenti solo quando necessari al compito.

## Come interpretare le evidenze

- Berger, Moe e Schweidel: facilitazione della lettura e tenuta dell’attenzione; cattura e condivisione restano obiettivi distinti.
- Aubin Le Quéré e Matias: 8.977 esperimenti sui titoli, relazione dipendente dalla concretezza di partenza; nessuna soglia universale di parole.
- Fang e Wheeler: risultati sfavorevoli ai titoli interrogativi nei contesti esaminati; letto l’abstract, non il testo completo.
- NN/g: usabilità e scansione di pagine web, non prova di conversione sui social.
- Google e TikTok: raccomandazioni ufficiali per pubblicità video, non regole dimostrate per post statici.
- Heath e StoryBrand: modelli professionali, non garanzie.
- Reddit: fonti di ipotesi e lessico, credenziali e percentuali degli autori non verificate.
- Governo australiano e OMS: chiarezza comunicativa; non esperimenti di viralità.
- Ricerca selettiva prevalentemente anglofona, con fonte in portoghese. Nature ha avuto limiti di accesso; recuperati risultati indicizzati e record PMC/PubMed. Nessuna replica dei dati né conteggio verificato delle citazioni scientifiche.
- Sintesi 50/25 parole, sound bite 6–16, testo immagine 3–8 e frasi 12–20 sono euristiche editoriali del prompt, adattabili. Non attribuirle a una validazione universale.

## Bibliografia


Tutti gli URL consultati il 7 novembre 2026. I riferimenti con data incerta sono marcati s.d.

[Journal-of-Marketing, 2023/01] Jonah Berger, Wendy W. Moe, David A. Schweidel. “What Holds Attention? Linguistic Drivers of Engagement.” Journal of Marketing, 87(5), 793–809. https://journals.sagepub.com/doi/10.1177/00222429231152880

[Wharton, 2024] Wharton Magazine, intervista con Jonah Berger. “Catching Eyes in the Attention Economy.” University of Pennsylvania. https://magazine.wharton.upenn.edu/issues/spring-summer-2024/catching-eyes-in-the-attention-economy/

[Scientific-Reports, 2025/01] Marianne Aubin Le Quéré, J. Nathan Matias. “When curiosity gaps backfire: effects of headline concreteness on information selection decisions.” Scientific Reports 15, 994. https://www.nature.com/articles/s41598-024-81575-9 — testo alternativo: https://pmc.ncbi.nlm.nih.gov/articles/PMC11704130/ — record: https://pubmed.ncbi.nlm.nih.gov/39762307/

[Journal-of-Consumer-Psychology, 2026/07] David Fang, S. Christian Wheeler. “Titles framed as questions reduce reader engagement.” Journal of Consumer Psychology 36(4), 470–481. https://myscp.onlinelibrary.wiley.com/doi/10.1002/jcpy.70031

[TikTok-Codes, s.d.] TikTok for Business, fonte aziendale. “TikTok Creative Codes: 6 Principles for Creating Effective Ads.” https://ads.tiktok.com/business/en-US/creative-codes

[Google-ABCD, s.d.] Google Ads Help, fonte aziendale. “About the ABCDs of effective video ads.” https://support.google.com/google-ads/answer/14783551?hl=en

[Motion-Runneth, s.d.] Motion/Runneth, glossario professionale di un fornitore. “What is Thumbstop rate / hook rate?” https://runneth.com/library/glossary/thumbstop-rate-hook-rate — URL iniziale: https://motionapp.com/library/glossary/thumbstop-rate-hook-rate

[Hawaii-OER, 2015] “Business Writing for Success”, §23.1 “Sound Bites and Quotables”; pagina didattica ospitata su University of Hawaiʻi, copyright attribuito a University of Minnesota. Autore individuale della sezione non confermato. https://pressbooks-dev.oer.hawaii.edu/cmchang/chapter/15-1-sound-bites-and-quotables/

[Heath, 2008] Chip Heath e Dan Heath, autori di Made to Stick. “Made to Stick: SUCCESs Model.” Scheda originale degli autori. https://heathbrothers.com/wp-content/uploads/resources/mts-made-to-stick-model.pdf

[StoryBrand, s.d.] StoryBrand, organizzazione commerciale di formazione marketing. Post aziendale sui cinque sound bite. https://www.linkedin.com/posts/storybrand_the-only-reason-anyone-purchases-anything-activity-7404314022671544320-CggQ

[NNG-Lettura, 1997/09] Jakob Nielsen, specialista di usabilità, Nielsen Norman Group. “How Users Read on the Web.” https://www.nngroup.com/articles/how-users-read-on-the-web/

[NNG-LayerCake, 2019/08] Kara Pernice, professionista della ricerca UX, Nielsen Norman Group. “The Layer-Cake Pattern of Scanning Content on the Web.” https://www.nngroup.com/articles/layer-cake-pattern-scanning/

[NNG-LongForm, 2023/11] Huei-Hsin Wang e Megan Chan, professioniste UX, Nielsen Norman Group. “5 Formatting Techniques for Long-Form Content.” https://www.nngroup.com/articles/formatting-long-form-content/

[Australia, s.d.] Australian Government Style Manual. “Quick guide: plain language.” Fonte istituzionale. https://www.stylemanual.gov.au/style-manual-resources/quick-guides/quick-guide-plain-language

[WHO, s.d.] World Health Organization. “Use plain language.” Fonte istituzionale. https://www.who.int/about/communications/understandable/plain-language

[RD-Station, s.d.] RD Station, organizzazione commerciale di marketing. “Aprenda o passo a passo para escrever conteúdo para SEO.” Lingua: portoghese. https://www.rdstation.com/blog/marketing/como-escrever-um-artigo-para-seo/

[Reddit-AdCopy, 2025/06] Autore indicato come [deleted], identità e affiliazione non verificate. “What I’ve Learned Writing Ad Copy.” r/copywriting, 16 giugno 2025. https://www.reddit.com/r/copywriting/comments/1lcmx6o/what_ive_learned_writing_ad_copy/

[Reddit-Hooks, 2026/01] u/Shani_9, identità e affiliazione non verificate; promuove uno strumento AI nel post. “I analyzed 1000+ viral hooks and found some patterns not enough people talk about.” r/copywriting, 14 gennaio 2026. https://www.reddit.com/r/copywriting/comments/1qcphbm/i_analyzed_1000_viral_hooks_and_found_some/
