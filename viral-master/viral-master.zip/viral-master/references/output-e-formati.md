# Output e adattamento ai formati

## Consegna normale: unire ideazione, attenzione e leggibilità

Usare sezioni brevi e parallele; tenere il post pronto da copiare separato dalle spiegazioni.

1. **Direzione ed evidenze**: obiettivo, destinatario e motivo della condivisione; soltanto evidenze pertinenti e limiti reali. Non etichettare ipotesi come dati.
2. **Tre concetti**: tre alternative compatte, con pubblico/messaggio, motivo di condivisione, prova, formato, rischio e obiettivo. Indicare il concetto scelto con una breve motivazione.
3. **Sintesi e sound bite**: una sintesi entro 50 parole, una entro 25 e tre frasi autonome indicativamente di 6–16 parole per il concetto scelto. Non falsificare per rispettare la lunghezza.
4. **Sei ganci**: sei aperture per il solo concetto scelto; per ognuna indicare lettore, promessa, prova e rischio in forma compatta. Indicare quella scelta e il motivo.
5. **Contenuto finale**: un solo post completo o l'intero formato richiesto, incorporando il gancio scelto. Nessun commento tecnico al suo interno. Non scrivere tre post completi salvo richiesta.
6. **Brief visivo**, soltanto se pertinente o richiesto: per immagine punto focale e messaggio breve; per video prima inquadratura, frase, testo a schermo e funzione audio. Non fingere di avere generato il file.
7. **Distribuzione e seguito**: proposta breve e pertinente, mai affermazioni di azioni eseguite.
8. **Un test**: singola variabile, due versioni distinguibili dell'elemento, ipotesi, metrica disponibile, finestra proposta e limiti interpretativi.
9. **Note e fonti**, solo quando necessarie: assunzioni, fatti da confermare, limiti di accesso e fonti effettivamente consultate. Non inventare una bibliografia o una ricerca per riempire la sezione.

La lunghezza dell'analisi deve restare proporzionata alla richiesta. Non mostrare il brief intero come questionario né ripetere principi teorici se non richiesti.

## SOLO POST e SOLO CONTENUTO

Trattare le due espressioni come equivalenti, anche minuscole o inserite nella frase. Dare soltanto il contenuto finale pronto da usare; omettere concetti, sintesi, sound bite separati, ganci alternativi, motivazioni, test, distribuzione, titoli di servizio e note. Continuare ad applicare tutti i controlli.

Per un carosello consegnare le slide richieste e l'eventuale caption richiesta. Per un Reel/TikTok consegnare il copione ed eventuale caption richiesti: le etichette utili a usare quel formato fanno parte del contenuto. Non aggiungere un post testuale diverso. Rispettare «solo caption», «solo copione» o altri vincoli più precisi.

Non premettere «Ecco il post». Non inserire elementi Markdown che la piattaforma di destinazione non supporta se non richiesti. Se un dato mancante è indispensabile o un fatto non verificato non può essere omesso, chiedere il chiarimento essenziale prima della consegna, anziché aggiungere avvertenze dentro il post.

## Criteri per formato, non leggi degli algoritmi

| Formato | Criterio editoriale |
| --- | --- |
| Facebook | Conversazione leggibile, sviluppo completo quanto serve, paragrafi naturali. |
| LinkedIn | Rilevanza professionale, osservazioni motivate, esempi concreti. |
| Instagram caption | Coordinamento con visual e contesto sufficiente per capire il contenuto. |
| Carosello | Una funzione per slide e avanzamento reale; rispettare il numero richiesto. |
| X / Threads | Idea concentrata; sequenza soltanto quando necessaria e compatibile con i limiti verificati. |
| Reel / TikTok | Testo pronunciabile, apertura parlata, sviluppo e indicazioni visive essenziali; distinguere caption e copione. |

Rispettare prima i vincoli espliciti di lunghezza. Non imporre una lunghezza ottimale universale. Verificare limiti tecnici correnti e tipo di account quando incidono sull'output. Non convertire silenziosamente il formato richiesto.

## Richieste mirate

Per «solo sintesi», «solo sound bite», «solo hook» o una quantità esplicita, rispettare la richiesta senza imporre la consegna completa. In SOLO POST il sound bite scelto può far parte del testo finale, ma non aggiungere un elenco di lavoro. Il brief visivo non fa parte di SOLO POST salvo che l’utente richieda anche il visual.
