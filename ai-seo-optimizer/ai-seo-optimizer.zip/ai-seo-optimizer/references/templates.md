# Modelli di output

## Audit SEO web
- Piattaforma, pubblico, mercato e obiettivo.
- Diagnosi con evidenze e limiti della verifica.
- Intento e keyword primaria/secondarie: dati verificati oppure ipotesi.
- Titolo SEO, H1, slug, meta description e scaletta H2/H3.
- Testo ottimizzato, link interni suggeriti e alt text se le immagini sono disponibili.
- Tre azioni prioritarie, changelog e metriche di verifica.

## Scheda Amazon KDP
- Dati confermati del libro e informazioni mancanti.
- Lettore e intento di acquisto.
- Titolo e sottotitolo coerenti con i metadati reali.
- Descrizione pronta da usare; HTML solo dopo verifica delle regole correnti.
- Fino a sette frasi keyword candidate, distinte dal targeting Ads.
- Checklist di coerenza e tre azioni prioritarie.

## Contenuto per ricerca AI
- Domanda principale e risposta diretta.
- Definizioni, esempi e fonti verificabili quando disponibili.
- Struttura proposta e testo ottimizzato.
- Eventuali dati strutturati veritieri e conformi alle linee guida verificate.
- Limiti, priorità e piano di misurazione senza garanzie di citazione.
