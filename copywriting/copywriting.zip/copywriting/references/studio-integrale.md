# Copywriting: come progettare testi e post che aiutino a vendere

**Studio per Andrea Tamburelli — 11 novembre 2026**

**Oggetto:** paradigmi della scrittura persuasiva, evidenze, strutture professionali, lessico italiano, sinonimi, post di vendita e verifica dei risultati.

**Perimetro:** ricerca internazionale mirata su articoli accademici, siti universitari, guide originali, PDF, fonti linguistiche italiane e discussioni Reddit. Non è un censimento di tutte le risorse mondiali né una revisione sistematica esaustiva. Le fonti metodologiche e i risultati empirici sono separati dalle proposte operative di questo studio.

## Indice

- [1. Che cosa significa rendere vendibile un testo](#1-che-cosa-significa-rendere-vendibile-un-testo)
  - [1.1 Una definizione operativa](#11-una-definizione-operativa)
  - [1.2 Standard, modelli e risultati](#12-standard-modelli-e-risultati)
- [2. Che cosa mostra la ricerca](#2-che-cosa-mostra-la-ricerca)
  - [2.1 Le formule universali incontrano limiti empirici](#21-le-formule-universali-incontrano-limiti-empirici)
  - [2.2 Il coinvolgimento cambia il peso degli argomenti](#22-il-coinvolgimento-cambia-il-peso-degli-argomenti)
  - [2.3 La facilità di lettura può influenzare i giudizi](#23-la-facilità-di-lettura-può-influenzare-i-giudizi)
  - [2.4 La concretezza ha evidenze in contesti specifici](#24-la-concretezza-ha-evidenze-in-contesti-specifici)
  - [2.5 Clic e lettura sono esiti differenti](#25-clic-e-lettura-sono-esiti-differenti)
  - [2.6 La leggibilità ha un ruolo distinto dalla persuasione](#26-la-leggibilità-ha-un-ruolo-distinto-dalla-persuasione)
- [3. I paradigmi da conoscere](#3-i-paradigmi-da-conoscere)
  - [3.1 Argomento, credibilità ed emozione](#31-argomento-credibilità-ed-emozione)
  - [3.2 Posizionamento e ricerca del pubblico](#32-posizionamento-e-ricerca-del-pubblico)
  - [3.3 Consapevolezza e obiettivo del messaggio](#33-consapevolezza-e-obiettivo-del-messaggio)
  - [3.4 Persuasione sociale e ostacoli alla decisione](#34-persuasione-sociale-e-ostacoli-alla-decisione)
- [4. Le strutture di copywriting a confronto](#4-le-strutture-di-copywriting-a-confronto)
  - [4.1 Schemi per organizzare l'argomento](#41-schemi-per-organizzare-largomento)
  - [4.2 Schemi per confronto e revisione](#42-schemi-per-confronto-e-revisione)
  - [4.3 Una regola di scelta utilizzabile](#43-una-regola-di-scelta-utilizzabile)
- [5. Un protocollo operativo per trasformare un testo](#5-un-protocollo-operativo-per-trasformare-un-testo)
  - [5.1 Il brief minimo](#51-il-brief-minimo)
  - [5.2 Le dieci passate di revisione](#52-le-dieci-passate-di-revisione)
  - [5.3 Dal dettaglio tecnico al beneficio](#53-dal-dettaglio-tecnico-al-beneficio)
- [6. Standard linguistici proposti per un post commerciale](#6-standard-linguistici-proposti-per-un-post-commerciale)
  - [6.1 Lessico, verbi e sintassi](#61-lessico-verbi-e-sintassi)
  - [6.2 Voce, emozione e ritmo](#62-voce-emozione-e-ritmo)
  - [6.3 Numeri, prove e condizioni](#63-numeri-prove-e-condizioni)
- [7. Sinonimi e alternative italiane: repertorio ragionato](#7-sinonimi-e-alternative-italiane-repertorio-ragionato)
  - [7.1 Perché il contesto viene prima della sostituzione](#71-perché-il-contesto-viene-prima-della-sostituzione)
  - [7.2 Trenta alternative lessicali contestuali](#72-trenta-alternative-lessicali-contestuali)
  - [7.3 Quindici riscritture di promesse generiche](#73-quindici-riscritture-di-promesse-generiche)
  - [7.4 Dieci CTA più specifiche](#74-dieci-cta-più-specifiche)
- [8. Come costruire il post, dall'apertura alla CTA](#8-come-costruire-il-post-dallapertura-alla-cta)
  - [8.1 L'apertura](#81-lapertura)
  - [8.2 Il corpo e la prova](#82-il-corpo-e-la-prova)
  - [8.3 Chiusura e continuità](#83-chiusura-e-continuità)
- [9. Laboratorio: tre riscritture complete](#9-laboratorio-tre-riscritture-complete)
  - [9.1 Un prodotto digitale pratico](#91-un-prodotto-digitale-pratico)
  - [9.2 Un libro da colorare](#92-un-libro-da-colorare)
  - [9.3 Una consulenza](#93-una-consulenza)
- [10. Che cosa aggiungono Reddit e i blog professionali](#10-che-cosa-aggiungono-reddit-e-i-blog-professionali)
  - [10.1 Voce del cliente: procedure utili, risultati da verificare](#101-voce-del-cliente-procedure-utili-risultati-da-verificare)
  - [10.2 Formule e idee non si escludono](#102-formule-e-idee-non-si-escludono)
  - [10.3 Il limite dei consigli professionali](#103-il-limite-dei-consigli-professionali)
- [11. Misurare se il testo contribuisce alla vendita](#11-misurare-se-il-testo-contribuisce-alla-vendita)
  - [11.1 Separare interesse e disponibilità a pagare](#111-separare-interesse-e-disponibilità-a-pagare)
  - [11.2 Due test interpretabili](#112-due-test-interpretabili)
  - [11.3 Checklist finale senza punteggi predittivi](#113-checklist-finale-senza-punteggi-predittivi)
- [12. Valutazione complessiva, limiti e fonti](#12-valutazione-complessiva-limiti-e-fonti)
  - [12.1 Che cosa conviene trattenere](#121-che-cosa-conviene-trattenere)
  - [12.2 Limiti e verifica del lavoro](#122-limiti-e-verifica-del-lavoro)
  - [12.3 Bibliografia accademica](#123-bibliografia-accademica)
  - [12.4 Fonti professionali, istituzionali e linguistiche](#124-fonti-professionali-istituzionali-e-linguistiche)
  - [12.5 Discussioni Reddit](#125-discussioni-reddit)

## 1. Che cosa significa rendere vendibile un testo

### 1.1 Una definizione operativa

In questo studio chiamiamo copywriting commerciale la progettazione di un messaggio che permetta a un pubblico preciso di riconoscere un valore, valutarne la credibilità e compiere un'azione coerente. La vendita è uno degli esiti possibili: il compito di un primo post può essere far vedere una dimostrazione o ottenere una richiesta pertinente.

La definizione è una scelta operativa del rapporto. Da essa deriva un criterio: prima di modificare aggettivi o punteggiatura bisogna sapere **chi legge, che cosa si offre, perché dovrebbe interessare e quale passo si chiede**.

Non usiamo “vendibile” per indicare un testo capace di convincere chiunque. Un criterio di qualità utile è permettere anche a chi non è adatto di riconoscerlo senza acquistare per errore.

### 1.2 Standard, modelli e risultati

Distinguere quattro oggetti evita molte promesse eccessive:

| Oggetto | Che cosa offre | Che cosa non dimostra |
|---|---|---|
| Criterio editoriale | Controlli su chiarezza, coerenza e precisione | Aumento certo delle vendite |
| Formula professionale | Ordine possibile delle informazioni | Sequenza ottimale per ogni pubblico |
| Risultato sperimentale | Evidenza relativa a condizioni ed esiti definiti | Trasferibilità automatica a ogni post |
| Risultato commerciale osservato | Esito di una campagna concreta | Causa certa senza confronto adeguato |

Questa tabella è una classificazione proposta dall'autore dello studio. L'idea di “standard che fa vendere” va quindi tradotta in un processo verificabile, con qualità minima del messaggio e test sul caso reale.

## 2. Che cosa mostra la ricerca

### 2.1 Le formule universali incontrano limiti empirici

O'Keefe e Hoeken esaminano 1.149 studi su 30 variazioni del messaggio: gli effetti medi sono generalmente piccoli e variabili. La mediana degli effetti medi è circa r=.10; non significa un incremento del 10% delle vendite. La forma mediamente migliore non assicura un vantaggio nel nuovo caso. L'analisi confronta variazioni persuasive, non l'intero valore del prodotto o del marketing. [O'Keefe e Hoeken (2021/06), abstract, risultati e discussione]

```text
“small mean effect sizes”

“dimensioni medie dell'effetto piccole”
```
[O'Keefe e Hoeken (2021/06), abstract]

**Conclusione operativa proposta:** usare gli schemi come ipotesi iniziali e controlli di completezza; non attribuire loro percentuali predittive.

### 2.2 Il coinvolgimento cambia il peso degli argomenti

Nel lavoro classico di Petty, Cacioppo e Schumann, la qualità degli argomenti influenza maggiormente gli atteggiamenti quando il coinvolgimento è alto; la natura del testimonial pesa maggiormente con basso coinvolgimento. Lo studio riguarda studenti e pubblicità su rivista, non acquisti su Facebook. È un contributo alla distinzione tra vie centrale e periferica della persuasione, che non va ridotta a “logica contro emozione”. [Petty, Cacioppo e Schumann (1983/09), abstract]

```text
“two relatively distinct routes to persuasion”

“due vie relativamente distinte della persuasione”
```
[Petty, Cacioppo e Schumann (1983/09), p. 135]

**Applicazione proposta:** per chi sta confrontando soluzioni, dare spazio a funzionamento, requisiti e prove; per il primo incontro, rendere subito riconoscibile la pertinenza senza perdere correttezza.

### 2.3 La facilità di lettura può influenzare i giudizi

Alter e Oppenheimer integrano nella loro review diversi tipi di facilità di elaborazione: percettiva, lessicale, sintattica e concettuale. Sottolineano che gli effetti sui giudizi dipendono dall'interpretazione e dal contesto; avvertono anche della cautela necessaria nel ricondurre retrospettivamente studi diversi allo stesso meccanismo. Non è una prova di incremento delle conversioni per ogni frase semplice. [Alter e Oppenheimer (2009/08), pp. 219–220]

```text
“depend strongly on the context”

“dipendono fortemente dal contesto”
```
[Alter e Oppenheimer (2009/08), p. 220]

**Applicazione proposta:** eliminare difficoltà non necessarie, lasciando i termini tecnici che il pubblico deve comprendere per decidere.

### 2.4 La concretezza ha evidenze in contesti specifici

Packard e Berger riportano cinque studi, incluse oltre 1.000 interazioni reali di servizio. Il linguaggio concreto è collegato a maggiore soddisfazione e a misure d'acquisto; il meccanismo riguarda la percezione di ascolto e comprensione dei bisogni. È stato consultato l'abstract ripubblicato sul sito universitario dell'autore, non il testo integrale OUP. Non segue che aggiungere dettagli a un post produca sempre più vendite. [Packard e Berger (2021), abstract universitario]

```text
“attending to and understanding their needs”

“prestare attenzione ai bisogni e comprenderli”
```
[Packard e Berger (2021), abstract universitario]

**Applicazione proposta:** sostituire “assistenza eccellente” con una descrizione verificabile di tempi, canali e attività effettivamente offerte.

### 2.5 Clic e lettura sono esiti differenti

Berger, Moe e Schweidel analizzano 649.129 eventi di consumo pagina relativi a 35.448 articoli, insieme a esperimenti. Facilità di elaborazione ed emozioni partecipano alla prosecuzione della lettura. Gli autori distinguono esplicitamente attirare e trattenere l'attenzione. L'osservazione dello scorrimento di contenuti editoriali non dimostra una crescita degli acquisti. [Berger, Moe e Schweidel (2023/01), abstract, metodi e “Types of Engagement”]

```text
“retaining attention is a different type of engagement”

“trattenere l'attenzione è un diverso tipo di coinvolgimento”
```
[Berger, Moe e Schweidel (2023/01), introduzione]

Robertson e colleghi analizzano esperimenti sui titoli Upworthy: 22.743 test, circa 105.000 varianti, oltre 370 milioni di impressioni. Il linguaggio negativo influenza il clic nel contesto studiato. Qui sono stati consultati testo indicizzato e abstract del PDF editoriale; l'apertura diretta è poi fallita. L'esito è il consumo di notizie, non l'acquisto di prodotti. [Robertson et al. (2023/03), abstract e metodi indicizzati]

**Applicazione proposta:** un titolo può essere valutato anche per la qualità delle persone che porta all'offerta, non soltanto per il numero di clic. Non assumere che paura, scandalo o negatività siano il tono migliore di una campagna.

### 2.6 La leggibilità ha un ruolo distinto dalla persuasione

Morkes e Nielsen confrontano cinque versioni di un sito: concisione, scansione e stile oggettivo migliorano l'usabilità misurata. Il celebre +124% riguarda il loro indice di usabilità combinato, non le vendite. Il test quantitativo coinvolge 51 utenti del web degli anni Novanta. La ricerca va letta nel suo periodo e formato. [Morkes e Nielsen (1997/01), studio 3 e risultati]

```text
“measured usability”

“usabilità misurata”
```
[Morkes e Nielsen (1997/01), sintesi]

La guida GOV.UK raccomanda parole familiari, chiarezza, struttura e spiegazione dei termini necessari anche per specialisti. È uno standard editoriale istituzionale inglese; non è un test di efficacia pubblicitaria in italiano. [GOV.UK (s.d.), “Use clear language”]

**Applicazione proposta:** un argomento per paragrafo, etichette informative quando utili, apertura pertinente e lunghezza sufficiente a decidere. Nessun numero fisso di righe rende automaticamente persuasivo un post.

## 3. I paradigmi da conoscere

### 3.1 Argomento, credibilità ed emozione

Purdue OWL distingue logos, ethos e pathos e mette in guardia da generalizzazioni affrettate e false attribuzioni causali. È una guida universitaria all'argomentazione, non un esperimento sulle conversioni. [Purdue OWL (s.d.), “Using Rhetorical Strategies for Persuasion”]

```text
“Logos or the appeal to reason”

“Logos, ossia l'appello alla ragione”
```
[Purdue OWL (s.d.), “Logos”]

Per revisionare un post, propongo tre domande distinte:

- **Argomento:** il beneficio segue davvero dalle caratteristiche del prodotto?
- **Credibilità:** il lettore può verificare la promessa o vedere una prova pertinente?
- **Rilevanza emotiva:** la situazione conta per quella persona, senza che il testo ne esasperi artificialmente il disagio?

Un'emozione non sostituisce una dimostrazione. Una testimonianza positiva non dimostra da sola che ogni cliente otterrà lo stesso risultato.

### 3.2 Posizionamento e ricerca del pubblico

Dunford collega posizionamento, alternative competitive, capacità distintive, valore e segmento. Il suo contesto professionale prevalente è il B2B tecnologico. Copyhackers descrive interviste, sondaggi e analisi delle recensioni come risorse per trovare messaggi e gerarchia delle informazioni. Sono metodologie professionali, non leggi universali. [Dunford (2021/03)]; [Copyhackers/Ricerca (2022/06)]

```text
“Conversion copywriters begin with research”

“Il copywriting orientato alla conversione comincia dalla ricerca”
```
[Copyhackers/Ricerca (2022/06), titolo di sezione]

**Procedura proposta:** registrare frase reale, situazione, alternativa, obiezione, fonte e data. Tenere separate parole effettivamente raccolte e formulazioni inventate per esercizio. Cercare anche clienti insoddisfatti e persone che non hanno comprato.

### 3.3 Consapevolezza e obiettivo del messaggio

La guida Copyhackers presenta i cinque livelli di consapevolezza attribuiti a Eugene Schwartz: inconsapevole, consapevole del problema, della soluzione, del prodotto e pronto all'offerta. In questo rapporto la fonte è una spiegazione professionale successiva, non la lettura integrale di Breakthrough Advertising. Non adottiamo come benchmark le percentuali di pubblico mostrate nell'articolo. [Copyhackers/Consapevolezza (2022/04)]

**Adattamento editoriale proposto:**

| Situazione del lettore | Informazione prioritaria | Azione ragionevole da proporre |
|---|---|---|
| Non riconosce ancora il bisogno | Episodio concreto, con pertinenza esplicita | Leggere un esempio |
| Riconosce la difficoltà | Spiegazione e possibilità realistica | Provare un passaggio |
| Confronta approcci | Funzionamento e differenze | Guardare una dimostrazione |
| Conosce il prodotto | Prove, requisiti, prezzo e obiezioni | Valutare la scheda completa |
| Vuole acquistare | Condizioni e procedura | Completare l'acquisto |

Il livello non è una diagnosi psicologica certa: va inferito da dati e conversazioni e può variare fra persone esposte allo stesso post.

### 3.4 Persuasione sociale e ostacoli alla decisione

Influence at Work presenta sette principi associati al lavoro di Cialdini: reciprocità, scarsità, autorità, coerenza, simpatia, riprova sociale e unità. La pagina dell'organizzazione è una fonte primaria per descrivere il proprio quadro, ma anche commerciale; non equivale a una revisione indipendente delle sette leve. [Influence at Work (s.d.), “The Science of Persuasion”]

MarketingExperiments distingue attrito del processo e preoccupazioni del cliente; il relativo PDF organizza la riflessione su motivazione, valore, incentivi, attrito e ansia. La sua equazione è un'euristica professionale: qui non viene usata come calcolatore numerico di probabilità di vendita. [MarketingExperiments (2008/04)]; [MarketingExperiments/Postcard (s.d.)]

**Uso proposto dei principi:**

| Principio o ostacolo | Applicazione verificabile | Errore da evitare |
|---|---|---|
| Reciprocità | Campione utile e autonomo | Far sentire obbligati a comprare |
| Autorità | Competenza pertinente documentata | Qualifiche o riconoscimenti inventati |
| Riprova sociale | Esperienza autentica con contesto | Recensioni false o casi eccezionali presentati come norma |
| Scarsità | Limite reale di posti o produzione | Contatore che si azzera senza motivo |
| Coerenza | Passi facoltativi coerenti con l'interesse | Pressione a mantenere un impegno poco informato |
| Simpatia e unità | Voce riconoscibile e appartenenza reale | Fingere amicizia o identità condivisa |
| Attrito | CTA e passaggi comprensibili | Modulo sproporzionato all'azione |
| Preoccupazione | Prezzo, consegna e requisiti espliciti | “Fidati” al posto di informazioni |

Gli esempi della tabella sono proposte di progettazione, non risultati sperimentali delle fonti.

## 4. Le strutture di copywriting a confronto

### 4.1 Schemi per organizzare l'argomento

Copyhackers raccoglie AIDA, PAS, FAB, 4P, ACCA e QUEST; Buffer presenta anche BAB e le 4C in ambito social. Le sigle e le loro espansioni sono documentate in queste guide professionali. Impiego e rischi nelle tabelle seguenti sono suggerimenti editoriali del rapporto, non una graduatoria di efficacia. [Copyhackers/Formule (2015/10)]; [Buffer (2024/05)]

| Modello | Sequenza sintetica | Impiego proposto | Punto da controllare |
|---|---|---|---|
| AIDA | Attenzione, interesse, desiderio, azione | Un percorso breve dalla pertinenza all'offerta | Il desiderio deve poggiare su elementi credibili |
| PAS | Problema, conseguenze, soluzione | Un bisogno già riconosciuto | Non amplificare oltre il vero |
| FAB | Caratteristica, vantaggio, beneficio | Tradurre una specifica in uso concreto | Non saltare dalla funzione a un risultato non dimostrato |
| 4P | Scena, promessa, prova, invito | Un'offerta con dimostrazione disponibile | La scena futura non è un risultato già ottenuto |
| ACCA | Consapevolezza, comprensione, convinzione, azione | Spiegare un problema o approccio poco noto | Evitare spiegazioni senza collegamento all'offerta |
| QUEST | Qualificare, comprendere, educare, stimolare, accompagnare | Un segmento e un compito circoscritti | Non trattare l'etichetta del pubblico come ricerca |

Per PAS, “conseguenze” è la scelta di adattamento qui proposta per la fase professionale chiamata agitation: spiegare il costo concreto del problema senza esasperarlo. Per le 4P esistono varianti: dichiarare quale si usa, senza mescolare le fasi o attribuirle automaticamente alle 4P del marketing mix.

### 4.2 Schemi per confronto e revisione

| Modello | Sequenza o controllo | Impiego proposto | Punto da controllare |
|---|---|---|---|
| BAB | Prima, dopo, ponte | Mostrare un cambiamento e come realizzarlo | Chiarire se il “dopo” è ipotetico o documentato |
| 4C | Chiaro, conciso, interessante, credibile | Revisionare una bozza | Una checklist non predice conversioni |

Nel rapporto non attribuiamo paternità storiche certe alle formule sulla base di raccolte secondarie. Alcuni acronimi hanno varianti e riusi. Conoscere il nome serve meno che sapere quale informazione manca al lettore.

### 4.3 Una regola di scelta utilizzabile

Proposta: scegliere la struttura dopo aver individuato l'obiezione principale.

- Se il lettore non capisce il funzionamento, partire da spiegazione e prova.
- Se confronta prodotti, partire da differenza e caso d'uso.
- Se è pronto a comprare, rendere immediate condizioni e azione.
- Se desidera piacere, bellezza o appartenenza, non inventare una sofferenza per poter usare PAS.
- Se il testo è lungo, verificare che ogni blocco aggiunga un elemento utile alla decisione.

## 5. Un protocollo operativo per trasformare un testo

Tutta questa sezione è una proposta originale costruita per applicare lo studio. Non è uno standard certificato o una formula validata sperimentalmente.

### 5.1 Il brief minimo

Prima della riscrittura compilare questi campi:

| Campo | Domanda |
|---|---|
| Prodotto | Che cosa riceve esattamente chi acquista? |
| Persona | Chi può usarlo e in quale situazione? |
| Alternativa | Che cosa farebbe altrimenti? |
| Beneficio | Che cosa può ottenere attraverso l'uso? |
| Meccanismo | Quale caratteristica rende plausibile il beneficio? |
| Evidenza | Che cosa possiamo mostrare o verificare? |
| Limite | A chi non serve e che cosa richiede? |
| Offerta | Quanto costa e quali condizioni si applicano? |
| Azione | Quale unico passo principale chiediamo adesso? |
| Destinazione | Che cosa trova dopo il clic? |

### 5.2 Le dieci passate di revisione

1. **Fedeltà:** evidenziare fatti, numeri, condizioni e promesse da non alterare.
2. **Rilevanza:** mettere in apertura una situazione o un beneficio pertinente.
3. **Valore:** collegare una caratteristica a un utilizzo e a un beneficio plausibile.
4. **Spiegazione:** chiarire come il prodotto contribuisce al risultato.
5. **Prova:** collocare demo, esempio, dato o esperienza verificata vicino alla promessa.
6. **Obiezione:** rispondere al dubbio più probabile con un'informazione concreta.
7. **Lingua:** semplificare dove possibile senza impoverire significato o voce.
8. **Ordine:** un argomento per paragrafo e passaggi collegati.
9. **Azione:** rendere specifica la CTA e coerente la destinazione.
10. **Misura:** indicare che cosa osservare dopo la pubblicazione.

Senza dati per una promessa, scegliere fra ridurla, presentarla come ipotesi o cercare la prova. Il cambio di sinonimo non risolve una mancanza di evidenza.

### 5.3 Dal dettaglio tecnico al beneficio

Esercizio proposto: completare tre frasi in successione.

**Il prodotto contiene/fa… → Questo permette di… → Nel caso del lettore significa…**

Esempio ipotetico: “Il kit contiene una scheda riutilizzabile per il brief” → “puoi raccogliere obiettivo, pubblico ed esempi in un documento” → “quando inizi un nuovo testo hai quei criteri disponibili”.

La terza frase non autorizza a scrivere “raddoppia la produttività”. Servirebbero una definizione della misura e risultati pertinenti.

## 6. Standard linguistici proposti per un post commerciale

### 6.1 Lessico, verbi e sintassi

Applicare questi controlli come scelte editoriali da verificare:

- Preferire verbi che descrivono l'azione: confronta, stampa, scegli, compila, guarda.
- Nominare oggetto e risultato: “scarica la scheda” comunica più di “inizia il tuo percorso”.
- Sciogliere nominalizzazioni inutili: “compila” al posto di “procedi alla compilazione”.
- Usare la forma attiva quando chiarisce chi fa cosa; conservare la passiva se mette a fuoco l'informazione utile.
- Rivedere aggettivi valutativi come unico, rivoluzionario, professionale, incredibile: specificare il fatto sottostante.
- Conservare qualificatori necessari: “può contribuire”, “nel test svolto”, “per questo utilizzo”.
- Non aggiungere gergo per simulare competenza né eliminarlo quando il pubblico ne ha bisogno.

Sono indicazioni del protocollo, non una lista di parole vietate. “Premium” può avere un significato preciso in una gamma; va spiegato. “Semplice” può essere una valutazione legittima, ma è più utile se accompagnata da passaggi e requisiti.

### 6.2 Voce, emozione e ritmo

Scegliere il registro in relazione a pubblico, marca e compito. Il “tu” può essere adatto a un post personale; non è obbligatorio in ogni settore. Evitare il passaggio casuale fra tu, voi e forma impersonale.

Alternare periodi brevi e più distesi secondo il senso. Usare le pause per separare argomenti, non mandare a capo ogni parola. Leggere ad alta voce per individuare passaggi artificiali, senza trattare la lettura scorrevole come prova di vendita.

Un'immagine mentale è utile quando chiarisce: “il PDF contiene una tavola per pagina” rende ispezionabile un prodotto. Una metafora che nasconde i requisiti ostacola invece la valutazione. Umorismo e intensità devono essere coerenti con il tema; non servono confessioni o esperienze personali inventate.

### 6.3 Numeri, prove e condizioni

Per ogni numero nel copy chiedere: fonte, data, unità, popolazione, confronto e condizioni. “Risparmia due ore” richiede una misura pertinente; “contiene dodici modelli” richiede che siano davvero dodici e che la parola modello descriva il contenuto.

Distinguere:

| Forma | Esempio ipotetico | Che cosa serve |
|---|---|---|
| Dato di contenuto | “12 tavole in PDF” | Verifica del file |
| Istruzione | “Scegli una tavola e stampala” | Requisiti e compatibilità indicati |
| Beneficio plausibile | “Raccogli il brief in un documento riutilizzabile” | Funzione effettiva e limiti |
| Risultato misurato | “Nel test, tempo medio da X a Y” | Metodo, campione e condizioni |
| Garanzia commerciale | “Rimborso entro…” | Condizioni realmente offerte |

Le righe sono esempi editoriali, non dichiarazioni su un prodotto esistente.

## 7. Sinonimi e alternative italiane: repertorio ragionato

### 7.1 Perché il contesto viene prima della sostituzione

Treccani distingue sinonimia assoluta, rara, e sinonimia relativa o contestuale: registro, connotazione e combinazioni possono impedire lo scambio. La consulenza di Raffaella Setti per la Crusca mostra come termini vicini possano divergere in usi specialistici ed espressività. Sono fonti linguistiche, non esperimenti sul rendimento delle parole nel marketing. [Treccani/Faloppa (2011)]; [Crusca/Setti (2025/03)]

```text
“sinonimia relativa o contestuale”
```
[Treccani/Faloppa (2011), “Sinonimi assoluti, relativi, quasi-sinonimi”]

```text
“sono rarissimi i sinonimi perfetti”
```
[Crusca/Setti (2025/03), apertura]

**Tutte le alternative delle tre tabelle seguenti sono proposte editoriali originali.** Non sono “parole scientificamente vendenti”. Alcune sono sinonimi contestuali; altre sono cambi di struttura o richieste più specifiche. Scegliere solo la forma che conserva ciò che il prodotto offre davvero.

### 7.2 Trenta alternative lessicali contestuali

| Parola o espressione | Alternativa possibile | Differenza e condizione d'uso |
|---|---|---|
| Utilizzare | Usare | Più quotidiano; conservare “utilizzo” se è un termine del documento |
| Effettuare un acquisto | Acquistare | Elimina la perifrasi senza cambiare l'azione |
| Procedere alla compilazione | Compilare | Rende l'istruzione diretta |
| Fornire assistenza | Aiutare / offrire supporto | Precisare attività e canale, soprattutto se l'assistenza è contrattuale |
| Ottenere informazioni | Informarsi / consultare i dettagli | Consultare richiede una destinazione concreta |
| Implementare | Applicare / introdurre / configurare | Dipende dall'oggetto: implementare software non equivale sempre a configurarlo |
| Ottimizzare | Migliorare / ridurre / riordinare | Specificare che cosa cambia; “ridurre” richiede una quantità o un oggetto |
| Massimizzare | Aumentare / sfruttare meglio | Evitare di affermare un massimo dimostrato solo per intensità |
| Facilitare | Aiutare / rendere più agevole | Descrivere l'attività resa più agevole |
| Usufruire di | Usare / accedere a | Conservare eventuali significati giuridici quando pertinenti |
| Fruire dei contenuti | Leggere / guardare / ascoltare | Scegliere l'attività effettiva |
| Inviare | Mandare / trasmettere | Mandare è colloquiale; trasmettere può essere tecnico |
| Ricevere | Ottenere / trovare nella propria area | “Trovare nell'area” richiede che quella modalità esista |
| Iniziare | Cominciare / avviare | Avviare è naturale per processi; cominciare è più conversazionale |
| Scegliere | Selezionare | Selezionare può indicare un'interazione d'interfaccia |
| Comprare | Acquistare | Registro più colloquiale rispetto a più formale; stessa azione da precisare |
| Costo | Prezzo / spesa | Prezzo è ciò che si paga per l'offerta; costo e spesa possono includere altro |
| Economico | Accessibile / a prezzo contenuto | Giudizi relativi: spesso è più chiaro riportare il prezzo |
| Rapido | Veloce / in [tempo verificato] | Il tempo quantificato cambia la promessa e richiede prova |
| Pratico | Operativo / da applicare | Operativo suggerisce uso: specificare compiti ed esempi |
| Completo | Esteso / con [contenuti elencati] | Nessuno dei due è neutro; un indice può essere più informativo |
| Esclusivo | Riservato a / disponibile per | Dichiarare a chi, per quale ragione e per quanto tempo |
| Personalizzato | Adattato a / configurato per | Spiegare quali elementi vengono adattati |
| Professionale | Per [ruolo o compito] | È una riscrittura di pubblico, non certifica qualità |
| Consulenza | Analisi / incontro / affiancamento | Non sono servizi identici: usare il nome della prestazione effettiva |
| Formazione | Corso / laboratorio / guida | Durata, interazione e formato cambiano il contenuto |
| Scoprire | Esplorare / conoscere / vedere | Scegliere il verbo coerente con il materiale destinazione |
| Imparare | Comprendere / esercitarsi / acquisire | Comprendere ed esercitarsi non equivalgono a padronanza ottenuta |
| Risolvere | Affrontare / contribuire a risolvere | Riduce l'assolutezza; conservare il limite se è quello corretto |
| Trasformare | Cambiare / passare da [A] a [B] | Specificare il cambiamento e se è possibile, previsto o misurato |

### 7.3 Quindici riscritture di promesse generiche

| Espressione da esaminare | Riscrittura proposta | Verifica necessaria |
|---|---|---|
| “La soluzione definitiva” | “Uno strumento per [compito]” | Funzione effettiva e casi esclusi |
| “Innovativo” | “Consente [differenza concreta]” | Confronto pertinente, se si afferma novità |
| “Rivoluziona il tuo lavoro” | “Raccogli [informazioni] in [supporto]” | Il prodotto deve eseguire quel compito |
| “Risultati straordinari” | Descrivere un risultato osservato con condizioni | Metodo e dati, senza scegliere solo casi eccezionali |
| “Senza sforzo” | “Segui questi [passaggi effettivi]” | L'elenco deve rappresentare tutto l'impegno necessario |
| “Per tutti” | “Per [segmento], con [requisito]” | Utilizzatori e limiti |
| “Sicuro al 100%” | Descrivere la misura specifica di protezione | Non trasformare una misura in garanzia assoluta |
| “Garantito” | Esporre garanzia reale o limitare la promessa | Condizioni effettive e ambito |
| “Gratis” | “Scarica [risorsa] senza [costo reale escluso]” | Eventuali iscrizioni, rinnovi o altri vincoli vanno chiari |
| “Risparmi tantissimo” | Mostrare prezzo e confronto corretto | Base di confronto e costi aggiuntivi |
| “Investi in te stesso” | “Il corso costa [prezzo] e comprende [contenuti]” | Prezzo complessivo e contenuti; nessun rendimento implicito inventato |
| “Il migliore” | “Adatto a [uso] perché [caratteristica]” | Criterio e funzione supportabili |
| “Imperdibile” | “Disponibile a [condizioni]” | Prezzo, disponibilità ed eventuale scadenza reale |
| “Ultimi posti” | “Posso seguire [numero reale] persone in [periodo]” | Capacità e disponibilità aggiornate |
| “Tutti lo scelgono” | Riportare esperienza documentata e contesto | Fonte autentica e popolazione a cui si riferisce |

**Prezzo e investimento non sono sinonimi neutrali.** Il secondo introduce un'inquadratura e può far pensare a un rendimento. **Sconto, omaggio, risparmio e gratis** descrivono condizioni diverse: non sostituirli per intensificare il tono. Queste sono osservazioni editoriali del rapporto, non indicazioni di aumenti misurati della conversione.

### 7.4 Dieci CTA più specifiche

| CTA vaga | Alternativa da testare | Deve portare a… |
|---|---|---|
| Scopri di più | Guarda una dimostrazione | Una demo effettiva |
| Clicca qui | Leggi l'indice e un estratto | Indice ed estratto accessibili |
| Inizia ora | Compila il primo brief | La scheda o la procedura per compilarlo |
| Approfittane | Acquista il PDF a [prezzo] | Offerta a quel prezzo, con condizioni chiare |
| Contattami | Chiedi un preventivo per [servizio] | Canale e informazioni necessarie |
| Iscriviti | Ricevi [risorsa o aggiornamento] | Descrizione di iscrizione e consegna |
| Prova | Prova [funzione] con [condizioni] | Esperienza e limiti indicati |
| Scarica | Scarica la scheda in PDF | File o procedura di download |
| Prenota | Prenota un incontro di [durata] | Durata, costo se previsto e disponibilità |
| Continua | Vai ai requisiti e alle condizioni | Informazioni annunciate |

Una CTA specifica può rendere l'azione più comprensibile; l'eventuale vantaggio commerciale è da misurare. Non chiamare “download” una pagina che obbliga prima a una procedura non dichiarata.

## 8. Come costruire il post, dall'apertura alla CTA

Tutta la sezione descrive un metodo editoriale proposto. Gli esempi non sono risultati di campagne.

### 8.1 L'apertura

Un'apertura utile identifica presto tema e pertinenza. Può mostrare un beneficio, un episodio, un dettaglio del prodotto, una prova o una differenza rispetto a un'alternativa. La curiosità riguarda la spiegazione, non l'identità nascosta dell'offerta.

Cinque aperture ipotetiche per un kit che organizza un lancio:

1. “Hai il prodotto pronto e non sai quali contenuti pubblicare prima dell'offerta.”
2. “Questa scheda collega ogni post del lancio a un dubbio del cliente.”
3. “Prima del post di vendita, prepara la prova che le persone potranno valutare.”
4. “Nel kit trovi un calendario da compilare partendo da pubblico, offerta e tempo disponibile.”
5. “Guarda un esempio di lancio organizzato con due ore di lavoro alla settimana.”

L'ultima richiede che esista davvero un esempio compatibile con quelle risorse. Se è una simulazione, va chiamata simulazione.

### 8.2 Il corpo e la prova

Dopo l'apertura aggiungere rapidamente un'informazione utile: cosa contiene il prodotto o come affronta il compito. Scegliere pochi benefici collegati alle caratteristiche. Rispondere all'obiezione decisiva, non a dieci dubbi immaginati.

Vicino alla promessa inserire ciò che permette di controllarla: anteprima reale, estratto, funzionamento documentato, modalità di servizio o risultato con metodo. Non usare una foto di un cliente sorridente come prova di un beneficio tecnico.

Per una prova da produrre, scrivere prima una nota interna: cosa serve, chi la esegue e che cosa dimostrerà. Non inserirla come già avvenuta nel post pubblico.

### 8.3 Chiusura e continuità

La CTA deve corrispondere alla fase. Chi sta conoscendo il prodotto può consultare una demo; chi vuole acquistare deve trovare prezzo e condizioni. Una richiesta di commentare una parola ha senso solo se chiarisce quale risorsa verrà ricevuta e come. Non deve nascondere informazioni essenziali o promettere una consegna automatica inesistente.

Verificare anche destinazione e primo utilizzo. Un post accurato seguito da una pagina vaga rende difficile valutare l'offerta. Titolo, immagine e corpo devono sostenere la stessa promessa.

## 9. Laboratorio: tre riscritture complete

Tutti i prodotti e i dati di questa sezione sono **ipotetici e dimostrativi**. Non descrivono risultati reali o condizioni dei prodotti di Andrea. Gli esempi mostrano scelte linguistiche, non incrementi di vendita misurati.

### 9.1 Un prodotto digitale pratico

**Bozza generica**

“Scopri il nostro innovativo kit professionale per rivoluzionare i tuoi contenuti. Una soluzione completa, facile e potente che ti farà risparmiare tantissimo tempo. Non perdere questa opportunità.”

**Informazioni ipotetiche disponibili:** scheda brief compilabile, tre esempi commentati, utilizzo con testi commerciali, prezzo 12 €, nessun risparmio di tempo misurato.

**Riscrittura proposta**

“Se riscrivi ogni bozza perché pubblico, tono e obiettivo cambiano lungo il testo, puoi provare a raccoglierli prima in un brief.

Questo kit contiene una scheda compilabile e tre esempi commentati per preparare le istruzioni di un testo commerciale. Ti guida a definire lettore, messaggio, prove e azione richiesta.

Il kit costa 12 €. Nella pagina trovi l'anteprima della scheda e un esempio, così puoi valutarne l'utilità prima di acquistare.

Guarda la scheda e l'esempio: [link].”

**Che cosa cambia:** il problema è riconoscibile; la promessa si limita alla funzione; il contenuto sostituisce gli aggettivi; non viene inventata una quantità di tempo risparmiato; la CTA conduce alla prova annunciata.

### 9.2 Un libro da colorare

**Bozza generica**

“Il libro perfetto per eliminare lo stress! Disegni meravigliosi e unici ti aspettano. Acquista ora e cambia le tue serate.”

**Informazioni ipotetiche disponibili:** 40 tavole fantasy, libro cartaceo, una tavola per pagina, prezzo 9,90 €, anteprime dell'interno. Nessun beneficio clinico verificato.

**Riscrittura proposta**

“Draghi, torri e paesaggi immaginari: 40 tavole fantasy da colorare, con un disegno per pagina.

Puoi scegliere da quale iniziare guardando le anteprime dell'interno e la dimensione dei dettagli. Servono i tuoi materiali per colorare; il libro è cartaceo.

Costa 9,90 €. Sfoglia le anteprime e controlla i dettagli del formato: [link].”

**Che cosa cambia:** viene valorizzato un desiderio creativo senza affermare un effetto terapeutico. Il lettore può valutare stile, contenuto e formato. Non occorre trasformare ogni acquisto piacevole nella soluzione a un problema grave.

### 9.3 Una consulenza

**Bozza generica**

“Porta il tuo business al livello successivo con la migliore consulenza AI. Risultati garantiti e strategie su misura.”

**Informazioni ipotetiche disponibili:** incontro di 60 minuti, analisi di un solo processo, consegna di un documento con priorità e strumenti valutati, prezzo 90 €. Nessun risultato economico garantito.

**Riscrittura proposta**

“Vuoi capire dove usare l'AI nel tuo lavoro senza cambiare tutti gli strumenti insieme?

Durante un incontro di 60 minuti analizziamo un processo che mi descrivi in anticipo, per esempio la preparazione delle schede prodotto. Dopo l'incontro ricevi un documento con priorità, strumenti valutati e passaggi da verificare.

La consulenza costa 90 € e riguarda un processo. L'implementazione tecnica non è inclusa.

Leggi come prepararti e verifica le disponibilità: [link].”

**Che cosa cambia:** servizio e consegna sono riconoscibili; il prezzo è associato a un perimetro; il limite riduce l'ambiguità; nessun rendimento economico è inventato.

## 10. Che cosa aggiungono Reddit e i blog professionali

### 10.1 Voce del cliente: procedure utili, risultati da verificare

Nel thread di u/JMALIK0702 l'autore descrive raccolta di recensioni, forum e conversazioni, classificando problemi, eventi d'acquisto, scetticismo e risultati riferiti. Sostiene un metodo di tre ore; nei commenti un altro professionista parla invece di settimane. Tempi, esperienza ed efficacia sono auto-riferiti e non sono stati verificati tramite analytics o progetti. [Reddit/VoC (2026, pagina: circa 6 mesi prima della consultazione)]

```text
“The exact words are the whole point.”

“Le parole esatte sono il punto centrale.”
```
[Reddit/VoC (2026), post principale]

**Uso proposto:** costruire un archivio di linguaggio con provenienza e contesto, senza trasformare una recensione in testimonianza del proprio prodotto. Frequenza in un campione di forum non equivale a diffusione nella popolazione.

### 10.2 Formule e idee non si escludono

In “Framework vs. Raw Ideas”, alcuni commentatori descrivono le formule come struttura per organizzare intuizioni raccolte dal pubblico. Nel thread che elenca numerosi acronimi, altri criticano l'apprendimento meccanico delle sigle. Sono opinioni qualitative di partecipanti con identità professionali non verificate, non confronti sperimentali. [Reddit/Framework vs Raw Ideas (2026, pagina: circa 8 mesi prima)]; [Reddit/Core Frameworks (2026, pagina: circa 6 mesi prima)]

```text
“The frameworks still need the insights”

“Le strutture hanno comunque bisogno delle intuizioni”
```
[Reddit/Framework vs Raw Ideas (2026), commento]

**Uso proposto:** trasformare ogni formula in una checklist di funzioni. Prima di aggiungere un blocco chiedere quale dubbio risolve e quale evidenza contiene.

### 10.3 Il limite dei consigli professionali

Una guida originale può essere molto utile per lavorare anche senza dimostrare sperimentalmente ogni indicazione. Il rapporto conserva questa distinzione per Copyhackers, Buffer, Dunford e MarketingExperiments. Non vengono trasferite percentuali dei loro casi a un nuovo post, né considerate equivalenti una raccolta di formule e una meta-analisi.

## 11. Misurare se il testo contribuisce alla vendita

### 11.1 Separare interesse e disponibilità a pagare

Il PDF Strategyzer distingue test d'interesse/rilevanza, disponibilità e capacità di pagare, preferenze e priorità. È una guida professionale per esperimenti, non una prova della qualità di un testo specifico. [Strategyzer (s.d.), p. 1]

```text
“Testing willingness & ability to pay”

“Verificare disponibilità e capacità di pagare”
```
[Strategyzer (s.d.), p. 1]

**Protocollo di misura proposto:**

| Livello | Indicatore possibile | Limite da dichiarare |
|---|---|---|
| Esposizione | Impressioni o persone raggiunte | Non dimostrano lettura |
| Primo interesse | Clic sul link | Non dimostrano valutazione completa |
| Interesse pertinente | Richieste coerenti con il caso d'uso | Serve una definizione precedente di qualificazione |
| Acquisto | Ordini pagati della finestra/coorte | Servono attribuzione, ritardi e cancellazioni |
| Uso | Primo compito completato | Non sempre osservabile |
| Qualità economica | Ricavo netto e margine disponibili | Richiede costi, rimborsi e commissioni |

CTR sul link = clic sul link / impressioni × 100. Conversione della pagina = acquirenti unici / visitatori unici × 100, se questi dati sono disponibili e riferiti alla stessa finestra. Non usare clic al posto di visitatori unici senza dichiararlo.

### 11.2 Due test interpretabili

**Test proposto A: beneficio o funzionamento nell'apertura.** Mantenere identici prodotto, prezzo, immagine, CTA e destinazione. Confrontare un'apertura sul compito del cliente e una sulla dimostrazione. Scegliere prima la misura pertinente: per un primo test può essere la richiesta qualificata; per la vendita, il comportamento d'acquisto osservabile. Non presumere che più clic significhino più valore.

**Test proposto B: CTA generica o specifica.** Confrontare “Scopri di più” e “Guarda una dimostrazione”, solo se entrambe portano alla stessa demo. Osservare clic e successiva azione disponibile. Se non c'è randomizzazione, registrare differenze di pubblico, momento e distribuzione.

Stabilire finestra e criterio prima di vedere i risultati. Il campione necessario dipende da conversione di base, variabilità ed effetto che si desidera rilevare: non si indica qui una soglia universale. Con pochi eventi privilegiare osservazione del percorso e conversazioni; un risultato inconcludente non è un fallimento da nascondere.

### 11.3 Checklist finale senza punteggi predittivi

Prima di pubblicare segnare “sì”, “da correggere” o “non applicabile”:

1. Il pubblico e la situazione sono riconoscibili?
2. Il prodotto è identificabile senza indovinare?
3. Il beneficio segue da una funzione effettiva?
4. La promessa ha una prova pertinente oppure è limitata correttamente?
5. Esempi e testimonianze sono autentici o dichiarati ipotetici?
6. Numeri, prezzo e condizioni sono verificati?
7. Ogni paragrafo aggiunge informazione?
8. Le alternative lessicali conservano significato e registro?
9. Il titolo e l'immagine promettono ciò che il corpo mantiene?
10. L'obiezione principale riceve una risposta concreta?
11. La CTA indica cosa succede dopo?
12. La destinazione mantiene la stessa offerta?
13. Il testo si legge agevolmente sul dispositivo previsto?
14. La misura scelta corrisponde all'obiettivo?
15. Sono registrati i limiti di attribuzione e i dati mancanti?

La checklist è uno strumento editoriale originale: sommare le risposte non produce una probabilità di vendita.

## 12. Valutazione complessiva, limiti e fonti

### 12.1 Che cosa conviene trattenere

La sintesi operativa del rapporto è progettare un **argomento credibile per una persona in una situazione**, poi scegliere struttura e parole coerenti. Il lessico conta, ma la sostituzione di “comprare” con “investire” non corregge un'offerta poco comprensibile o una promessa senza prova.

Le strutture servono a organizzare. I criteri linguistici servono a rendere il testo comprensibile e fedele. I test servono a verificare il comportamento nel caso concreto. Questa è la proposta metodologica del rapporto, non una legge universale derivata da un singolo studio.

### 12.2 Limiti e verifica del lavoro

- Ricerca mirata, prevalentemente in inglese con approfondimento linguistico italiano. Comprende contributi di istituzioni e autori di Stati Uniti, Canada, Regno Unito, Paesi Bassi, Italia e altri contesti di ricerca europei. Non rappresenta ogni lingua e mercato mondiale.
- Le evidenze spaziano fra atteggiamenti, giudizi, assistenza clienti, lettura e clic. La trasferibilità alle vendite dei post va verificata e non è presunta.
- Sono stati aperti PDF accademici di O'Keefe/Hoeken, Alter/Oppenheimer e Petty/Cacioppo/Schumann; quest'ultimo è privo di testo estraibile e l'abstract è stato verificato sulla prima pagina. Consultati anche i PDF professionali MarketingExperiments e Strategyzer.
- Per Packard/Berger è stato letto l'abstract sul sito universitario: accesso al testo integrale dell'editore fallito. Per Robertson et al. disponibili ampi passaggi indicizzati e abstract PDF; apertura diretta HTML/PDF non riuscita. Il PDF della Crusca ha restituito un tipo di file non leggibile dal sistema: è stato usato il testo HTML completo.
- Non è stato letto integralmente il libro Breakthrough Advertising; i livelli sono riportati dalla guida Copyhackers. Non sono stati acquistati corsi o usate copie non autorizzate di manuali.
- I thread Reddit letti non sono un campione rappresentativo e le qualifiche dei partecipanti non sono verificate. Due ulteriori thread non accessibili sono stati esclusi. Date relative non sono state convertite arbitrariamente in giorni esatti.
- I conteggi di citazioni non sono stati verificati per la maggior parte dei paper. Per Berger/Moe/Schweidel la rilevazione parallela del sito editoriale riportava 98 Crossref e 92 Web of Science alla consultazione; database e aggiornamenti differiscono. I conteggi non sono usati come punteggio di qualità.
- Nessun post di esempio è stato pubblicato o sottoposto a test commerciale. I prodotti, prezzi e contenuti nella sezione laboratorio sono inventati per esercizio e dichiarati come tali.

Controlli completati: distinzione tra studi e metodi professionali; riapertura delle fonti selezionate dai ricercatori paralleli; verifica di autori, contesto e limiti disponibili; deduplicazione dei riferimenti; controllo della coerenza fra titoli e contenuti; separazione degli esempi originali dai risultati delle fonti.

Metadati: `product: Work`; `execution_location: Cloud`; `audit_mode: parallel-subagents`; capacità usate: ricerca web, lettura testuale e visiva PDF, ricerche parallele accademiche e linguistiche/Reddit, creazione del rapporto. Non disponibili: analytics privati, vendite dei casi, accesso integrale a tutte le fonti e una copertura esaustiva mondiale.

### 12.3 Bibliografia accademica

Consultazione delle fonti: 11 novembre 2026. Le affiliazioni si riferiscono al paper quando reperibili, non necessariamente all'incarico attuale. Conteggi non indicati: non verificati.

[O'Keefe e Hoeken, 2021/06] Daniel J. O'Keefe, Northwestern University, e Hans Hoeken, Utrecht University, ricercatori di comunicazione. “Message Design Choices Don't Make Much Difference to Persuasiveness and Can't Be Counted On—Not Even When Moderating Conditions Are Specified.” Frontiers in Psychology, 12:664160, 29 giugno 2021. Testo e PDF consultati. https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2021.664160/full — PDF autore: https://www.dokeefe.net/pub/OKeefeHoeken21FP.pdf

[Petty, Cacioppo e Schumann, 1983/09] Richard E. Petty e David Schumann, University of Missouri; John T. Cacioppo, University of Iowa, ricercatori. “Central and Peripheral Routes to Advertising Effectiveness: The Moderating Role of Involvement.” Journal of Consumer Research, 10(2), 135–146. Abstract della prima pagina verificato visivamente; non lettura integrale. https://richardepetty.com/wp-content/uploads/2019/01/1983-jcr-pettycaciopposchumann.pdf

[Alter e Oppenheimer, 2009/08] Adam L. Alter, New York University, e Daniel M. Oppenheimer, Princeton University, ricercatori. “Uniting the Tribes of Fluency to Form a Metacognitive Nation.” Personality and Social Psychology Review, 13(3), 219–235; online 28 luglio 2009. Abstract e sezioni iniziali consultati. https://pages.stern.nyu.edu/~aalter/tribes.pdf

[Packard e Berger, 2021] Grant Packard, Schulich School of Business/York University, e Jonah Berger, Wharton/University of Pennsylvania, ricercatori di marketing. “How Concrete Language Shapes Customer Satisfaction.” Journal of Consumer Research, 47(5), 787–806. Abstract consultato sulla pagina universitaria di Packard; testo OUP non recuperato. https://schulich.yorku.ca/faculty/grant-packard/ — DOI: https://doi.org/10.1093/jcr/ucaa038

[Berger, Moe e Schweidel, 2023/01] Jonah Berger, Wharton/University of Pennsylvania; Wendy W. Moe, University of Maryland; David A. Schweidel, Emory University, ricercatori di marketing. “What Holds Attention? Linguistic Drivers of Engagement.” Journal of Marketing, 87(5), 793–809; online 10 gennaio 2023. Testo, metodi e discussione consultati. Rilevazione parallela citazioni: Crossref 98, Web of Science 92, 11 novembre 2026. https://journals.sagepub.com/doi/10.1177/00222429231152880

[Robertson et al., 2023/03] Claire E. Robertson e Jay J. Van Bavel, New York University; Nicolas Pröllochs, University of Giessen; Kaoru Schwarzenegger e Stefan Feuerriegel, ETH Zurich, con affiliazione LMU Munich per Feuerriegel; Philip Pärnamets, Karolinska Institutet. “Negativity drives online news consumption.” Nature Human Behaviour, 16 marzo 2023. Testo indicizzato e abstract PDF consultati; apertura diretta non riuscita. https://www.nature.com/articles/s41562-023-01538-4 — PDF: https://www.nature.com/articles/s41562-023-01538-4.pdf

### 12.4 Fonti professionali, istituzionali e linguistiche

[Copyhackers/Ricerca, 2022/06] Jessica Noel, autrice Copyhackers; Joanna Wiebe, editor e fondatrice Copyhackers. “7 copywriting research techniques conversion copywriters love.” Mese da percorso editoriale; giorno non verificato. https://copyhackers.com/2022/06/copywriting-research/

[Copyhackers/Formule, 2015/10] Joanna Wiebe, fondatrice e autrice Copyhackers. “Every Copywriting Formula Ever (or The Ultimate Guide to No-Pain Copywriting).” Mese da percorso editoriale; giorno non verificato. Sezioni pertinenti consultate. https://copyhackers.com/2015/10/copywriting-formula/

[Copyhackers/Consapevolezza, 2022/04] Michelle Chow, autrice; Jessica Noel, editor. “Conversion copy course takeaways: Lessons that stuck with me.” Mese da percorso editoriale; giorno non verificato. https://copyhackers.com/2022/04/conversion-copy-course/

[Buffer, 2024/05] Rochi Zalani, autrice del blog Buffer. “10 Copywriting Formulas to Convert Skimmers to Buyers.” 23 maggio 2024. Guida professionale; non verifica indipendente delle promesse nel titolo. https://buffer.com/resources/copywriting-formulas/

[Dunford, 2021/03] April Dunford, consulente di posizionamento B2B tecnologico. “A Quickstart Guide to Positioning.” 15 marzo 2021. https://www.aprildunford.com/post/a-quickstart-guide-to-positioning

[Influence at Work, s.d.] Influence at Work, organizzazione collegata al lavoro di Robert Cialdini, psicologo e autore. “The Science of Persuasion / 7 Principles of Persuasion.” Data non verificata; fonte originale del proprio quadro e sito commerciale. https://www.influenceatwork.com/7-principles-of-persuasion/

[MarketingExperiments, 2008/04] Peg Davis, autrice MarketingExperiments; ruolo ulteriore non verificato. “Friction and Anxiety in your marketing process: defining the difference.” 22 aprile 2008. https://marketingexperiments.com/conversion-marketing/friction-and-anxiety-in-your-marketing-process-defining-the-difference

[MarketingExperiments/Postcard, s.d.] MarketingExperiments, autore istituzionale. PDF sulla motivazione e la conversion heuristic, 2 pagine, data non verificata. https://marketingexperiments.com/wp-content/uploads/motivation_postcard.pdf

[Strategyzer, s.d.] Strategyzer AG, autore istituzionale. “Testing Your Business Model: A Reference Guide.” PDF ufficiale, 10 pagine, data non verificata. https://assets.strategyzer.com/assets/resources/testing-your-business-model-a-reference-guide.pdf

[Morkes e Nielsen, 1997/01] John Morkes e Jakob Nielsen, ricercatori di usabilità. “Concise, SCANNABLE, and Objective: How to Write for the Web.” NN/g, 1 gennaio 1997 nella pagina attuale. https://www.nngroup.com/articles/concise-scannable-and-objective-how-to-write-for-the-web/

[GOV.UK, s.d.] Governo britannico, autore istituzionale. “Use clear language.” Guida editoriale; data non verificata. https://guidance.publishing.service.gov.uk/writing-to-gov-uk-standards/writing-guidelines/clear-language/

[Purdue OWL, s.d.] The Writing Lab & OWL, Purdue University, autore istituzionale. “Using Rhetorical Strategies for Persuasion.” Data di pubblicazione non verificata; il copyright non viene usato come data. https://owl.purdue.edu/owl/general_writing/academic_writing/establishing_arguments/rhetorical_strategies.html

[Treccani/Faloppa, 2011] Federico Faloppa, autore della voce enciclopedica. “Sinonimi.” Enciclopedia dell'Italiano, Treccani. https://www.treccani.it/enciclopedia/sinonimi_(Enciclopedia-dell%27Italiano)/

[Crusca/Setti, 2025/03] Raffaella Setti, autrice della consulenza linguistica. “Uno scorcio (o squarcio?) nel bosco dei sinonimi.” Italiano digitale, XXXII, 2025/1, pp. 109–113, 3 marzo 2025. HTML consultato; PDF non leggibile tramite lo strumento. Citazioni non verificate. https://id.accademiadellacrusca.org/articoli/uno-scorcio-o-squarcio-nel-bosco-dei-sinonimi/32365

### 12.5 Discussioni Reddit

[Reddit/VoC, 2026] u/JMALIK0702, autore che si presenta come professionista health/wellness; identità e risultati non verificati. “The VoC research process I run before writing a single word of copy for a health brand.” r/copywriting. Pagina: circa 6 mesi prima della consultazione; un risultato di ricerca parallelo riportava 20 aprile 2026, non assunto come giorno verificato dall'apertura. https://www.reddit.com/r/copywriting/comments/1sqrqfs/the_voc_research_process_i_run_before_writing_a/

[Reddit/Framework vs Raw Ideas, 2026] u/Lonely_Mark_8719 e commentatori, identità professionali non verificate. “Framework vs. Raw Ideas.” r/copywriting, pagina: circa 8 mesi prima della consultazione; giorno non verificato. https://www.reddit.com/r/copywriting/comments/1r8tmb7/framework_vs_raw_ideas/

[Reddit/Core Frameworks, 2026] u/itsfabioposca e commentatori, identità professionali non verificate. “All the Core Conversion Copywriting Frameworks You Should Know (Not Necessarily Master).” r/copywriting, pagina: circa 6 mesi prima della consultazione; giorno non verificato. https://www.reddit.com/r/copywriting/comments/1sz1b4w/all_the_core_conversion_copywriting_frameworks/
