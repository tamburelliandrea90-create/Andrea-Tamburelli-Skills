---
name: knowledge-work-plugins-it
description: Coordina e applica in italiano le skill professionali tratte dal repository Anthropic knowledge-work-plugins: marketing, vendite, finanza, legale, dati, design, engineering, operations, HR e altro. Seleziona il workflow pertinente e verifica i risultati. Richiamare quando l'utente chiede Knowledge Work Plugins.
---

# Knowledge Work Plugins IT

Questa è una **versione adattata per ChatGPT** delle procedure testuali contenute nel repository Anthropic knowledge-work-plugins. Non equivale all'installazione dei plugin Claude originali.

## Procedura
1. Chiedi o deduci obiettivo, destinatario, materiale disponibile, vincoli e risultato atteso.
2. Consulta `references/catalogo.csv` per scegliere la skill pertinente. Le skill originali sono archiviate in `references/source/` con la struttura originale.
3. Leggi il relativo `SKILL.md` e i riferimenti necessari prima di applicare la procedura. Se un file non è accessibile, dichiaralo.
4. Applica la procedura in italiano senza inventare risultati, fonti, accessi, autorizzazioni o integrazioni.
5. Distingui output documentali da azioni reali; per strumenti esterni o servizi MCP, richiedi connettori separati e permessi.
6. Verifica il risultato e riporta limiti, dipendenze e passaggi successivi.

## Limitazioni
- I file `.mcp.json` originali non sono attivati da questo adattamento.
- I plugin partner possono richiedere servizi, credenziali e licenze separati.
- I file script e gli ambienti eseguibili non sono installati automaticamente.
- Per legale, finanza, HR e salute, i risultati richiedono controllo professionale.
- Conservare le attribuzioni e licenze originali prima di ridistribuire.

## Esempi
- «Usa Knowledge Work Plugins IT: seleziona il workflow marketing per un lancio KDP».
- «Analizza il mio funnel commerciale con la skill più pertinente e proponi KPI».
- «Trova una skill per organizzare il supporto clienti e prepara una procedura operativa».
