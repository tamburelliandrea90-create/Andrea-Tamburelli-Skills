# Metodo di ricerca e provenienza

## Origine

Versione 1.0 costruita l'11 novembre 2026 per Andrea Tamburelli, consulente AI, dal prompt concordato e dallo studio «Creare il contesto per lanciare un prodotto». Procedura operativa indipendente: non è il corso ufficiale Product Launch Formula di Jeff Walker e non contiene il suo materiale riservato. Non descrivere istruzioni e riferimenti come addestramento di un nuovo modello.

Usare le fonti seguenti come riferimenti metodologici, non come prova dell'efficacia di questa implementazione. Consultarle quando si richiedono dettagli o aggiornamenti; non dichiarare nuove letture non eseguite.

## Fonti metodologiche

- April Dunford, «A Quickstart Guide to Positioning», 15 marzo 2021. Posizionamento, alternative, differenze e valore; esperienza soprattutto B2B tecnologica. https://www.aprildunford.com/post/a-quickstart-guide-to-positioning
- Jessica Noel, editor Joanna Wiebe, Copyhackers, «7 copywriting research techniques conversion copywriters love», giugno 2022 (mese del percorso editoriale). Ricerca e voce del cliente. https://copyhackers.com/2022/06/copywriting-research/
- Joanna Wiebe, Copyhackers, raccolta di formule, ottobre 2015 (mese del percorso editoriale). AIDA/PAS come strumenti, non garanzie. https://copyhackers.com/2015/10/copywriting-formula/
- Jeff Walker, «The Four Key Steps Behind My Product Launch Process», 1 agosto 2022. Descrizione commerciale originale della sequenza PLF. https://jeffwalker.com/product-launch-process/
- Google/The Behavioural Architects, «Decoding Decisions: Making sense of the messy middle», 2020. Esplorazione/valutazione e simulazioni di scelta; non equiparare preferenza simulata a vendita. https://www.thinkwithgoogle.com/_qs/documents/9998/Decoding_Decisions_The_Messy_Middle_of_Purchase_Behavior.pdf
- Schreiner, Mandler, van Heerde e Haiduk, «Dynamics of pre-release consumer buzz», Journal of the Academy of Marketing Science, 15 febbraio 2025. Studio nel cinema, non validazione universale del prelancio. https://link.springer.com/article/10.1007/s11747-024-01077-y
- Berger e Milkman, «What Makes Online Content Viral?», Journal of Marketing Research, aprile 2012. Diffusione; nello studio iniziale consultato l'abstract editoriale, non il testo integrale. https://journals.sagepub.com/doi/10.1509/jmr.10.0353
- Nabila Amarsy, Strategyzer, «Ways to test your value proposition and business model», 30 aprile 2015. Distinguere dichiarazioni e comportamento. https://www.strategyzer.com/library/ways-to-test-your-value-proposition-and-business-model
- Strategyzer, «Testing Your Business Model: A Reference Guide», PDF senza data verificata. https://assets.strategyzer.com/assets/resources/testing-your-business-model-a-reference-guide.pdf

## Uso delle fonti durante il lancio

Ricercare il prodotto e il pubblico, non ripetere solo queste fonti generali. Registrare autore/ente, titolo, URL, data verificabile e consultazione. Distinguere accademia, metodi professionali, dichiarazioni commerciali e testimonianze.

Per Reddit/recensioni riportare contesto e non generalizzare ricavi individuali. Non dedurre conversione senza denominatori. Non presentare frasi inventate come voce del cliente. Riassumere senza riprodurre lunghi brani protetti.

Con dati insufficienti proporre interviste su episodi passati, osservazione di prove e verifica della disponibilità a pagare mediante azioni trasparenti. Quantità di interviste e durata del calendario sono scelte organizzative, non soglie universali.

Trattare opportunità, trasformazione ed esperienza come funzioni del contenuto. Usare chiusura/scarsità solo con condizioni reali. Non trasferire automaticamente risultati del cinema a prodotti digitali, software o libri.
