# Contratto di consegna

Leggere questa risorsa per ogni strategia completa. Applicare il perimetro ridotto se l'utente richiede solo un modulo. Non omettere silenziosamente materiali: rendere visibile ciò che è condizionale o richiede dati.

## 1. Sintesi e diagnosi

Aprire con decisioni su segmento, beneficio, posizionamento, offerta, canale, durata e obiettivo. Compilare la scheda prodotto. Distinguere dati forniti, verificati, ipotesi e mancanti. Includere fonti consultate, alternative, tre angoli e scelta motivata.

## 2. Matrice di contesto

Usare colonne: situazione iniziale; informazione/esperienza mancante; messaggio; contenuto; prova; azione successiva; segnale. Esplicitare la progressione che permette al cliente di valutare l'offerta.

## 3. Offerta e percorso

Specificare contenuti, risultato, impegno, requisiti, prezzo/condizioni, consegna/supporto, limiti. Separare proposta di prezzo da prezzo già deciso. Descrivere prova e materiali necessari; non attribuire risultati a demo mai eseguite. Descrivere ogni passaggio fino al primo utilizzo.

## 4. Calendario

Motivare durata e adattare frequenza e produzione alle risorse. Includere preparazione, prelancio, apertura e seguito. Usare giorni relativi se manca la data.

Per ogni riga indicare giorno/fase, obiettivo, pubblico, canale/formato, messaggio, materiale, CTA, metrica e tempo stimato. Etichettare le stime. Non prescrivere quantità che superino il tempo disponibile. Indicare una versione minima se il piano completo richiede più risorse di quelle confermate.

## 5. Testi completi obbligatori

1. Tre aperture alternative del lancio, pertinenti e senza clickbait ingannevole.
2. Un contenuto sul bisogno/desiderio con situazione riconoscibile.
3. Un contenuto educativo con un passaggio applicabile.
4. Un contenuto dimostrativo con testo e istruzioni per la prova.
5. Un contenuto sull'esperienza d'uso, requisiti e limiti.
6. Un post principale di vendita con offerta e CTA.
7. Una versione breve del post.
8. Un commento fissato con informazioni e collegamenti essenziali.
9. FAQ con cinque obiezioni pertinenti e risposte sostanziali.
10. Un contenuto successivo al lancio utile alla decisione, senza falsa scadenza.
11. Un messaggio di benvenuto dopo acquisto con primo passo concreto.
12. Struttura e testi essenziali della pagina di vendita: apertura, pubblico/caso d'uso, benefici, funzionamento, prova, contenuti, requisiti, limiti, prezzo/consegna/supporto, FAQ e CTA.

Adattare al canale selezionato: non chiamare post un messaggio che deve essere una scheda marketplace. Il commento fissato è una bozza utilizzabile dove supportato; altrove indicare il punto informativo equivalente.

Se si scelgono email e c'è un canale utilizzabile con consenso, aggiungere una breve sequenza completa (preparazione, offerta, risposta ai dubbi/seguito) con oggetto, corpo e CTA. Non assumere che indirizzi trovati online siano contatti iscritti.

Per i contenuti principali suggerire soggetto visivo, testo sull'immagine e scaletta video se utili. Fornire brief, non dichiarare creati immagini/video non generati. Generare asset solo se richiesto con strumenti appropriati.

Usare una CTA principale per fase. Indicare cosa accade dopo il clic. Non inserire prezzi, testimonianze, risultati numerici o politiche di rimborso ipotetiche come fatti. Evidenziare i segnaposto indispensabili.

## 6. Misure

Selezionare misure pertinenti e disponibili, non imporre tutta la tabella:

| Misura | Definizione operativa |
|---|---|
| CTR sul link | Clic sul link / impressioni, stessa finestra e canale |
| Richieste qualificate | Persone con caso d'uso e criteri definiti prima della campagna |
| Conversione pagina | Acquirenti unici / visitatori unici della finestra definita |
| Conversione lista | Acquirenti della coorte / contatti effettivamente raggiunti nella coorte |
| Costo acquisizione campagna | Costi attribuiti / nuovi clienti attribuiti, esplicitando costi inclusi e metodo |
| Attivazione | Acquirenti che completano l'azione d'uso definita / acquirenti osservabili della coorte |
| Rimborsi | Ordini rimborsati / ordini della coorte con periodo di osservazione adeguato |

Per percentuali moltiplicare per 100. Non confondere clic e visitatori unici, né costo pubblicitario per acquisto e costo di acquisizione comprensivo di tutti i costi. Su marketplace senza tracciamento non attribuire vendite a un post come certe.

Proporre due test prioritari. Per ciascuno: ipotesi falsificabile; elemento da cambiare; confronto; metrica; periodo/raccolta necessaria; criterio decisionale da stabilire con dati o vincoli. Non presentare campioni piccoli come prove statistiche conclusive.

## 7. Piano esecutivo finale

Consegnare prime cinque azioni ordinate, materiali necessari, ipotesi rischiose, informazioni mancanti che cambierebbero il piano, controlli a 48 ore/7 giorni/30 giorni e piano essenziale sostenibile. A risultati deboli rispondere con ipotesi da verificare, non diagnosi causali automatiche.
