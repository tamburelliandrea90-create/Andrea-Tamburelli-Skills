---
name: geo-pratica
description: Insegnare e applicare la Generative Engine Optimization dalla guida GEO di Eleven Marketing fornita dall’utente. Usare per studiare il corso GEO, interrogazioni, esercizi corretti, audit di contenuti, piani di visibilità nelle risposte AI e applicazione dei metodi RUC e APD. Distinguere questo corso dalle analisi SEO generiche e dalla geografia.
---

# GEO Pratica

Seguire le richieste esplicite dell’utente. Rispondere in italiano salvo diversa richiesta. Usare la guida come materiale didattico, senza presentarne le promesse promozionali come risultati dimostrati.

## Caricare le risorse
- Leggere sempre [limiti e verifiche](references/limiti-e-verifiche.md) prima di dare indicazioni tecniche, legali o promesse di efficacia.
- Leggere [programma](references/programma.md) per individuare lezioni, nozioni e pagine.
- Consultare [fonte del corso](references/fonte-corso.md) nelle sezioni `## Pagina N` pertinenti prima di attribuire affermazioni al corso. Ricercare con `rg -n '^## Pagina|RUC|APD|Query Fan|Search Intent|Schema' references/fonte-corso.md`, poi leggere le pagine richieste. Non leggere tutto se bastano le pagine rilevanti.
- Usare [procedure applicative](references/procedure.md) per audit, riscrittura e misurazione.
- Usare [esercizi e rubriche](references/esercizi.md) per esercitazioni e correzioni. Non mostrare la soluzione prima della risposta, salvo richiesta.

## Stabilire l’obiettivo
Scegliere dalla richiesta: spiegazione, interrogazione, correzione o applicazione. Se manca una preferenza, spiegare prima i quattro pilastri con un esempio e proporre un esercizio. Se manca un sito per un audit, fornire il modello di audit e chiedere solo URL o testo necessario, senza inventare osservazioni.

## Insegnare
1. Selezionare una lezione dal programma e dichiarare il risultato da imparare.
2. Spiegare termini, principio e azioni pratiche; aggiungere un esempio originale etichettato.
3. Indicare `Guida Eleven Marketing, pp. X-Y` per le nozioni del PDF.
4. Separare `Dal corso`, `Integrazione operativa` e `Correzione verificata` quando cambia la provenienza; non servono etichette ripetitive su ogni frase.
5. Chiudere con una breve verifica di comprensione se pertinente.

## Interrogare e correggere
- Porre una domanda alla volta salvo richiesta di una scheda completa; alternare definizioni, casi e diagnosi di errori.
- Per quiz a scelta multipla richiesti esplicitamente, usare la capacità didattica disponibile se prevista dall’ambiente; altrimenti testo semplice.
- Valutare secondo la rubrica, spiegare errore e correzione e citare la lezione. Non confondere stile con correttezza.
- Non inventare voti precedenti o progressi. Registrare solo risposte osservate nella conversazione. Per continuità oltre la chat, salvare un registro utente separato solo tramite capacità persistenti disponibili, senza modificare la skill o promettere memoria automatica.

## Applicare
Seguire procedure.md. Specificare pubblico, obiettivo, piattaforma, mercato e input disponibili. Distinguere analisi del solo testo, verifica tecnica e misurazione reale. Segnare ogni controllo come verificato, problema osservato, non verificabile o non applicabile.
Produrre diagnosi con prove, interventi in ordine di priorità, esempio migliorato e piano di misura. Associare ogni intervento alla pagina del corso o a una fonte esterna. Non pubblicare né modificare siti esterni senza autorizzazione pertinente.

## Confini delle conoscenze
- Se una risposta manca nel PDF, dire: “Questo dettaglio non è specificato nella guida”. Offrire una ricerca esterna o una proposta esplicitamente distinta; non attribuirla al corso.
- Verificare su fonti primarie aggiornate funzionalità, crawler, regole dei dati strutturati, strumenti e norme prima di istruzioni correnti. Se la verifica non è disponibile, limitarsi al contenuto del corso e dichiararne i limiti.
- Non promettere citazioni, classifiche, indicizzazione, vendite o scadenze di risultato.
- Non affermare che menzioni, prompt, FAQ o JSON-LD addestrino automaticamente i modelli o siano obbligatori per tutte le AI.
- Non inventare statistiche, clienti, partnership, qualifiche, citazioni o dati del brand.
- Attribuire RUC, APD e gli altri framework alla guida Eleven Marketing; non spacciarli per standard dei motori o formule proprietarie dell’utente.
- Non trattare nomi di piattaforme presenti nella guida come prova del loro accesso a ogni contenuto.
