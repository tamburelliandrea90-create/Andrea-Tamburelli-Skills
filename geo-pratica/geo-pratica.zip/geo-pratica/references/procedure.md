# Procedure applicative

Le pagine rimandano al PDF. Le modalità di campionamento e le metriche di test sotto indicate sono integrazioni operative, non protocolli ufficiali Eleven Marketing.

## 1. Brief
Raccogliere contenuto/URL, pubblico, settore, lingua/mercato, obiettivo, piattaforma e disponibilità di misure. Usare quanto già fornito. Non bloccare una spiegazione didattica per dati mancanti.

## 2. Audit con prove
Usare una tabella: area | osservazione/prova | stato | azione | priorità | riferimento.
- Recuperabilità: accessibilità, testo disponibile, pagine collegate. Verificare tecnicamente soltanto con strumenti sufficienti; il testo incollato non prova crawling o indicizzazione. Corso pp. 8-9,17-19.
- Intento: domanda reale, risposta principale, completezza. Corso pp. 13,16.
- Struttura: titoli, risposta iniziale, elenchi, esempi e dati verificabili. Corso pp. 10,13,19.
- Autorevolezza: autore identificato, fonti reali, menzioni pertinenti. Corso pp. 11,14-15.
- Entità: nome e servizi coerenti, relazioni esplicite. Corso pp. 33-34.
- Semantica: sinonimi naturali, sottodomande e link utili. Corso pp. 35-38.
- Media/markup: alt text, trascrizioni, dati strutturati corrispondenti al contenuto visibile. Corso pp. 12,21-22.
- Locale, solo se pertinente: dati di contatto e località reali. Corso pp. 15-16.
- Aggiornamento e misure: fatti obsoleti, date, campione e fonti. Corso pp. 19-24,39-40.
Priorità alta: errori fattuali, ostacoli tecnici verificati, bisogno principale senza risposta. Media: struttura, riferimenti, collegamenti. Bassa: rifiniture. Adattare alla situazione, non assegnare punteggi finti.

## 3. Riscrittura
Consegnare: titolo descrittivo; risposta breve; sezioni per domande/sottotemi; passaggi o confronto se utili; esempi e fonti; FAQ non ridondanti; azione successiva per il lettore. Segnalare dati mancanti senza riempirli con invenzioni.
Per markup: selezionare un tipo appropriato solo dopo verifica attuale; usare dati reali; generare JSON valido senza segnaposto presentati come produzione. Indicare che la sintassi valida non prova efficacia o idoneità ai risultati avanzati.

## 4. Copertura e distribuzione
Costruire una mappa domanda principale -> sottodomande -> contenuto esistente -> lacuna -> pagina da creare o migliorare. Accorpare temi sovrapposti. Suggerire canali pertinenti al pubblico e formati originali con attribuzione, evitando invio massivo e duplicazioni meccaniche. Corso pp. 14-16,33-38.

## 5. Test della visibilità
- Separare prompt sul brand (riconoscimento) da prompt di settore senza il nome (scoperta spontanea).
- Scegliere un piccolo insieme stabile di domande rappresentative, includendo confronti e bisogni concreti.
- Registrare data, piattaforma/modello se visibile, lingua/località, ricerca web attiva o meno, prompt esatto, risposta, brand menzionato, URL citato, correttezza e concorrenti.
- Per la scoperta spontanea non allegare il proprio contenuto né suggerire il proprio brand nel prompt.
- Ripetere in sessioni pulite e più momenti con condizioni il più possibile confrontabili. Le risposte possono variare; non promettere isolamento perfetto.
- Distinguere impossibilità di accesso alla piattaforma da mancata citazione. Non simulare risultati mai osservati.
- Non usare la sola autodescrizione dell’AI sulle fonti come prova: verificare i link restituiti e il contenuto quando possibile.

## 6. KPI
Dal corso: citazioni, correttezza entità-brand, recuperabilità, menzioni senza link, presenza nelle risposte Google, ranking e CTR. La recuperabilità non è sempre osservabile come valore autonomo.
Integrazioni proposte, da dichiarare:
- Tasso di menzione = risposte con il brand / risposte valide osservate.
- Tasso di citazione = risposte con un link pertinente al dominio / risposte valide osservate.
- Correttezza = risposte sul brand corrette / risposte valutabili sul brand.
Usare denominatori, dimensione del campione e intervallo temporale espliciti; non presentare questi valori come copertura dell’intero mercato. Separare menzioni, visite attribuibili e conversioni reali. Non attribuire automaticamente miglioramenti alla singola modifica.

## 7. Output minimo
Diagnosi breve; tabella con prove e priorità; esempio applicato; tre prossime azioni; misura di partenza e riesame. Se si tratta di una simulazione, dichiararlo.
