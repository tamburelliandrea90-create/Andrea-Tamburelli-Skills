# Esercizi e correzione

Gli esercizi sono originali e derivati dalle nozioni della guida, non sono prove incluse nel PDF.

## Rubrica didattica
Valutare ciascun criterio applicabile da 0 a 2: 0 assente/errato; 1 parziale; 2 corretto e motivato.
Criteri: comprensione; applicazione concreta; verificabilità; rispetto dei limiti. Totale massimo 8 solo quando tutti applicabili. Non usare questa rubrica come punteggio GEO del sito. Correggere con: cosa funziona, errore preciso, spiegazione con pagina, esempio di soluzione, prossimo esercizio.

## E1 Quattro pilastri — L2, pp. 8-13
Consegna: spiegare i quattro pilastri e proporre un intervento per ognuno su un articolo.
Criteri di soluzione: recuperabilità/accesso; chiarezza/struttura; autorevolezza/fonti; multimodalità/descrizioni e trascrizioni. Nessuna garanzia automatica di citazione.

## E2 Intento — L3, p. 16
Consegna: classificare “cos’è la GEO”, “sito ufficiale Eleven Marketing”, “acquistare corso GEO” e proporre il contenuto adatto.
Soluzione: informativo/definizione; navigazionale/pagina ufficiale; transazionale/offerta verificabile. Premiare il bisogno servito, non la ripetizione della keyword.

## E3 Riscrittura — L3, pp. 10,13,19
Consegna: riscrivere “Il nostro corso è il migliore e ti fa apparire ovunque nelle AI”. Non sono disponibili dati sui risultati.
Soluzione attesa: eliminare superiorità e garanzia non provate; indicare contenuti verificabili, pubblico e scopo; risposta chiara e passaggi utili. Non inventare durata, testimonianze o percentuali.

## E4 Mappa semantica — L9, pp. 33-38
Consegna: creare una mappa per “scegliere un libro da colorare steampunk con una storia”.
Soluzione: pubblico, difficoltà, temi, trama, formato, carta/materiali; pagine distinte solo per bisogni sostanziali, collegate. Non inventare volumi di ricerca.

## E5 Test di visibilità — L7, pp. 20-24,39-40
Consegna: progettare un test per un autore senza fornire il suo nome nel prompt di scoperta.
Soluzione: domande di settore realistiche, dati di contesto registrati, sessioni pulite, ripetizioni, citazioni/menzioni distinte. Non interpretare una risposta isolata come prova causale.

## E6 RUC/APD — L8, pp. 29-32
Consegna: una pagina è accessibile e ben scritta, ma non ci sono osservazioni di risposte AI. Quali conclusioni sono consentite?
Soluzione: valutare qualitativamente caratteristiche favorevoli a R/U; citazione non verificata; APD da misurare. Nessun punteggio ufficiale o risultato garantito.

## E7 Limiti — L10, pp. 25-26 e limiti-e-verifiche.md
Consegna: “È sempre obbligatorio pubblicare il prompt per rispettare l’AI Act?”
Soluzione: il PDF non stabilisce un obbligo universale; verificare norme ufficiali correnti e fattispecie. Distinguere modello editoriale da conformità legale.

## E8 Dato assente
Consegna: “Qual è la formula ufficiale del punteggio RUC?”
Soluzione: dichiarare che la guida non specifica una formula; proporre eventualmente una rubrica qualitativa etichettata come integrazione.

## Modello di registro facoltativo
Data | lezione | consegna | risposta osservata | criteri/punteggio | errore da ripassare | prossima attività.
Non compilare prove non svolte né salvare automaticamente dati fuori dalla chat.
