# Programma e mappa delle conoscenze

Fonte: guida fornita dall’utente, 43 pagine fisiche. Lezioni organizzate per uso didattico; la numerazione L1-L10 è una riorganizzazione, non l’indice originale.

| Lezione | Pagine | Concetti e azioni |
|---|---|---|
| L1 Obiettivo GEO e SEO | 2-7,17-18,26 | Distinguere visibilità nei risultati da presenza nelle risposte generate. Comprendere zero-click. Integrare contenuti, reputazione e accessibilità tecnica. Non presumere che una citazione produca traffico o vendite. |
| L2 Quattro pilastri | 8-13 | Recuperabilità: rendere reperibili i contenuti. Chiarezza: definizioni, gerarchie, risposte sintetiche. Autorevolezza: fonti e menzioni pertinenti. Multimodalità: immagini descritte e trascrizioni. |
| L3 Intento e scrittura | 10,13,16,19 | Distinguere intento informativo, navigazionale e transazionale. Collegare titoli al bisogno reale. Rispondere subito, approfondire con elenchi, offrire un passo pratico. Usare dati veri e linguaggio semplice. |
| L4 Distribuzione e reputazione | 11,14-15,42 | Pubblicare sul sito e partecipare a blog verticali, Reddit, Quora, LinkedIn, Medium, podcast e YouTube con contributi utili. Distinguere autopubblicazione da riconoscimento indipendente. Wikipedia richiede criteri editoriali propri. |
| L5 GEO locale | 15-16 | Rendere coerenti nome, indirizzo, telefono, città, CAP e regione. Descrivere servizi nelle località effettivamente servite. Citare collaborazioni reali. Valutare LocalBusiness e PostalAddress. |
| L6 Dati strutturati e media | 9,12,18,21-22 | Conoscere FAQPage, HowTo, Article, Person, Organization, ImageObject e LocalBusiness. JSON-LD descrive contenuti reali. Curare alt text, didascalie, nomi file, trascrizioni e metadati social. Verificare supporto e sintassi. |
| L7 Test e KPI | 20-24,39-40 | Testare domande di settore e sul brand. Registrare presenza, citazioni, descrizioni, fonti e concorrenti. Integrare ranking, CTR, traffico e comportamento. Il bounce rate richiede contesto. Brand24 è citato come esempio di monitoraggio menzioni, non prova automatica di citazione AI. |
| L8 RUC e APD | 27-32 | RUC: recuperabilità, utilizzo, citazione. APD: AI Visibility, percezione, dominanza. Usare come griglie qualitative attribuite a Eleven Marketing, senza formula numerica ufficiale nel PDF. |
| L9 Entità e copertura semantica | 33-38 | Entity/Knowledge Graph: identità, servizi e relazioni coerenti. Semantic Retrieval: trattare significati e concetti correlati. Query fan-out: coprire domanda principale e sottodomande con pagine distinte quando utili e collegate. |
| L10 Revisione, trasparenza e limiti | 19,25-26,41-42 | Pianificare revisioni: la guida suggerisce 3-6 mesi, non è una legge del ranking. Distinguere AI-assisted e AI-generated secondo il testo. Verificare separatamente le norme; il modello di dichiarazione non certifica conformità. |

## Nozioni operative da conservare
1. Definire per quali domande si vuole essere utili e riconoscibili.
2. Rendere il contenuto accessibile, comprensibile e pertinente.
3. Scrivere risposte autonome e ben contestualizzate, non frasi isolate prive di soggetto.
4. Usare titoli gerarchici, paragrafi leggibili, liste e tabelle quando servono.
5. Fornire esempi concreti e dati controllabili, senza numeri decorativi.
6. Citare fonti reali e pertinenti alle affermazioni.
7. Curare identità dell’autore e coerenza del brand fra canali.
8. Distribuire materiale utile nei luoghi frequentati dal pubblico.
9. Collegare pagine correlate e sviluppare approfondimenti sui sottotemi.
10. Rendere disponibili in testo le informazioni essenziali contenute nei media.
11. Usare markup pertinente senza interpretarlo come scorciatoia obbligatoria.
12. Mantenere dati locali e descrizioni aggiornati.
13. Ripetere misure confrontabili; distinguere osservazione da causa.
14. Correggere informazioni inesatte sul proprio sito e sulle fonti controllabili.
15. Aggiornare quando cambiano fatti e bisogni, indicando modifiche sostanziali.

## Esempio originale per editoria
Tema: scegliere un libro da colorare steampunk con una storia.
Domande: che cosa significa steampunk? Quanto sono complessi i disegni? A chi è adatto? Quali materiali sono compatibili con la carta? Come si intrecciano storia e tavole?
Creare una pagina generale e approfondimenti utili collegati; inserire numero tavole, formato e caratteristiche solo dopo verifica del libro reale. Questo esempio non dimostra domanda di mercato né volume di ricerca.
