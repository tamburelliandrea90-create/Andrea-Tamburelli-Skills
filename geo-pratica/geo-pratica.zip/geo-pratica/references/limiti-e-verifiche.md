# Limiti della guida e verifiche

Revisione preparata il 7 novembre 2026. Non considerarla aggiornata per sempre.

## Distinguere fonte, interpretazione e prova
Il PDF è una guida commerciale, con ripetizioni e inviti alla consulenza. Contiene esempi e schemi, non uno studio sperimentale che dimostri efficacia universale. RUC/APD non hanno nel PDF formule, pesi o soglie validate. Non inventarle; se si propone una rubrica, dichiararla euristica.

## Correzioni essenziali
- Pubblicare online non inserisce automaticamente un testo nei dataset di addestramento. Separare addestramento, indicizzazione, recupero web e generazione con fonti.
- Un prompt di prova non addestra permanentemente il motore a riconoscere il brand. Una risposta ottenuta fornendo il proprio testo verifica soprattutto l’uso di quell’input, non la reperibilità spontanea.
- Una menzione del brand e una citazione con link alla pagina sono risultati distinti. Nessuna delle due prova che una specifica modifica abbia causato il risultato.
- Non tutti i modelli consultano il web per ogni domanda, né tutti usano lo stesso indice o processo. La descrizione del corso è semplificata.
- La guida descrive query fan-out come molto diffuso: Google documenta che AI Overviews e AI Mode possono usarlo, non che tutte le AI eseguano sempre decine di ricerche.
- Google dichiara che per AI Overviews/AI Mode valgono le basi SEO e non serve uno schema speciale. Accessibilità e requisiti soddisfatti non garantiscono inclusione.
- FAQ e HowTo possono essere utili al lettore; non sono requisiti universali né garanzie di risultati avanzati. Controllare regole correnti per ogni tipo.
- Alcuni esempi JSON-LD del PDF sono incompleti, con puntini di sospensione o parentesi mancanti. Non copiarli come codice pronto: rigenerare e validare la sintassi, poi verificare veridicità e pertinenza rispetto al testo visibile.
- Non aggiungere sinonimi o pagine solo per moltiplicare keyword. Coprire bisogni distinti con contenuti sostanziali e link pertinenti.
- Non ottenere citazioni con spam, recensioni false, autorità inventate o editing promozionale di Wikipedia.
- Aggiornare ogni 3-6 mesi è una cadenza suggerita dall’autore. Non cambiare date senza modifiche reali e non promettere un vantaggio automatico.
- Alt text serve a descrivere immagini pertinenti; og:image è un metadato sociale. Non attribuire a ciascun campo un peso GEO dimostrato.
- Un’immagine generata da un prompt che menziona un URL non misura il recupero della pagina né la visibilità del brand.

## Fonti primarie di confronto
1. Google Search Central, “AI features and your website”: https://developers.google.com/search/docs/appearance/ai-features — verificato il 7 novembre 2026. Basi SEO, testo disponibile, collegamenti interni, markup coerente, nessun requisito speciale, query fan-out possibile e limiti di inclusione.
2. Commissione europea, articolo 50 AI Act: https://ai-act-service-desk.ec.europa.eu/en/ai-act/article-50 — individuato in ricerca ufficiale il 7 novembre 2026; apertura diretta limitata da HTTP 429. Verificare il testo vigente prima di indicazioni legali.
3. Commissione europea, FAQ trasparenza: https://digital-strategy.ec.europa.eu/en/faqs/transparency-obligations-under-article-50-ai-act — fonte da consultare per aggiornamenti.

## Sezione AI Act del PDF, pp. 25-26
Trattare le dichiarazioni proposte come modelli editoriali del corso. Non affermare che la legge imponga sempre di pubblicare prompt, nome del modello e data per ogni testo assistito da AI. Gli obblighi dipendono da contenuto, ruolo e fattispecie, con eccezioni. Prima di una risposta normativa consultare il testo ufficiale vigente; senza verifica dichiarare che il PDF non basta a stabilire gli obblighi.

## Ciò che il materiale non specifica
Non fornisce: configurazione dettagliata dei crawler delle singole piattaforme; formule ufficiali RUC/APD; tempi garantiti per citazioni; tassi di conversione; accesso a dati privati; una ricerca keyword con volumi; istruzioni complete per CMS; piano sperimentale controllato. Esplicitare queste assenze quando pertinenti.
