---
name: search-intent-keyword-generator
description: Estrae da un testo keyword singole e keyword di esattamente due parole che un utente potrebbe cercare per trovare il contenuto, con classificazione per intento e piattaforma.
---
# Search Intent Keyword Generator

## Obiettivo
Trasforma qualsiasi testo in query di ricerca plausibili, con particolare attenzione a keyword di una o esattamente due parole. Non limitarti alle parole più frequenti: ragiona sul bisogno dell'utente che cerca il contenuto.

## Procedura
1. Leggi il testo completo, identifica argomento, pubblico, problemi risolti, benefici, entità, contesto geografico e lingua.
2. Se non specificata, usa la lingua del testo e una ricerca web generica; per testi di libri considera anche Amazon KDP, senza presupporre dati Amazon.
3. Genera 10-20 keyword di una parola e 20-40 keyword di esattamente due parole, se il testo le supporta. Riduci il numero se le combinazioni pertinenti sono poche.
4. Usa espressioni idiomatiche naturali che un utente potrebbe digitare. Includi sinonimi pertinenti non presenti nel testo, senza inventare contenuti.
5. Scarta stopword isolate, ripetizioni, accostamenti artificiosi, termini fuorvianti, marchi non pertinenti e keyword generiche senza utilità.
6. Per ciascuna keyword assegna intento (informativo, commerciale, transazionale, navigazionale), pertinenza stimata 0-100 e breve motivazione se richiesta.
7. Ordina per pertinenza e plausibilità dell'intento, non per presunti volumi. Segnala le 10 prioritarie.
8. Se l'utente specifica Google, Amazon, YouTube, social o lingua, adatta lessico e intento alla piattaforma.
9. Distingui chiaramente stime qualitative da dati verificati. Non attribuire volumi, CPC, difficoltà o trend senza fonti esterne attendibili.

## Output standard
Breve sintesi dell'intento di ricerca; tabella delle keyword singole; tabella delle keyword di due parole con intento e pertinenza; top 10 prioritarie; eventuali note su ambiguità e validazione con strumenti di keyword research.

## Vincoli
Le keyword classificate 'due parole' devono contenere esattamente due unità separate da spazio. Non confondere la keyword con il titolo o il testo di origine. Non affermare che una keyword sia realmente cercata dagli utenti senza dati di ricerca. Per contenuti sensibili o professionali evitare promesse o termini ingannevoli.
