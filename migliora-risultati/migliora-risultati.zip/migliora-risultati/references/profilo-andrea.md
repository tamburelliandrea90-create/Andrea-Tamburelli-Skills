# Profilo operativo — Andrea Tamburelli

Fotografia iniziale: 6 novembre 2026, Europe/Rome. Base: richiesta corrente, memoria riassuntiva e catalogo skill forniti nella sessione. Non è stata analizzata l'intera cronologia né sono stati aperti i file storici. Le tracce di file dimostrano soltanto che esiste una registrazione dell'artefatto, non ne certificano contenuto o qualità. Verificare le fonti primarie per aggiornamenti e affermazioni sul loro contenuto.

## Attività e preferenze
- Nome professionale: Andrea Tamburelli. Ambiti ricorrenti: autore e self publishing Amazon KDP, libri da colorare narrativi, manuali, creazione di skill e divulgazione AI. Fonte: memoria della sessione; riepilogo storico.
- Lingua prevalente: italiano. Tono richiesto per Facebook: umano, diretto, caldo, competente, leggermente ironico; titoli curiosi, talvolta molto ironici. Fonte: richieste Facebook riassunte del 5–6 novembre 2026.
- Struttura dei post: gancio comprensibile, problema concreto, benefici ed esempi, punti quando servono, chiusura con una CTA. Per tutorial, passaggi semplici adatti a inesperti. Evitare gergo non spiegato e promesse di vendite o viralità garantite.
- CTA: quando richiesta, invitare a commentare con il nome esatto della skill. Marketing Suite: commento «Marketing Suite»; altre parole dipendono dal singolo post. Non pubblicare o contattare persone sulla sola base di questa preferenza.
- Marketing Suite: presentarla come raccolta organizzata da Andrea basata su 53 moduli/skill reperiti in rete; non attribuirgli l'autorialità dei moduli originali. Preferenza esplicita riassunta del 6 novembre: nel post promozionale non elencarli tutti.
- Copertine KDP: margini di 2,5 cm richiesti frequentemente; formati variabili. Verificare formato, tipo di copertina, pagine e specifiche per ogni progetto, senza assumere una misura unica.
- Dettagli personali e sanitari non inclusi perché non necessari allo scopo operativo.

## Skill osservate
Fonte: catalogo skill della sessione del 6 novembre 2026. Disponibilità osservata in questa sessione; non è una verifica indipendente dei file o della loro efficacia.

| Skill/nome disponibile | Funzione indicata |
| --- | --- |
| marketing-suite | Strategia e marketing tramite raccolta di 53 moduli |
| ottimizza | Brief di conversione e riscrittura |
| umanizza-testo | Voce naturale e fluidità |
| comprimi-testo | Sintesi chiara di testi e trascrizioni |
| agenda-mail | Flussi posta/calendario e promemoria |
| amazon-product-analyst | Valutazione commerciale e concorrenti |
| amazon-competitor-compare | Confronto PDF con concorrente Amazon |
| amazon-kdp-scheda-competitor-audit | Audit contenuto e scheda KDP |
| amazon-kdp-publishing | Preparazione e pubblicazione KDP |
| progetta-copertine-kdp | Copertine e adattamenti KDP |
| instagram-competitor-reels | Audit Instagram e piano Reel |
| reel-reverse-engineering | Analisi narrativa e montaggio video |
| sbobina-audio-video | Trascrizioni e sottotitoli |
| ai-seo-optimizer | Analisi e ottimizzazione SEO |
| amazon-kdp-book-audit | Audit editoriale e commerciale |
| amazon-kdp-market-intelligence | Ricerca mercato, posizionamento e Ads |
| search-intent-keyword-generator | Keyword di una o due parole per intento |

La presenza in catalogo non dimostra che ogni skill sia stata creata da Andrea: distinguere le skill personali dai pacchetti forniti da plugin. Copywriting, Social, Marketing Psychology e Content Research Writer sono strumenti citati/disponibili; non attribuirne l'autorialità ad Andrea. «Scrittura legale» è riportata come richiesta storica; creazione e disponibilità da verificare.

## Obiettivi richiesti e risultati documentabili

| Obiettivo | Stato al 6 novembre 2026 | Evidenza disponibile | Prossimo controllo |
| --- | --- | --- | --- |
| Migliorare accuratezza e continuità con un profilo operativo | Richiesto nella chat corrente | Messaggio utente che richiede «migliora risultati» | Verificare salvataggio della skill e aggiornare lo stato solo dopo conferma |
| Creare e distribuire skill AI con guide | Produzione di alcuni artefatti documentata; distribuzione da verificare | Tracce del 6 novembre: Amazon_Product_Analyst_Skill.zip e Amazon_Product_Analyst_Guida.txt | Leggere i file per certificarne i contenuti; verificare separatamente upload e condivisione |
| Preparare il libro Robin Hood per KDP | Artefatti registrati; pubblicazione da verificare | Tracce del 6 novembre: interno PDF e copertine JPG/PDF | Controllare file correnti, requisiti e stato KDP |
| Promuovere Marketing Suite su Facebook | Testo e immagine richiesti; immagine registrata | Richieste e traccia «Marketing Suite: il megafono sbagliato.png» del 6 novembre | Verificare testo finale e pubblicazione effettiva |
| Collegare Facebook a Metricool e pubblicare | Problema segnalato; soluzione non verificata | Messaggi storici del 6 novembre su login e mancato riconoscimento pagina | Controllare connessione attuale prima di dichiarare risolto |
| Aumentare le vendite e ottimizzare Amazon Ads | Obiettivo dichiarato; andamento non verificato | Memoria: budget test 7 €/giorno e riferimento a budget 50 €, senza report attuale | Consultare report, date e budget correnti; non presumere vendite o ROI |
| Ricevere briefing KDP, radar coloring e avvisi recensioni | Automazioni riportate come attive nella memoria; efficacia da verificare | Elenco automazioni e ultime esecuzioni forniti nella sessione | Leggere configurazione e risultati prima di modificarle o dichiararne l'esito |
| Ricevere notifiche vendite KDP | Richiesto; attivazione non verificata | Memoria di richieste del 29–31 ottobre | Verificare integrazione e dati disponibili |

## Criteri operativi
Usare lo stile come guida, senza imporre un tono promozionale a traduzioni o risposte tecniche. Per post su un libro leggere il libro o le fonti pertinenti prima di descriverne la trama come verificata. Una richiesta di post non autorizza automaticamente pubblicazione. Non proporre come novità una skill già disponibile; verificare se Andrea chiede un aggiornamento.

## Copertura e lacune
Nessun archivio completo elaborato. Nessuna verifica diretta delle impostazioni di memoria o delle istruzioni personalizzate dell'account. Nessun accesso verificato a report KDP, dashboard Ads o risultati social. Il profilo deve essere aggiornato con fonti datate prima di affermazioni su questi stati.
