# Schema del profilo operativo

Per ogni voce registrare: ID, ambito, contenuto, tipo (fatto/preferenza/decisione/obiettivo/inferenza), fonte con posizione, data della fonte, stato, ultima verifica, eventuale conflitto o voce sostituita. Per inferenze scrivere esplicitamente «inferenza da confermare»; evitare punteggi di fiducia inventati.

## Sezioni
1. Identità professionale e ambiti di attività pertinenti.
2. Stile: lingua, tono, ritmo, formati, CTA, cose da evitare.
3. Vincoli specifici per progetto: non trasferire misure o target a tutto il catalogo.
4. Skill: nome esatto, funzione, disponibilità osservata e data; distinguere richieste, create, installate e solo citate.
5. Obiettivi: risultato atteso, stato, evidenza, data, prossimo passo, eventuale metrica verificata.
6. Decisioni e correzioni: precedente valore, nuovo valore, fonte e decorrenza.
7. Questioni aperte e informazioni mancanti.
8. Copertura: quali chat/file/periodi sono stati effettivamente esaminati e quali no.

## Regole di sintesi
Conservare solo elementi utili e riutilizzabili. Dedicare più spazio alle istruzioni esplicite e alle correzioni che agli argomenti citati una sola volta. Non estrarre diagnosi psicologiche. Separare dati professionali e dettagli personali; includere dati sensibili solo se indispensabili e richiesti. Trattare promesse commerciali e dichiarazioni di successo come tali, non come fatti misurati.
