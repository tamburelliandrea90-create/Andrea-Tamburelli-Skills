# Formati e fonti

Preferenze di Andrea; verificare sempre la disponibilità corrente per edizione, carta e inchiostro.

| Formato finito | Fronte a 300 dpi, senza bleed | Gabbia personale predefinita |
|---|---|---|
| 6×9 pollici | 1800×2700 px | 2 cm |
| 6×11 pollici | 1800×3300 px | 2 cm |
| 8,5×11 pollici | 2550×3300 px | 2,5 cm |
| 8,25×11 pollici | 2475×3300 px | 2,5 cm |
| B5 ISO, 176×250 mm | circa 2079×2953 px | 2,5 cm |

B5 non identifica automaticamente un formato KDP disponibile; distinguere ISO da JIS e verificare la selezione o formato personalizzato. Non usare 8,5×11 paperback come template hardcover. Se un formato non è disponibile, proporre un'alternativa disponibile senza sostituirlo silenziosamente.

## Regole geometriche di riferimento

Verificate il 7 ottobre 2026; consultare le fonti per aggiornamenti.

Paperback: bleed esterno 0,125 pollici (3,175 mm); testo del fronte e retro almeno 0,125 pollici dentro il taglio. Distinguere questa distanza da 0,25 pollici dal bordo esterno del file comprensivo di bleed. Copertina completa: larghezza = 2 × larghezza finita + dorso + 0,25 pollici; altezza = altezza finita + 0,25 pollici. Derivare il dorso dal calcolatore ufficiale; non inventare spessore carta. La pagina di copertina personalizzata indica almeno 79 pagine per testo sul dorso; Cover Creator indica 80. Verificare il flusso effettivo e mantenere almeno 0,0625 pollici lateralmente sul dorso, oltre alle aree del template.

Hardcover: usare il template ufficiale come autorità per pannelli, cerniere, area sicura e risvolti. Non trasferire distanze misurate dal bordo del file al bordo del pannello; non mescolare misure di origine diversa. Barcode: lasciare libera l'area del template sul retro.

## Fonti ufficiali

- Calcolatore e template: https://kdp.amazon.com/cover-calculator
- Paperback: https://kdp.amazon.com/help/topic/G201953020
- Hardcover: https://kdp.amazon.com/help/topic/GDTKFJPNQCBTMRV6
- Formati e margini del manoscritto, per verificare il formato finito: https://kdp.amazon.com/help/topic/GVBQ3CMEQW3W2VL6
- Cover Creator: https://kdp.amazon.com/help/topic/G201113520
- Copertine ebook: https://kdp.amazon.com/help/topic/G200645690
