---
name: progetta-copertine-kdp
description: Progettare, creare, adattare e correggere le copertine Amazon KDP di Andrea Tamburelli, con formati variabili, aree sicure misurate e gerarchia di titolo, sottotitolo, ribbon e autore. Usare per nuove copertine, conversioni paperback/hardcover/ebook, esportazioni JPG/PDF, testi fuori margine e richieste di gabbie di sicurezza di 2 o 2,5 cm.
---

# Copertine KDP di Andrea

## Raccogliere il brief

Usare il testo e i file della richiesta corrente come autorità. Recuperare il file nominato prima di modificarlo. Usare Andrea Tamburelli come autore predefinito, salvo indicazione diversa. Non trasferire titoli, claim, numero di pagine o tavole da libri precedenti.

Identificare formato fisico, tipo di edizione, fronte solo o copertina completa, titolo, sottotitolo, ribbon opzionali, autore e stile. Per un fronte senza specifiche usare 6×9 pollici, dichiarando l'assunzione; non assumere dati per una copertina completa. Se mancano pagine definitive, carta, inchiostro o rilegatura, realizzare il fronte e chiedere solo i dati necessari per il dorso definitivo. Non dichiarare un fronte JPG pronto per il caricamento come copertina cartacea completa.

Leggere [references/formati-e-fonti.md](references/formati-e-fonti.md). Verificare i requisiti KDP correnti nelle fonti ufficiali quando si produce un file da caricare. Non confondere margini del manoscritto e margini della copertina.

## Costruire la geometria prima della grafica

Usare il template ufficiale KDP relativo a formato, edizione, carta, inchiostro e pagine. Tenere distinte le coordinate di file, taglio, fronte, retro, dorso, cerniere, risvolti e area barcode. Per hardcover non applicare la formula paperback e non misurare il margine dal bordo esterno del file.

Usare come preferenza personale una gabbia di 2 cm all'interno del pannello frontale visibile per 6×9 e 6×11; usare 2,5 cm per 8,5×11, 8,25×11 e B5. Questi sono margini editoriali prudenziali, non minimi imposti da Amazon. Per altri formati usare 2 cm. Dare precedenza al margine richiesto esplicitamente. Intersecare sempre la gabbia personale con le aree sicure ufficiali: tutti i testi devono stare in entrambe. Se la richiesta rende la gabbia impossibile, spiegare il problema e proporre un valore concreto.

Eseguire `scripts/check_safe_boxes.py` su un manifest JSON per verificare ogni riquadro testuale. Usare un sistema di coordinate unico con origine in alto a sinistra, in pixel o punti. Schema: `{"canvas":[larghezza,altezza],"safe_rect":[x0,y0,x1,y1],"texts":[{"role":"titolo","bbox":[x0,y0,x1,y1]}]}`. Per retro e dorso usare manifest separati con le rispettive aree. Per aree escluse come cerniere/barcode verificare anche le intersezioni nel programma di impaginazione. Misurare i glifi effettivi, includendo accenti, contorni e ombre; non usare solo il centro del testo o il box nominale del font. Il controllo del manifest non sostituisce la misura del rendering.

## Comporre i testi

Rendere il titolo dominante, leggibile anche a 160–200 pixel di larghezza. Usare come punto iniziale titolo 100%, sottotitolo 35–50%, ribbon 25–40%, autore 30–45% della dimensione del titolo; adattare questi rapporti alla lunghezza e al genere, senza renderli vincoli rigidi.

Collocare il titolo nella parte alta della gabbia, lasciando aria sopra le lettere; collocare sottotitolo e ribbon senza competere col titolo; collocare l'autore nella parte bassa della gabbia, lasciando aria sotto. Consentire impaginazioni alternative se migliorano la lettura. Usare al massimo due famiglie di caratteri e contrasto sufficiente; proteggere testi su immagini complesse con fondi o gradienti.

Conservare esattamente nomi e testi richiesti. Non inventare ribbon, badge, premi, quantità o promesse. Se il testo non entra, cambiare prima a capo, disposizione e spaziature, poi dimensione entro limiti leggibili; non tagliare o riscrivere il copy senza autorizzazione. La fascia decorativa può arrivare al bordo, ma il suo testo e gli elementi essenziali devono restare dentro la gabbia.

## Creare e adattare la grafica

Per nuove illustrazioni raster usare imagegen e la sua skill. Per modificare immagini esistenti seguire il flusso di editing imagegen, salvo esplicita richiesta diversa. Preferire, quando possibile, illustrazione senza scritte più tipografia composta separatamente e misurabile; usare un editor vettoriale o impaginazione per testo, esportazione e verifica quando appropriato. Se imagegen incorpora i testi, controllare il risultato, rigenerare in caso di errori e non considerare sufficiente il prompt sui margini.

Adattare lo stile al libro: noir e libro-game con atmosfera e indizi leggibili; manuali con promessa concreta e ordine visivo; coloring book con rapporto chiaro tra lettura e colorazione. Seguire la richiesta corrente per palette e riferimenti.

Nel cambio di formato reimpaginare testi e ricomporre immagine senza deformarla; ricalcolare gabbia, dorso e dimensioni. Non spostare indiscriminatamente l'intera copertina di un centimetro: correggere separatamente testi e oggetti critici, mantenendo sfondo esteso. Quando si deve preservare una grafica precedente, mantenere palette, composizione e identità visiva per quanto compatibile con la nuova geometria.

## Verificare e consegnare

1. Controllare dimensioni fisiche, pixel, risoluzione effettiva e rapporto d'aspetto. A 300 dpi convertire con pixel = pollici × 300; centimetri = pollici × 2,54. Non migliorare artificialmente il dettaglio cambiando solo i metadati DPI.
2. Renderizzare e ispezionare il file finale a dimensione piena e in miniatura; controllare ortografia, accenti, tutti i testi, contrasto, sovrapposizioni e gabbia. Correggere ogni box fuori area e rieseguire il controllo.
3. Per stampa esportare una copertina completa in PDF a pagina singola, con font incorporati e immagini alla risoluzione richiesta; eliminare guide, template e crocini. Usare profilo colore secondo specifiche correnti. Per il fronte richiesto in JPG esportare il JPG separato; per ebook seguire i requisiti digitali correnti, senza bleed o dorso cartaceo.
4. Conservare una versione modificabile quando disponibile. Salvare i deliverable tramite la skill Library; le immagini generate seguono il salvataggio automatico previsto dal sistema.
5. Consegnare i file richiesti e indicare brevemente formato, margine personale usato e verifiche effettuate. Dichiarare pronto per stampa solo se geometria completa e controlli sono eseguiti. Non promettere accettazione KDP né affermare di aver usato il Print Previewer senza averlo aperto.
