# Rapporto operativo

Adattare l'estensione alle prove. Non usare punteggi pseudo-oggettivi di qualità o conversione.

## Apertura e copertura

Aprire con opportunità principale e tre interventi. Riportare titolo, ASIN, variante, marketplace e data; conteggi effettivi di pagine lette/viste, moduli A+ osservati e recensioni lette. Distinguere campione e revisione completa.

## Concorrenti

| Titolo/autore | Link, formato, edizione | Motivo di inclusione | BSR e relativa classifica, prezzo, valutazioni rilevati | Copertura e limiti |
|---|---|---|---|---|

Indicare query, criteri, numero selezionato e distinzione fra concorrenti diretti e aspirazionali. Non ordinare dati non comparabili o presentare prezzi come permanenti.

## Confronto

| Area | Il tuo libro/scheda: prova | Concorrente: prova | Differenza utile al lettore | Stato e confidenza |
|---|---|---|---|---|

Coprire pubblico/promessa, copertina, descrizione, contenuti/anteprima, A+, autore, prezzo/formato e fiducia. Per A+ confrontare funzione e chiarezza oltre all'estetica. Non dichiarare assente ciò che non è recuperato.

## Voce del lettore

Solo con recensioni testuali lette:

| Bisogno o obiezione | Evidenza e ricorrenze nel campione | Cosa offre/comunica il concorrente | Opportunità per il tuo libro |
|---|---|---|---|

Altrimenti dichiarare la sezione non valutabile, senza stereotipi.

## Modifiche prioritarie

| Priorità/area | Modifica concreta | Prova | Effetto da verificare | Impatto ipotizzato | Confidenza | Sforzo | Test |
|---|---|---|---|---|---|---|---|

Dare prima tre interventi, poi gli altri motivati. Specificare cosa conservare e dipendenze, per esempio verificare l'anteprima prima di aggiungere una promessa.

## Descrizione completa pronta da usare

Consegnare testo italiano definitivo, senza note di analisi, fonti o segnaposto nel testo da copiare. Aggiungere HTML solo se richiesto/utile e verificato. Separare avvertenze sul contenuto. Spiegare brevemente le scelte senza promettere vendite.

## A+ modulo per modulo

Per ciascun modulo fornire:

1. Funzione e decisione sul modulo attuale: conservare, correggere, sostituire.
2. Titolo definitivo.
3. Testo definitivo breve e coerente con il contenuto, distinto dalla descrizione.
4. Brief visivo: soggetto, atmosfera, composizione, gerarchia e leggibilità mobile.
5. Testo alternativo fedele all'immagine proposta, da aggiornare sull'asset finale.
6. Dimensioni/modello solo se verificati per il modulo scelto; altrimenti verificare il gestore prima dell'esportazione.

Non generare immagini automaticamente se non richieste. Non presentare immagini illustrative inventate come documentazione di fatti reali. Non usare moduli per paragoni pubblici con concorrenti o recensioni clienti.

## Altre proposte e piano

Quando sostenuti dalle prove, includere nota autore, brief copertina e interventi editoriali. Distinguere elementi esistenti e sviluppi da realizzare. Verificare vincoli di edizione prima di modifiche ai metadata.

Nei primi sette giorni preparare bozze e verificare comprensione/aspettative con lettori del target. Nei trenta giorni successivi osservare metriche realmente disponibili su periodi comparabili, annotando variazioni di traffico, prezzo e campagne. Non confondere preferenza con acquisto o variazione BSR con conversione.

Elencare ciò che resta non valutabile e il dato necessario a risolverlo. Non chiedere credenziali o screenshot di elementi già verificati. Concludere con una prossima azione concreta.
