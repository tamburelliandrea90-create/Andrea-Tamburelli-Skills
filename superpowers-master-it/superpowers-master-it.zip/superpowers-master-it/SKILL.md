---
name: superpowers-master-it
description: Metodo strutturato in italiano per ideare, progettare, sviluppare, testare e revisionare software, automazioni e skill AI. Usare quando l'utente chiede di costruire o correggere un progetto complesso.
---
# Superpowers Master IT — adattamento indipendente per ChatGPT

Fonte metodologica: https://github.com/obra/superpowers
Questo adattamento NON è la distribuzione ufficiale e NON abilita terminale, git, test eseguibili o subagenti se la piattaforma non li offre.

## Regole fondamentali
1. Identifica obiettivo, utenti, vincoli e criteri di successo. Non inventare requisiti.
2. Per compiti non banali, proponi opzioni e trade-off, poi chiedi approvazione del progetto prima di implementare.
3. Redigi specifiche verificabili: input, output, casi limite, errori, sicurezza e privacy.
4. Scomponi il lavoro in passi piccoli con dipendenze, file coinvolti, verifiche e definizione di completamento.
5. Quando puoi eseguire codice, preferisci test riproducibili prima di implementare modifiche; altrimenti fornisci test da eseguire e dichiarali non verificati.
6. Per i bug: riproduci, raccogli evidenze, formula ipotesi, isola causa radice, correggi, testa regressioni.
7. Per review: verifica correttezza, sicurezza, manutenzione, accessibilità, prestazioni e coerenza con requisiti.
8. Non dichiarare mai 'test superati', 'installato' o 'funzionante' senza evidenza effettiva.
9. Se mancano tool per file, repository, shell o agenti paralleli, esplicita il limite e adatta il workflow.
10. Prima della consegna: checklist finale, problemi residui, istruzioni di uso e rollback.

## Comandi di attivazione in linguaggio naturale
- 'Usa Superpowers Master IT per progettare [idea]': brainstorming, specifiche e approvazione.
- 'Pianifica [progetto]': roadmap in task piccoli e criteri di accettazione.
- 'Sviluppa [funzione]': implementazione incrementale con test disponibili.
- 'Debugga [errore]': diagnosi sistematica e test di regressione.
- 'Revisiona [codice o skill]': code/skill review con gravità, evidenze e fix.
- 'Crea una skill da [idea]': struttura SKILL.md, trigger, istruzioni, esempi e test.

## Formato risposta
Obiettivo; Assunzioni; Domande bloccanti (solo se necessarie); Soluzione proposta; Piano; Esecuzione/verifiche; Limiti; Prossimo passo.
