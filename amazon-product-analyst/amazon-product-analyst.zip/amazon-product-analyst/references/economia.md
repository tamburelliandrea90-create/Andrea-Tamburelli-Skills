# Calcoli economici

Usare valori per unità e una base IVA coerente. Definire ogni variabile, fonte e periodo. Non offrire un parere fiscale: quando il trattamento IVA è incerto, esplicitare il limite del calcolo.

## Prodotti fisici

- Ricavo unitario R: ricavo di vendita sulla base adottata, al netto di sconti a carico del venditore.
- Costi variabili V: acquisto/produzione e tutti i costi incrementali per unità, comprese commissioni, logistica e oneri attesi di reso/assistenza quando stimabili.
- Contributo prima della pubblicità C0 = R − V.
- Costo pubblicitario per vendita A: spesa pubblicitaria / vendite attribuite, con finestra di attribuzione dichiarata; in previsione usarlo solo come ipotesi.
- Contributo dopo pubblicità C1 = C0 − A.
- Punto di pareggio in unità = arrotondamento per eccesso(F / C1), con F costi fissi del periodo e C1 positivo. Con C1 nullo o negativo, nessun pareggio a queste condizioni aumentando il volume.
- Massimo costo pubblicitario teorico per unità prima di costi fissi e profitto = C0. Per una soglia operativa sottrarre quota dei costi fissi e contributo obiettivo; non presentare C0 come budget consigliato.

Non usare una percentuale generica dei resi senza dichiararla ipotetica o documentarne la fonte. Specificare se scorte invendute, immobilizzo e costi di avvio sono inclusi o ancora da stimare. Le commissioni possono avere basi diverse da R: usare la base ufficiale appropriata senza assumere equivalenza automatica.

## Libri KDP

Partire dalla royalty per copia applicabile al formato, marketplace e condizioni specifiche. Se la royalty dichiarata è già al netto di stampa o consegna digitale, non sottrarre nuovamente quei costi. Sottrarre soltanto altri costi variabili effettivamente sostenuti dall'autore e il costo pubblicitario per copia per ottenere il contributo. Trattare editing, copertina e impaginazione come costi fissi quando coerente. Distinguere copie vendute da pagine lette/ricavi di programmi di abbonamento: non convertire automaticamente letture in copie.

## Scenari

Mostrare per ciascuno prezzo, costi, costo pubblicitario ipotizzato e contributo risultante. Utilizzare intervalli giustificati o indicare «esempio di sensibilità, non previsione». Se mancano costi decisivi, mostrare formule o soglie condizionali invece di risultati inventati. Non indicare ricavi mensili senza esplicitare che il volume è ipotetico e non provato dalla ricerca.
