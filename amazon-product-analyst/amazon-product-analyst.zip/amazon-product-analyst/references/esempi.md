# Esempi di utilizzo

Tutti gli importi e i prodotti seguenti sono esempi ipotetici, non risultati di un'analisi già svolta.

## Lavatrice

Richiesta: «Voglio vendere su Amazon.it una lavatrice nuova da 8 kg a 349 €. Analizza i concorrenti e dimmi a quali condizioni avrebbe senso fare una prova».

Chiedere marchio/modello, dimensioni, caratteristiche, costo di acquisto e modalità di consegna/assistenza. Avviare il confronto con modelli equivalenti, separando compatti, ricondizionati e capacità diverse. Studiare recensioni su affidabilità, rumorosità, usabilità e servizio solo se disponibili. Evitare un giudizio favorevole sulla redditività senza costi di trasporto, assistenza e reso. Dare un verdetto condizionale o dati insufficienti quando mancano elementi decisivi.

## Borraccia

Richiesta: «Questo è il link di una borraccia concorrente. Voglio proporne una termica da 750 ml per chi va al lavoro. Ho un prezzo previsto di 24,90 € e un costo di acquisto di 7 €. Cerca concorrenti e differenze utili».

Separare capacità, materiali, isolamento e tipologia di chiusura; non confrontare prodotti diversi soltanto per la parola “borraccia”. Verificare evidenze su perdite, pulizia, ingombro e uso quotidiano. Il solo costo d'acquisto non basta: raccogliere commissioni e logistica prima di concludere sui margini. Non affermare prestazioni o idoneità del prodotto senza documentazione. Proporre un piccolo test con misure legate ai costi effettivi.

## Libro KDP

Richiesta: «Allego il PDF di un libro da colorare steampunk per adulti e il link di un concorrente. Voglio pubblicarlo in cartaceo a 12,90 €. Analizza contenuto, scheda e concorrenti e valuta il potenziale».

Leggere il PDF effettivamente accessibile e dichiarare quanto esaminato. Confrontare target, stile, complessità, formato, contenuti e proposta narrativa; non attribuire contenuti al concorrente non visibili nell'anteprima. Verificare royalty e stampa applicabili invece di usare tariffe della vendita di beni fisici. Distinguere competitività della proposta, economia per copia e domanda osservabile. Se l'utente valuta anche ebook, verificare l'adeguatezza del formato all'uso previsto senza assumere equivalenza con il cartaceo.

## Dati non accessibili

Richiesta: «Controlla tutte le lavatrici di Amazon e dimmi quante copie vende ogni concorrente».

Riformulare il perimetro come campione dichiarato di modelli confrontabili. Non promettere esaustività né inventare vendite. Se nessuna fonte è accessibile, proporre l'analisi di link, estratti o schede forniti; mantenere «Dati insufficienti per un giudizio attendibile» per le conclusioni che dipendono dalla ricerca mancante.
