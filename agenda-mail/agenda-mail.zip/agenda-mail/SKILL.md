---
name: agenda-mail
description: Configurare posta Outlook o Gmail e calendario Outlook o Google Calendar, anche combinati; salvare appuntamenti richiesti dall'utente e predisporre promemoria email 24 ore prima. Usare per configurare Agenda Mail, collegare posta e calendario, aggiungere appuntamenti con email di promemoria o cambiare gli account usati.
---

# Agenda Mail

## Avvio e limiti

Avviare la configurazione alla prima invocazione se manca un profilo verificato. Non dichiarare che installare una skill apra automaticamente una conversazione, esegua OAuth o attivi un servizio in background. Proporre il comando «Configura Agenda Mail» dopo l'installazione. Usare strumenti connessi e un sistema di pianificazione effettivamente disponibile: le istruzioni da sole non inviano email future.

Separare la creazione della skill dalla sua esecuzione: una richiesta di creare o distribuire Agenda Mail non autorizza a riconfigurare l'agenda corrente. Non incorporare account del creatore, autorizzazioni o dati personali nella skill distribuita.

## Configurazione guidata

1. Chiedere insieme le scelte mancanti, con linguaggio semplice:
   - «Per inviare le email usi Outlook oppure Gmail (Google)?»
   - «Per gli appuntamenti usi Calendario Outlook oppure Google Calendar?»
   Consentire tutte le quattro combinazioni. Non trattare la scelta Google come un indirizzo da indovinare.
2. Individuare gli strumenti dei due servizi selezionati e leggere le relative istruzioni. Se assenti, cercare e proporre soltanto i collegamenti mancanti. Fare completare l'accesso attraverso la procedura ufficiale; non chiedere password, codici MFA, token o segreti in chat. Non aggirare richieste di connessione o consenso.
3. Verificare il profilo email collegato e l'elenco dei calendari con letture reali. Se vi sono più account o calendari scrivibili, chiedere quale usare. Non equiparare un calendario condiviso all'account personale.
4. Verificare destinatario e fuso. Proporre come destinatario il proprio indirizzo letto dal profilo; se diverso, farlo indicare e verificare esplicitamente. Usare il fuso IANA dell'utente; chiedere se non noto. Chiarire il caso di eventi senza orario.
5. Riassumere account mittente, destinatario, calendario e fuso; chiedere una sola volta, se non già autorizzato: «Vuoi che salvi gli appuntamenti che mi chiedi e invii a questo indirizzo un'email di promemoria 24 ore prima?» Il consenso riguarda solo promemoria personali, non inviti, inoltri o messaggi ad altri. Una configurazione salvata non sostituisce i permessi della piattaforma.
6. Conservare il profilo nella conversazione e nelle istruzioni persistenti delle automazioni autorizzate. Registrare provider posta, account verificato, destinatario, provider calendario, ID calendario, fuso, anticipo 24h e autorizzazione. Non modificare la skill condivisibile per salvarvi i dati di una persona. Non promettere memoria fra chat se non disponibile: recuperare un profilo già salvato con gli strumenti consentiti o richiedere i soli campi mancanti.
7. Testare la lettura del calendario prima di pianificare. Non creare eventi o inviare email di prova senza una richiesta esplicita. Dichiarare separatamente cosa funziona e cosa è ancora da autorizzare.

## Salvare un appuntamento

- Eseguire solo richieste di appuntamento dell'utente. Non estrarre automaticamente eventi da tutta la casella email: richiedere un ambito esplicito per tale funzione.
- Raccogliere titolo, data, ora e durata/fine; chiedere i dati necessari mancanti. Convertire «domani» nel fuso dell'utente e gestire ore ambigue per cambio d'ora. Per eventi a giornata intera chiedere l'ora del promemoria.
- Prima di creare, cercare duplicati nello stesso calendario con data, titolo e orario. Non modificare un evento simile senza identificazione certa.
- Creare nel calendario selezionato usando lo schema effettivo del connettore. Non aggiungere partecipanti se non richiesti. Salvare ID, occorrenza/serie, inizio con fuso, fine e link restituiti.
- Solo dopo il successo predisporre il promemoria. Una notifica nativa del calendario non equivale a un'email: verificare il canale supportato.
- Se l'evento esiste ma la pianificazione fallisce, dichiarare «Appuntamento salvato; promemoria email non attivo». Non duplicare l'evento per ritentare il promemoria.

## Pianificazione a 24 ore

Leggere le capacità correnti del sistema di automazione e del provider. Non inventare nomi di strumenti, webhook Outlook/Google Calendar, permessi o garanzie di puntualità. Le email devono partire dall'account selezionato, non dal canale email generico di ChatGPT.

Per un singolo evento creato o selezionato nella conversazione interattiva:

1. Calcolare l'istante assoluto `inizio_UTC - 24 ore`, rispettando ora legale e fuso. Non sottrarre semplicemente un giorno all'ora locale nei cambi d'ora.
2. Consultare privatamente i promemoria esistenti per evitare doppioni. Riutilizzare o aggiornare soltanto quelli pertinenti: non cambiare automazioni estranee né aggiungere avvisi extra.
3. Creare un promemoria una tantum con pianificazione esatta se disponibile. Includere nel prompt il profilo verificato, ID evento/calendario/occorrenza, inizio atteso e l'intera procedura di invio sotto riportata, senza dipendere da file locali temporanei. Confermare l'attivazione solo dopo successo dello strumento.
4. Se mancano meno di 24 ore, spiegare che l'anticipo non è più possibile e proporre un avviso immediato; inviarlo solo se già autorizzato per questo caso o dopo la scelta dell'utente.
5. Per serie ricorrenti usare un meccanismo verificato che gestisca ogni occorrenza e il fuso; non fingere che una singola automazione copra tutta la serie. Se necessario proporre il monitoraggio orario qui sotto.

Per tutti gli eventi già esistenti o aggiunti esternamente, attivare un controllo orario soltanto quando l'utente ne richiede il monitoraggio e dopo aver testato accesso e invio disponibili. Usare `condition_watch`, RRULE `FREQ=HOURLY` e il fuso personale, secondo lo schema disponibile. Specificare prima che questo metodo invia circa 24 ore prima (normalmente nella finestra 23–24 ore), non al minuto esatto. Non sostituirlo silenziosamente alla richiesta di un orario preciso. Evitare sovrapposizione con promemoria una tantum già attivi.

Non dichiarare di monitorare il calendario se è stata creata soltanto una scadenza isolata. Gli spostamenti effettuati attraverso la skill devono aggiornare il relativo promemoria; per spostamenti esterni spiegare che una scadenza isolata rilegge l'evento ma non garantisce un nuovo avviso 24h prima. Proporre il monitoraggio orario se serve rilevarli.

## Procedura da includere nei promemoria

- Rileggere dal servizio l'evento/occorrenza aggiornato. Non inviare per eventi eliminati, annullati, rifiutati o già iniziati. Se lettura o connessione fallisce, segnalare il blocco senza inventare dati.
- Per una scadenza isolata verificare che l'inizio coincida con quello atteso; in caso di spostamento non inviare un promemoria con ora obsoleta e segnalare che la scadenza deve essere aggiornata. Non creare altre automazioni durante esecuzioni pianificate se il runtime lo vieta.
- Per il controllo orario leggere una finestra esplicita da adesso a +24h ed espandere le ricorrenze con la vista calendario, seguendo la paginazione. Selezionare gli eventi a 23–24h; per eventi scoperti tardi o controlli saltati usare un avviso di recupero solo se autorizzato nel profilo. Non inviare aggiornamenti quando non c'è nulla da segnalare.
- Deduplicare con provider, ID calendario, ID evento/serie, occorrenza, inizio UTC e tipo `email-24h`. Consultare il registro persistente o i risultati precedenti disponibili e, se utile, le email inviate. Se non esiste una fonte di deduplicazione affidabile, dichiararlo e non promettere assenza di duplicati.
- Comporre in testo semplice: oggetto «Promemoria appuntamento: [titolo]»; corpo con titolo, data completa, ora nel fuso dell'utente, luogo se presente e link verificato restituito dal calendario. Non copiare note riservate non necessarie né aggiungere destinatari in CC/BCC.
- Inviare tramite il provider di posta selezionato al solo destinatario autorizzato. Registrare il successo solo dopo conferma, conservando identificativo messaggio se disponibile. Su esito incerto verificare i messaggi inviati prima di ritentare; non ritentare ciecamente.
- Distinguere sempre «pianificato», «inviato» e «consegna non verificata». Se l'email fallisce, comunicarlo in chat; non dichiararla inviata.

## Modifiche e disattivazione

Aggiornare ora, calendario, destinatario o provider solo su richiesta. Per un nuovo destinatario verificare identità e autorizzazione. Non interrompere altre automazioni dell'utente. Alla richiesta di sospensione disabilitare i soli promemoria di Agenda Mail e confermare i risultati effettivi. Non eliminare gli appuntamenti quando si disattivano i promemoria.

## Risposta finale all'utente

Usare un riepilogo breve: account posta, calendario, appuntamento salvato e stato reale dell'email. Fornire il link dell'evento se disponibile. Spiegare che il collegamento fra posta e calendario è un flusso gestito dalla skill con i connettori autorizzati, non una sincronizzazione completa fra account.
