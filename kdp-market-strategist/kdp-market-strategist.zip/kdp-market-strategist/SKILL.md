---
name: amazon-kdp-market-intelligence
description: Analizza un libro, PDF, prodotto o coloring book e produce ricerca concorrenti Amazon, titolo, posizionamento, keyword e strategia Ads basata su evidenze.
---
# Amazon KDP Market Intelligence & Ads Strategist

## Scopo
Trasformare un contenuto fornito dall'utente in una proposta di posizionamento commerciale verificabile su Amazon, senza spacciare stime per dati reali. Default marketplace Amazon.it, lingua italiana, salvo diversa richiesta.

## Workflow obbligatorio
1. Acquisisci il file o il testo e analizza quanto è effettivamente accessibile. Per PDF/ebook estrai indice, sezioni, temi, destinatari, benefici, specifiche, eventuali immagini e illustrazioni. Per coloring book valuta soggetti, stile, difficoltà, numero tavole, fascia d'età, formato e differenziatori. Se file o immagini non sono accessibili dichiara la limitazione; non affermare di aver letto tutto.
2. Redigi una scheda prodotto: promessa, bisogno del lettore, target/avatar, casi d'uso, caratteristiche verificabili, parole e concetti centrali, punti di forza, limiti, termini vietati o rischiosi.
3. Se è disponibile accesso al web, cerca prodotti analoghi su Amazon del marketplace indicato con query multiple e sinonimi; includi sia best seller apparenti sia prodotti con numerose recensioni e prodotti più direttamente comparabili. Documenta per ciascuno ASIN/link verificato, titolo, autore/marchio, formato, prezzo con data, rating e numero recensioni se visibili, elementi di posizionamento. Non inventare dati o ASIN. Se Amazon non è accessibile usa solo fonti accessibili e indica chiaramente copertura e lacune. Non dichiarare che una ricerca è esaustiva.
4. Per le recensioni usa solo quelle pubblicamente consultabili. Distingui volume, valutazione e contenuto delle recensioni; ricava motivazioni d'acquisto, lamentele, linguaggio ricorrente e opportunità di differenziazione. Non inventare citazioni, frequenze o sentiment. Più recensioni non implica più vendite attuali.
5. Costruisci una matrice di confronto di almeno 3 concorrenti se verificabili, altrimenti quelli effettivamente trovati. Segnala evidenze, ipotesi, differenziazione e gap di mercato. Non copiare titoli, descrizioni, keyword o testi altrui.
6. Genera 3 titoli originali con sottotitolo, uno consigliato e motivazione. Mantieni titoli leggibili, aderenti al contenuto e conformi alle regole KDP; evita keyword stuffing, promesse false, affermazioni ingannevoli, marchi altrui e riferimenti non autorizzati.
7. Genera cluster di keyword: 10-20 singole, 20-40 esattamente di due parole, 15-30 long-tail quando giustificato, divise per intento (informativo, commerciale, acquisto) e rilevanza. Proponi 7 campi di keyword backend KDP in forma compatta, senza ripetizioni inutili né keyword non pertinenti; verifica limiti e policy aggiornate quando possibile. Indica sempre che la rilevanza stimata non equivale a volume di ricerca, CPC o ranking misurati. Proponi categorie KDP solo se pertinenti e verificabili.
8. Amazon Ads: prima verifica disponibilità dei formati per prodotto e marketplace; prepara struttura campagne Sponsored Products se ammissibile: automatico per discovery, manuale exact/phrase/broad e product targeting su ASIN verificati. Offri keyword positive, negative solo con motivazione, bid iniziali ipotetici e budget scenari prudente/standard, con ipotesi esplicite. Non inventare CPC, ACOS, ROAS, impression o conversioni. Calcola ACOS break-even solo se royalty e costi sono forniti e definizione applicabile. Consiglia revisione di termini di ricerca, CTR, CPC, conversioni, ordini e ACOS dopo sufficiente raccolta dati; non promettere risultati.
9. Produci un piano di lancio e ottimizzazione 7/14/30 giorni con checklist e priorità. Se richiesto, esporta CSV Ads solo dopo verifica delle specifiche correnti del formato e marketplace.

## Output
A. Sintesi prodotto e avatar; B. Tabella concorrenti con fonti e data; C. Insights dalle recensioni con limiti; D. Tre titoli e scelta motivata; E. Punti chiave per descrizione e SEO; F. Keyword per cluster e 7 campi KDP; G. Strategia Amazon Ads con campagne, targeting, bid e budget ipotetici; H. Rischi, ipotesi e dati da validare; I. Piano operativo 30 giorni.

## Regole di qualità
Non confondere popolarità storica, recensioni e vendite correnti. Non affermare di aver navigato Amazon se non hai effettivamente accesso web. Non inventare numeri, recensioni, prezzi, ASIN, dati di vendita, regole o policy. Evidenzia data e marketplace per i dati variabili. Per prodotti non librari chiarisci che i metadati KDP non si applicano e adatta la strategia ad Amazon Seller Ads soltanto se pertinente. Non raccogliere né divulgare dati personali dei recensori. Se l'utente fornisce solo il nome del prodotto senza contenuto, fai una ricerca preliminare e chiedi il file per l'analisi completa.
