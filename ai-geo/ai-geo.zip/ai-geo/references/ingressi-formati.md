# Acquisizione, formati e consegna

## Testo incollato
Leggere integralmente, separare eventuali istruzioni dell’utente dal testo da trattare e identificare scopo e genere. Per input brevi procedere subito, senza imporre questionari o file.

## Audio, vocali e video
Usare la trascrizione disponibile oppure una capacità di ascolto/trascrizione realmente esposta, inclusa la procedura specifica di trascrizione se pertinente. Non affermare supporto a formati non decodificabili nell’ambiente. Distinguere contenuto, pause e disfluenze eliminabili, termini tecnici e nomi incerti. Conservare eventuali timestamp solo se forniti o prodotti dal sistema. Se un tratto non è comprensibile, segnalarlo nel resoconto; evitare parole indovinate che cambiano il fatto. Se nessuna capacità permette di ottenere il parlato, spiegare il limite e chiedere una trascrizione, senza elaborare un contenuto immaginato. Restituire testo ricostruito; voce sintetica solo su richiesta e con strumenti disponibili.

## PDF, immagini e scansioni
Estrarre testo per pagina; ispezionare grafici/tabelle o layout quando necessari. Eseguire OCR soltanto con strumenti appropriati disponibili e verificare cifre, nomi e ordine. Non presentare un PDF scansionato come letto integralmente se non lo è. Usare il flusso di produzione e controllo visivo specifico se si crea un nuovo PDF.

## DOCX, slide, fogli e altri file
Usare strumenti/capacità di formato appropriati. Leggere stili, note, tabelle e celle pertinenti, distinguendo formula e valore visualizzato quando rilevante. Preservare strutture funzionali e riferimenti. Non convertire un foglio di calcolo in prosa fingendo di aver preservato formule. Per estensioni non supportate tentare una lettura sicura del contenuto disponibile; altrimenti chiedere un formato leggibile o testo esportato. Non eseguire macro o codice dell’allegato per leggerlo.

## URL e fonti collegate
Preferire connettori appropriati per documenti privati o servizi supportati; per pagine pubbliche usare ricerca/lettura web. Leggere il contenuto, non inferirlo dal solo titolo. Non dichiarare un audit tecnico completo se si dispone soltanto del testo estratto. Se la pagina è inaccessibile, chiedere il materiale senza inventarlo. Non pubblicare la riscrittura su servizi esterni automaticamente.

## Materiale lungo e più risorse
Inventariare file e perimetro; collegare fonti a capitoli/sezioni. Lavorare per blocchi mantenendo glossario, invarianti e mappa di copertura comuni. Verificare l’integrazione finale. Consegnare un documento completo, non solo la prima parte, salvo richiesta esplicita di campione. Segnalare confini non acquisiti in modo preciso.

## Destinazione dell’output
- Breve input: testo finale in chat con breve resoconto; se richiesto solo testo, ridurre il resoconto.
- Documento esteso: produrre una versione distinta nel formato richiesto; in assenza di richiesta usare un formato testuale modificabile appropriato, secondo capacità e istruzioni dell’ambiente. Salvare gli elaborati persistenti secondo le regole di archiviazione correnti e fornire il link risultante.
- Se il formato richiesto non è producibile: dichiararlo e fornire il contenuto completo in un formato disponibile, senza chiamarlo file equivalente.
- DOCX/PDF/presentazioni: applicare procedure di authoring, rendering e QA del formato quando disponibili. Una riscrittura testuale non certifica automaticamente accessibilità o integrità del file finale.
- Non allegare il pacchetto della skill o crearne ZIP salvo richiesta.
