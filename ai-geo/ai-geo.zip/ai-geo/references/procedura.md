# Procedura completa e matrice dei metodi

Fonte di riferimento: ricerca-geo.md, 7 novembre 2026; documento Library originale libfile_5fd224bc22c08191b556d70ef2ef411f. Metodi applicativi proposti nel rapporto, non algoritmo ufficiale o effetti validati universalmente. Conservare la separazione fra evidenza ufficiale, esperimento, correlazione e testimonianza.

## Inventario prima della riscrittura
Creare internamente quattro registri:
1. Provenienza: ID passaggio, pagina/sezione/slide/timestamp, argomento, contenuto.
2. Invarianti: fatto, numero, unità, data, condizione, negazione, attribuzione.
3. Conoscenze: nozione, regola, procedura, esempio, esercizio se presente, limite.
4. Decisioni: mantenuto, spostato, chiarito, corretto con prova, rimosso con ragione, dato mancante.
Per scansioni o audio, conservare le incertezze di estrazione e correggerle soltanto con prova. Non creare riferimenti temporali o di pagina inesistenti.

## Matrice di copertura
Per ogni risorsa valutare tutte le righe. Stati: A=applicato al risultato; NA=non pertinente; E=richiede dati/intervento esterno; NV=non verificabile con gli strumenti/input. L’utente può richiedere la matrice completa; di default mostrarne solo le conseguenze utili.

| Metodo | Azione concreta | Controllo | Riferimento rapporto |
|---|---|---|---|
| 1 Obiettivo e destinazione | Definire pubblico, genere, uso e risultato; ipotesi minime dichiarate | La riscrittura serve lo stesso scopo concordato | §5.1 |
| 2 Domande e decisioni | Mappare bisogni, risposte e lacune; accorpare varianti | Ogni tema essenziale ha una destinazione | §5.2 |
| 3 Risposta e approfondimento | Usare struttura leggibile, titoli informativi, risposte dirette dove opportune | Il lettore trova risposta e condizioni | §5.3 |
| 4 Contesto ed entità | Esplicitare soggetti, definire acronimi, indicare unità/periodi/mercati | Il passaggio isolato non cambia significato | §5.4 |
| 5 Claim e prove | Mappare fatti a fonti; distinguere opinioni e ipotesi | Ogni fonte sostiene il fatto associato | §5.5 |
| 6 Valore originale | Valorizzare contributi realmente presenti; proporre raccolte dati se assenti | Nessuna esperienza o ricerca inventata | §5.6 |
| 7 Procedure/confronti | Riordinare prerequisiti, passi e verifiche; confrontare criteri omogenei | Azione praticabile, senza dati presunti | §5.7 |
| 8 Versioni/correzioni | Preservare data e stato; identificare fatti volatili | Nessuna falsa freschezza | §5.8 |
| 9 Estrazione/accessibilità | Controllare OCR, ordine, tabelle, formule, note, descrizioni informative | Significato visivo e testo estratto compatibili | §5.9 |
| 10 Genere | Adattare il formato a tutorial, corso, report, narrativa o scheda | Nessuna FAQ imposta alla narrativa | §5.10 |
| 11 Reperibilità tecnica | Verificare URL/accessi/header solo se disponibili | Prova separata da indicizzazione e citazione | §6.1 |
| 12 Pagina di riferimento | Preparare metadati/sintesi/link quando pertinenti | Versioni coerenti; pubblicazione non simulata | §6.2 |
| 13 Markup | Generare solo tipo pertinente, dati veri, sintassi validata e regole attuali | Corrispondenza col visibile; altrimenti E/NA | §6.3 |
| 14 Distribuzione | Proporre contributi autentici pertinenti al pubblico | Nessuna menzione o autorità inventata | §6.4 |
| 15 Lingua/locale | Preservare lingua, valuta, mercato e sedi reali | Nessuna sede o traduzione incoerente | §6.5 |
| 16 Quattro prove | Distinguere comprensione, accesso, scoperta, uso corretto | Dichiarare solo prove realmente eseguite | §7.1 |
| 17 Campione prompt | Proporre domande con risposte attese e repliche | Prompt e condizioni registrabili | §7.2 |
| 18 Indicatori | Distinguere menzione, URL, correttezza, visite, conversione | Denominatori espliciti; non inventare baseline | §7.3 |
| 19 Esperimento | Proporre baseline, confronto, registro cambi e limiti | Nessuna causalità inferita da una sola risposta | §7.4 |

## Riorganizzazione approfondita
1. Progettare l’architettura secondo il risultato: sintesi o risposta iniziale se utile, definizioni, sviluppo, procedure/confronti, limiti e azione finale pertinente.
2. Riposizionare contenuti dispersi; eliminare duplicazioni senza perdere dettagli unici.
3. Sostituire riferimenti ambigui con soggetti espliciti, senza inventare ciò a cui il riferimento potrebbe alludere.
4. Mantenere una terminologia coerente con sinonimi naturali, non una lista di keyword.
5. Integrare fonti di dominio reali; identificare le opinioni come tali. Non mantenere come fatto una promessa impossibile solo per “fedeltà”. Segnalarne la revisione.
6. Se il compito richiede generare nuovo materiale dal corso, ricavare contenuti dalle nozioni disponibili; marcare esempi aggiunti come originali/ipotetici. Preservare riferimenti alle lezioni nella mappa o nelle note.
7. Consegnare il testo completo; non sostituirlo con una scaletta o con l’analisi dei metodi.

## Corso trasformato in elaborato
Organizzare prima nozioni, regole, procedure, esempi ed esercizi già presenti. Non inventare esercizi “del corso”. Se aggiunti dall’assistente, etichettarli come nuovi. Se l’elaborato è applicativo, privilegiare la procedura e il caso; se didattico, obiettivi, prerequisiti, spiegazione, esempio e verifica. Riferirsi a pagina/sezione originale quando disponibile.

## Interpretazioni da escludere
- Un miglior testo fornito al modello non prova scoperta spontanea.
- “Fino al 40%” nello studio GEO non è aumento atteso di traffico/vendite.
- Menzioni, citazioni e ripresa delle informazioni sono eventi distinti.
- Le correlazioni dei brand non convalidano menzioni comprate, spam o false autorità.
- Il rapporto contiene disallineamenti fra documentazione Google su reporting: verificare attualmente le funzioni, senza scegliere arbitrariamente una versione come universale.
- Nessun numero fisso di paragrafi, parole, FAQ, citazioni o aggiornamenti è obbligatorio.
