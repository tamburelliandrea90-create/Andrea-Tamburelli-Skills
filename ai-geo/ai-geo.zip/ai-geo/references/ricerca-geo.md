# GEO AI: ricerca critica e metodi applicabili ai documenti

Data di ricognizione: **7 novembre 2026**. Lingua del rapporto: italiano.
Ambito: visibilità e corretto utilizzo dei contenuti in risposte AI con ricerca web; leggibilità di PDF, Word, presentazioni e contenuti testuali; distinzione dai sistemi RAG privati.
Fonti selezionate: **36**, comprendenti documentazione ufficiale, sei studi accademici, analisi originali di operatori, blog specialistici e sei discussioni Reddit. Consultate anche versioni PDF e pagine equivalenti: non contate come nuove ricerche indipendenti.
Product: Work. Execution_location: Cloud. Audit_mode: parallel-subagents. Capabilities_used: ricerca web, lettura di pagine e PDF pubblici, analisi di fonti, file locali, verifiche incrociate.

## Indice

- [1. Come usare questo rapporto](#1-come-usare-questo-rapporto)
  - [1.1 Livelli di evidenza](#11-livelli-di-evidenza)
  - [1.2 Quattro contesti diversi](#12-quattro-contesti-diversi)
- [2. Cosa stabiliscono le fonti ufficiali](#2-cosa-stabiliscono-le-fonti-ufficiali)
  - [2.1 Google: fondamentali SEO e contenuto utile](#21-google-fondamentali-seo-e-contenuto-utile)
  - [2.2 Microsoft: struttura e prove utilizzabili](#22-microsoft-struttura-e-prove-utilizzabili)
  - [2.3 I crawler svolgono ruoli diversi](#23-i-crawler-svolgono-ruoli-diversi)
  - [2.4 PDF e altri formati](#24-pdf-e-altri-formati)
- [3. Cosa mostrano gli studi accademici](#3-cosa-mostrano-gli-studi-accademici)
  - [3.1 GEO originale: risultato sperimentale, non promessa commerciale](#31-geo-originale-risultato-sperimentale-non-promessa-commerciale)
  - [3.2 SAGEO Arena: controllare tutte le fasi](#32-sageo-arena-controllare-tutte-le-fasi)
  - [3.3 Differenze fra motori, lingue e fonti](#33-differenze-fra-motori-lingue-e-fonti)
  - [3.4 Una citazione può sostenere male un’affermazione](#34-una-citazione-può-sostenere-male-unaffermazione)
  - [3.5 Selezione e assorbimento: proposta esplorativa](#35-selezione-e-assorbimento-proposta-esplorativa)
  - [3.6 LIVE-GEO: anche gli URL forniti non sono scoperta spontanea](#36-live-geo-anche-gli-url-forniti-non-sono-scoperta-spontanea)
- [4. Industria, blog e Reddit: risultati da interpretare](#4-industria-blog-e-reddit-risultati-da-interpretare)
  - [4.1 Correlazioni di brand](#41-correlazioni-di-brand)
  - [4.2 Menzioni, citazioni e stabilità](#42-menzioni-citazioni-e-stabilità)
  - [4.3 Locale e business](#43-locale-e-business)
  - [4.4 Sei discussioni Reddit](#44-sei-discussioni-reddit)
- [5. Metodi per contenuto e documenti](#5-metodi-per-contenuto-e-documenti)
  - [5.1 Metodo 1: definire obiettivo e destinazione](#51-metodo-1-definire-obiettivo-e-destinazione)
  - [5.2 Metodo 2: mappare domande e decisioni](#52-metodo-2-mappare-domande-e-decisioni)
  - [5.3 Metodo 3: risposta chiara e approfondimento](#53-metodo-3-risposta-chiara-e-approfondimento)
  - [5.4 Metodo 4: contesto esplicito e identità coerente](#54-metodo-4-contesto-esplicito-e-identità-coerente)
  - [5.5 Metodo 5: registro delle affermazioni e delle prove](#55-metodo-5-registro-delle-affermazioni-e-delle-prove)
  - [5.6 Metodo 6: aggiungere valore originale documentato](#56-metodo-6-aggiungere-valore-originale-documentato)
  - [5.7 Metodo 7: procedure e confronti utilizzabili](#57-metodo-7-procedure-e-confronti-utilizzabili)
  - [5.8 Metodo 8: revisione, versioni e correzioni](#58-metodo-8-revisione-versioni-e-correzioni)
  - [5.9 Metodo 9: estrazione e accessibilità del file](#59-metodo-9-estrazione-e-accessibilità-del-file)
  - [5.10 Metodo 10: adattare il metodo al genere](#510-metodo-10-adattare-il-metodo-al-genere)
- [6. Metodi per pubblicazione e reputazione](#6-metodi-per-pubblicazione-e-reputazione)
  - [6.1 Metodo 11: verificare la reperibilità tecnica](#61-metodo-11-verificare-la-reperibilità-tecnica)
  - [6.2 Metodo 12: pagina pubblica di riferimento e archivio coerente](#62-metodo-12-pagina-pubblica-di-riferimento-e-archivio-coerente)
  - [6.3 Metodo 13: markup pertinente e validato](#63-metodo-13-markup-pertinente-e-validato)
  - [6.4 Metodo 14: presenza editoriale esterna autentica](#64-metodo-14-presenza-editoriale-esterna-autentica)
  - [6.5 Metodo 15: mercati, lingue e attività locali](#65-metodo-15-mercati-lingue-e-attività-locali)
- [7. Metodi per verifica e misurazione](#7-metodi-per-verifica-e-misurazione)
  - [7.1 Metodo 16: quattro prove con esiti separati](#71-metodo-16-quattro-prove-con-esiti-separati)
  - [7.2 Metodo 17: campione di prompt e registro delle osservazioni](#72-metodo-17-campione-di-prompt-e-registro-delle-osservazioni)
  - [7.3 Metodo 18: distinguere indicatori e denominatori](#73-metodo-18-distinguere-indicatori-e-denominatori)
  - [7.4 Metodo 19: sperimentare senza attribuire tutto alla riscrittura](#74-metodo-19-sperimentare-senza-attribuire-tutto-alla-riscrittura)
  - [7.5 Strumenti ufficiali e cambiamenti recenti](#75-strumenti-ufficiali-e-cambiamenti-recenti)
- [8. Tecniche opzionali e cose da non confondere](#8-tecniche-opzionali-e-cose-da-non-confondere)
  - [8.1 llms.txt e Markdown](#81-llmstxt-e-markdown)
  - [8.2 RAG e segmentazione dei documenti](#82-rag-e-segmentazione-dei-documenti)
  - [8.3 Tabella dei claim da evitare](#83-tabella-dei-claim-da-evitare)
- [9. Modelli pronti da applicare](#9-modelli-pronti-da-applicare)
  - [9.1 Scheda di lavoro per qualsiasi documento](#91-scheda-di-lavoro-per-qualsiasi-documento)
  - [9.2 Prompt di analisi e riscrittura](#92-prompt-di-analisi-e-riscrittura)
  - [9.3 Esempio applicato a una guida](#93-esempio-applicato-a-una-guida)
  - [9.4 Checklist finale](#94-checklist-finale)
- [10. Priorità, limiti e controlli completati](#10-priorità-limiti-e-controlli-completati)
  - [10.1 Ordine di lavoro proposto](#101-ordine-di-lavoro-proposto)
  - [10.2 Limiti della ricerca](#102-limiti-della-ricerca)
  - [10.3 Controlli completati](#103-controlli-completati)
- [11. Fonti e documenti originali](#11-fonti-e-documenti-originali)
  - [11.1 PDF accademici e documento di esempio](#111-pdf-accademici-e-documento-di-esempio)

## 1. Come usare questo rapporto

### 1.1 Livelli di evidenza

- **Documentato dal fornitore:** descrive uno specifico prodotto e le sue condizioni dichiarate. Non estendere automaticamente a tutti i motori.
- **Sperimentale:** risultato di un disegno identificabile; leggere campione, metrica, confronto e limiti.
- **Osservazionale:** relazione fra variabili, senza dimostrazione della direzione causale.
- **Testimonianza:** esperienza o opinione della comunità; utile per formulare domande, insufficiente come prova.
- **Proposta operativa:** procedura originale di questo rapporto per organizzare il lavoro. Non è un algoritmo ufficiale o un metodo validato in ogni contesto.

Le istruzioni nelle sezioni 5-9 sono **proposte operative**: rendono concreti i principi citati, con controlli osservabili. I numeri suggeriti per un test sono scelte di progetto, non soglie dei motori. Nessuna procedura garantisce citazioni, traffico o vendite. Le schede delle fonti restano separate dalle applicazioni proposte.

### 1.2 Quattro contesti diversi

| Contesto | Obiettivo verificabile | Cosa non dimostra da solo |
|---|---|---|
| Documento caricato in una chat | Recuperare e spiegare correttamente il contenuto fornito | Scoperta sul web o apprendimento permanente |
| Base documentale RAG privata | Trovare il passaggio giusto e rispondere con prove | Visibilità nei motori pubblici |
| Documento o pagina pubblicati | Rendere possibile scoperta e consultazione | Selezione garantita come fonte |
| Risposte AI con ricerca | Osservare citazioni e rappresentazione del contenuto | Clic, acquisti o causalità di una modifica |

La separazione fra ricerca e addestramento è esplicita nei controlli OpenAI. La ricerca RAG di Anthropic tratta invece un indice documentale controllato. Sono contesti da misurare separatamente. [OpenAI-Bot (consultato 2026/11)]; [Anthropic-RAG (2024/09)].

## 2. Cosa stabiliscono le fonti ufficiali

### 2.1 Google: fondamentali SEO e contenuto utile

Google collega l’idoneità nelle risposte della Ricerca a indicizzazione, possibilità di mostrare snippet e regole ordinarie. Non promette inclusione. La guida più recente rifiuta una lunghezza ideale, microframmentazione obbligatoria, markup AI speciale e menzioni artificiali. [Google-AI (2025/12), How to appear]; [Google-Guida (2026/07), Avoid common pitfalls].

```text
There's no ideal page length.

Non esiste una lunghezza ideale della pagina.
```
[Google-Guida (2026/07), Avoid common pitfalls]

Originalità, competenza dimostrabile, scopo del contenuto e trasparenza dell’autore sono criteri di autovalutazione. E-E-A-T non è presentato come singolo fattore di ranking né come certificazione da ottenere. [Google-Qualita (2026/10), Self-assess / E-E-A-T].

### 2.2 Microsoft: struttura e prove utilizzabili

La guida Microsoft suggerisce titoli descrittivi, domande pertinenti, liste, confronti e dati supportati. Il testo precisa che la selezione non è garantita. È una guida del fornitore, non una prova che ogni FAQ migliori ogni risposta AI. [Microsoft-Contenuti (2025/10), Structure / conclusion].

```text
nothing guarantees selection

nulla garantisce la selezione
```
[Microsoft-Contenuti (2025/10), conclusion]

### 2.3 I crawler svolgono ruoli diversi

| Operatore | Ricerca | Possibile training | Consultazione su richiesta |
|---|---|---|---|
| OpenAI | OAI-SearchBot | GPTBot | ChatGPT-User |
| Anthropic | Claude-SearchBot | ClaudeBot | Claude-User |
| Perplexity | PerplexityBot | Non è il ruolo dichiarato di PerplexityBot | Perplexity-User |

Non dedurre il ruolo dal solo termine “bot”. Verificare anche CDN, firewall e identità delle richieste secondo la documentazione del singolo operatore. I fetch avviati dall’utente possono avere regole diverse dal crawling automatico. [OpenAI-Bot (consultato 2026/11)]; [Anthropic-Bot (consultato 2026/11)]; [Perplexity-Bot (consultato 2026/11)].

### 2.4 PDF e altri formati

Google elenca PDF, DOCX, PPTX, EPUB e vari formati testuali fra i formati indicizzabili; questo non attesta che un file specifico sia stato acquisito. W3C descrive come controllare l’ordine logico dei PDF: il beneficio documentato riguarda l’accessibilità, non un incremento di citazioni AI. [Google-File (2026/02), Supported encoded file types]; [W3C-PDF (consultato 2026/11), Description / Tests].

## 3. Cosa mostrano gli studi accademici

### 3.1 GEO originale: risultato sperimentale, non promessa commerciale

GEO-bench comprende 10.000 query. Le prove valutano riscritture con fonti preselezionate e metriche di presenza nell’output. L’abstract riferisce incrementi fino a circa il 40%; non sono incrementi di traffico o vendite. Fonti, statistiche, citazioni testuali e fluidità hanno esiti differenti per dominio. Il test Perplexity dell’appendice usa 200 casi con file forniti al sistema. [GEO-KDD (2024/06), §§3-4, §9, appendix C.1].

```text
we didn’t evaluate how GEO methods affect search rankings

non abbiamo valutato l’effetto dei metodi GEO sui posizionamenti di ricerca
```
[GEO-KDD (2024/06), §9]

**Conseguenza metodologica proposta:** separare la qualità del testo dopo il recupero dalla probabilità che quel testo venga prima trovato.

### 3.2 SAGEO Arena: controllare tutte le fasi

Il benchmark conserva retrieval, reranking e generazione su 2.700 query e 171.003 documenti. Alcune ottimizzazioni migliorano una fase e peggiorano le precedenti. La struttura aiuta in alcune configurazioni, ma il benchmark non replica integralmente i motori commerciali. [SAGEO-KDD (2026/08), §3 e appendix D].

**Conseguenza metodologica proposta:** non giudicare la riscrittura soltanto chiedendo a un modello di scegliere fra testi già allegati.

### 3.3 Differenze fra motori, lingue e fonti

Lo studio di Toronto confronta servizi AI e ricerca tradizionale, verticali, parafrasi e lingue con dati dell’agosto 2025. Rileva differenze nel mix Brand/Earned/Social e nella freschezza delle fonti. L’agenda pratica degli autori è interpretativa: non dimostra causalmente che una campagna PR produca nuove citazioni. [Toronto-GEO (2025/09), §§4-7].

**Conseguenza metodologica proposta:** segmentare misurazioni per lingua, paese, intento e prodotto.

### 3.4 Una citazione può sostenere male un’affermazione

L’audit umano di Stanford del 2023 riporta il 51,5% delle frasi pienamente supportate e il 74,5% delle citazioni coerenti con la frase associata nei sistemi allora valutati. Sono dati storici, non prestazioni attuali dei prodotti. [Stanford-Verifica (2023/12), abstract].

**Conseguenza metodologica proposta:** controllare correttezza e uso della fonte, oltre al conteggio delle citazioni.

### 3.5 Selezione e assorbimento: proposta esplorativa

Il preprint sull’assorbimento considera 602 prompt e distingue fonte selezionata da contenuto effettivamente ripreso. Il suo indice di influenza è un proxy osservazionale. Parte delle verifiche confermative e sperimentali è proposta futura; i metadati degli autori risultano discordanti con l’HTML. Non lo uso per prescrivere formule universali. [Assorbimento (2026/04), Measurement framework / Threats to validity].

### 3.6 LIVE-GEO: anche gli URL forniti non sono scoperta spontanea

Il preprint del 31 ottobre 2026 pubblica pagine di 80 brand fittizi, 18 famiglie e cinque strategie, poi fornisce URL ai valutatori. Rileva differenze fra motori e sensibilità all’ordine dei candidati. Il verificatore numerico segnala riscritture problematiche; non sostituisce il controllo umano. [LIVE-GEO (2026/10), §§3-4].

**Conseguenza metodologica proposta:** verificare che la riscrittura conservi fatti e quantità, e non confondere accesso a URL suggeriti con acquisizione organica.

## 4. Industria, blog e Reddit: risultati da interpretare

### 4.1 Correlazioni di brand

Ahrefs analizza circa 75.000 brand selezionati con filtri di forza del dominio e ricerca del nome. Nel primo studio le menzioni web correlano con le menzioni AI Overviews (0,664), più dei backlink (0,218). Il 26% senza menzioni è escluso dall’analisi successiva. Sono associazioni su un campione selezionato, non effetti causali. [Ahrefs-Menzioni (2025/05), Methodology / takeaways].

L’estensione multipiattaforma osserva correlazioni alte con menzioni YouTube e web, ma usa pool di domande non identici per tutti i sistemi. Non dimostra che pubblicare un video produca un incremento prestabilito. [Ahrefs-Multi (2025/12), Methodology].

**Proposta:** cercare riconoscimenti editoriali pertinenti e misurare risultati reali, anziché acquistare menzioni per riprodurre una correlazione.

### 4.2 Menzioni, citazioni e stabilità

Semrush distingue dominio citato e brand nominato in 3.981 apparizioni, 115 prompt e 14 paesi. Il corpo indica 61,7% citation-only, 13,2% entrambi e 25,1% mention-only. Il titolo usa un denominatore ambiguo: il 61,7% non va ripetuto automaticamente come quota di tutte le citazioni. [Semrush-Ghost (2026/06), findings / methodology].

AirOps riferisce oltre 45.000 citazioni da 800 query ripetute, con forte variabilità. Non specifica completamente versioni, finestre e numero di run nel passaggio metodologico consultato. [AirOps-Drift (2025/09), Scope of Study].

**Proposta:** registrare separatamente brand nominato, link citato, entrambi, e frequenza nelle repliche.

### 4.3 Locale e business

Yext studia 6,8 milioni di citazioni in un contesto di sedi e quattro industrie, luglio-agosto 2025. “Brand-managed” comprende listing esterni: il suo 86% non significa 86% di citazioni a siti proprietari, né quota di tutto il web. [Yext-Locale (2025/10), About this research].

Ahrefs riferisce sul proprio sito 0,5% delle visite e 12,1% delle iscrizioni da AI search in trenta giorni. Il dato riguarda un singolo sito B2B, senza prova di generalizzabilità; iscrizioni non equivalgono a ricavi. [Ahrefs-Conversioni (2025/06), traffic / signups].

**Proposta:** misurare separatamente qualità dei dati locali, visite attribuibili, contatti qualificati e acquisti.

### 4.4 Sei discussioni Reddit

Questo campione mappa dubbi e ipotesi; non rappresenta l’intera comunità. Due thread condividono lo stesso autore e rilanciano studi commerciali: non sono osservatori indipendenti.

| Discussione | Cosa emerge | Come utilizzarla |
|---|---|---|
| Esperienze llms.txt, 2025 | Richiesta di risultati, testimonianze contrastanti su richieste ai file | Domandare log e definizione di successo; non elevare un commento storico a fatto attuale |
| Analisi Ahrefs rilanciata, 2026 | Dibattito fra utilizzo osservato, adozione futura e costo opportunità | Non confondere richieste HTTP con citazioni |
| Test Otterly rilanciato, 2026 | Discussione su visite bot e pressione commerciale | Cercare l’originale prima di adottarne le cifre |
| Markdown per agenti | Mescolanza fra documentazione coding e ricerca consumer | Specificare il tipo di agente e compito |
| Domande nei titoli | Affermazioni su intervalli di caratteri; originale LinkedIn non verificato | Nessun optimum universale ricavabile dal thread |
| Checklist e prove | Richiesta di distinguere guida ufficiale da esperienze individuali | Rendere sempre espliciti piattaforma e metodo di misura |

Fonti delle righe, nell’ordine: [Reddit-Esperienze (2025/05 indicizzato)]; [Reddit-Ahrefs (2026/06 indicizzato)]; [Reddit-Otterly (2026/04 indicizzato)]; [Reddit-Markdown (consultato 2026/11)]; [Reddit-FAQ (2026/04 indicizzato)]; [Reddit-Prove (2026/10 indicizzato)]. Date relative e indicizzate non sempre coincidono: non ricostruisco giorni esatti non verificati. Non uso le cifre rilanciate come risultati tecnici indipendenti.

## 5. Metodi per contenuto e documenti

Le procedure seguenti sono **proposte applicative originali**. I riferimenti indicano il principio di partenza, non una validazione di ogni passaggio. Usarle con il tipo di testo, il pubblico e il contesto di pubblicazione reali.

### 5.1 Metodo 1: definire obiettivo e destinazione

**Scopo:** stabilire cosa significa riuscire prima di riscrivere.

1. Identificare formato, pubblico, lingua, paese e data di validità.
2. Scegliere un esito: spiegazione corretta, reperimento in archivio, citazione pubblica, contatto o vendita.
3. Separare documento privato, estratto pubblico e pagina di presentazione.
4. Elencare fatti intoccabili: nomi, date, quantità, condizioni, voce narrativa.
5. Dichiarare cosa manca e chi può verificarlo.

**Output:** una scheda di brief di mezza pagina. **Controllo:** tutti concordano sullo stesso esito e sulla fonte dei fatti. La distinzione ricerca/training e il disegno RAG giustificano trattare questi flussi separatamente. [OpenAI-Bot (consultato 2026/11)]; [Anthropic-RAG (2024/09)].

### 5.2 Metodo 2: mappare domande e decisioni

**Scopo:** rispondere al bisogno reale, senza forzare ogni paragrafo in una keyword.

1. Raccogliere domande da clienti, lettori, assistenza, ricerche interne e fonti osservate.
2. Separare imparare, eseguire, confrontare, scegliere, acquistare e trovare un’entità.
3. Collegare ciascuna domanda al passaggio che la risolve.
4. Segnare domande senza risposta e domande fuori scopo.
5. Accorpare duplicati; creare una sezione o pagina autonoma soltanto se serve un bisogno distinto.

**Output:** tabella domanda / intento / risposta esistente / prova / lacuna. **Controllo:** nessuna variante creata solo per moltiplicare pagine. Il query fan-out è descritto da Google come una possibilità dei suoi sistemi, non un invito alla produzione massiva. [Google-AI (2025/12), How AI features work]; [Google-Guida (2026/07), valuable content].

### 5.3 Metodo 3: risposta chiara e approfondimento

**Scopo:** rendere la risposta immediatamente individuabile, preservando le condizioni.

1. Usare un titolo che espliciti il contenuto della sezione.
2. Dare la risposta principale nelle prime frasi quando il genere lo consente.
3. Aggiungere motivo, limiti, esempio e azione successiva.
4. Usare liste per elementi paralleli, passi numerati per sequenze, tabelle per confronti.
5. Eliminare premesse pubblicitarie che ritardano la risposta.

**Output:** una sezione riscrivibile come risposta utile anche a un lettore umano. **Controllo:** non omettere eccezioni per ottenere uno snippet più corto. Non imporre un numero fisso di parole, righe o token. La struttura è un consiglio Microsoft; non una garanzia multipiattaforma. [Microsoft-Contenuti (2025/10), Q&A / Lists and Tables].

### 5.4 Metodo 4: contesto esplicito e identità coerente

**Scopo:** ridurre interpretazioni sbagliate quando un passaggio viene letto isolatamente.

1. Esplicitare soggetto, prodotto o servizio alla prima occorrenza significativa.
2. Sciogliere acronimi e distinguere omonimi.
3. Accompagnare numeri con unità, periodo, mercato e base di confronto.
4. Collegare l’autore a una biografia vera e pertinente.
5. Usare una scheda anagrafica condivisa per aggiornare nome, ruoli e contatti nei diversi canali.

**Output:** glossario e scheda entità. **Controllo:** un lettore esterno capisce a chi si riferisce ogni affermazione. L’esempio RAG Anthropic mostra la perdita del contesto di impresa e trimestre in un frammento; applicare il controllo al testo è una nostra proposta editoriale. [Anthropic-RAG (2024/09), contextualized chunk].

### 5.5 Metodo 5: registro delle affermazioni e delle prove

**Scopo:** rendere verificabile ogni fatto rilevante.

1. Estrarre affermazioni fattuali, risultati, confronti e promesse.
2. Abbinare fonte primaria e passaggio pertinente, non un link genericamente autorevole.
3. Registrare data, unità, denominatore, metodo e limiti.
4. Separare dato, opinione, esempio ipotetico e proposta.
5. Correggere o rimuovere i claim senza sostegno; mantenere le citazioni vicine al fatto.

**Output:** registro claim / fonte / data / verifica / limite. **Controllo:** la fonte sostiene proprio quella frase? Non aggiungere numeri o virgolettati per ottenere un’apparenza di scientificità. La verifica claim-fonte è distinta dal numero dei riferimenti nell’audit Stanford. [Stanford-Verifica (2023/12), abstract / evaluation].

### 5.6 Metodo 6: aggiungere valore originale documentato

**Scopo:** fornire qualcosa di utile oltre a riassumere testi già disponibili.

1. Scegliere esperienza diretta, test, procedura, dati originali o confronto documentabile.
2. Spiegare raccolta, campione e condizioni.
3. Mostrare il materiale necessario a controllare il risultato, nei limiti della pubblicazione scelta.
4. Dichiarare interesse commerciale e limiti della propria esperienza.
5. Sostituire “migliore” con criteri confrontabili quando esistono prove.

**Output:** almeno un contributo sostanziale e verificabile. **Controllo:** qualcuno potrebbe produrre lo stesso contenuto senza conoscere o svolgere il lavoro descritto? Il principio deriva dall’autovalutazione di originalità ed esperienza, non da un bonus numerico GEO. [Google-Qualita (2026/10), Content and quality / Expertise].

### 5.7 Metodo 7: procedure e confronti utilizzabili

**Scopo:** aiutare una decisione o un’esecuzione concreta.

1. Per procedure: dichiarare prerequisiti, strumenti, passi, risultato atteso, errori e verifica finale.
2. Per confronti: usare gli stessi criteri, condizioni, versione e data per tutti i soggetti.
3. Per prodotti: descrivere caratteristiche vere, destinatari, limiti e disponibilità con fonte.
4. Per guide: distinguere soluzione generale e caso specifico.
5. Sostituire classifiche assolute con scelta per scenario quando i criteri lo richiedono.

**Output:** sequenza o confronto omogeneo. **Controllo:** il lettore riesce a decidere o agire senza indovinare informazioni mancanti? Liste e tabelle sono formati suggeriti da Microsoft, non fattori dal peso dichiarato. [Microsoft-Contenuti (2025/10), Lists and Tables].

### 5.8 Metodo 8: revisione, versioni e correzioni

**Scopo:** mantenere informazioni affidabili nel tempo.

1. Identificare i campi volatili: prezzi, norme citate, software, date, disponibilità e ruoli.
2. Assegnare responsabile e data di verifica coerenti con la volatilità.
3. Conservare versione e modifiche sostanziali.
4. Aggiornare i collegamenti e correggere affermazioni superate.
5. Non cambiare la data solo per sembrare recenti.

**Output:** registro di revisione. **Controllo:** data e contenuto raccontano la stessa storia? Google mette in guardia dalla falsa freschezza; la frequenza concreta è una scelta editoriale, non una cadenza universale. [Google-Qualita (2026/10), Avoid search engine-first content].

### 5.9 Metodo 9: estrazione e accessibilità del file

**Scopo:** verificare che il contenuto visibile sia disponibile anche come testo sensato.

1. Esportare testo selezionabile; per scansioni, prevedere OCR e revisione di nomi, cifre e simboli.
2. Usare stili di titolo, indice, didascalie e riferimenti espliciti.
3. Verificare ordine di lettura in colonne e riquadri.
4. Estrarre il testo con il parser che verrà effettivamente usato e confrontarlo con il documento visivo.
5. Controllare tabelle, note, formule, collegamenti e pagine campione; descrivere gli elementi visivi informativi.

**Output:** file originale più estrazione di controllo. **Controllo:** nessun numero attribuito alla riga o al soggetto sbagliato. W3C documenta i rischi dell’ordine di lettura; l’uso del parser è un nostro test aggiuntivo. Non tutti i parser utilizzano i tag PDF allo stesso modo. [W3C-PDF (consultato 2026/11), Description / Tests].

### 5.10 Metodo 10: adattare il metodo al genere

**Scopo:** applicare i controlli pertinenti senza snaturare il documento.

| Documento | Applicare soprattutto | Conservare / evitare |
|---|---|---|
| Articolo e tutorial | Intento, risposta, prove, procedura | Evitare FAQ ripetitive e premesse decorative |
| Corso e manuale | Obiettivi, definizioni, esempi, esercizi, riferimenti alle lezioni | Non eliminare prerequisiti e spiegazioni necessarie |
| PDF tecnico e report | Sintesi, metodi, unità, tabelle, fonti, versione | Non sacrificare precisione a brevità |
| Word e presentazione | Stili, ordine logico, titoli, note, fonti | Non affidare i fatti essenziali soltanto a immagini |
| Scheda commerciale | Caratteristiche reali, uso, condizioni, confronto documentato | Non inventare recensioni, superiorità o prestazioni |
| Romanzo e memoir | Metadati, sinossi, pagina autore e presentazione pubblica | Preservare la voce e la struttura narrativa; non trasformare i capitoli in FAQ |
| Archivio interno | Identificativi, versioni, accessi, contesto, prove di recupero | Non pubblicare il materiale privato per inseguire visibilità |

Questa tabella è una proposta editoriale. “Qualsiasi documento” significa selezionare controlli pertinenti, non applicare indiscriminatamente tutti i formati a ogni testo.

## 6. Metodi per pubblicazione e reputazione

### 6.1 Metodo 11: verificare la reperibilità tecnica

**Scopo:** controllare l’accesso reale della destinazione scelta.

1. Verificare URL stabile, risposta HTTP corretta, contenuto accessibile senza ostacoli non voluti.
2. Leggere robots.txt e controlli di indicizzazione; per PDF ispezionare anche gli header HTTP.
3. Verificare che il testo principale sia disponibile dopo il rendering pertinente e che i link lo rendano raggiungibile.
4. Controllare eventuali blocchi di CDN, WAF o challenge ai bot autorizzati.
5. Verificare acquisizione con strumenti ufficiali e log, quando disponibili; registrare “non verificabile” se manca accesso.

**Output:** checklist con prove e stato. **Controllo:** test di accesso, indicizzazione e citazione restano tre controlli distinti. `noindex` e limitazioni di anteprima hanno funzioni diverse; un blocco di scansione può impedire al motore di leggere la direttiva. [Google-Robots (2026/03), Combining rules]; [Perplexity-Bot (consultato 2026/11), WAF Configuration].

### 6.2 Metodo 12: pagina pubblica di riferimento e archivio coerente

**Scopo:** offrire un punto di riferimento identificabile per un documento pubblicato.

1. Creare una pagina con titolo, autore, argomento, versione, data e descrizione fedele del documento.
2. Collegare file e pagine correlate con etichette descrittive.
3. Rendere disponibili indice e sintesi utili, senza promettere accesso a contenuti che non si pubblicano.
4. Allineare versioni HTML, PDF e metadati; evitare contraddizioni e duplicazioni inutili.
5. Segnalare nuove versioni attraverso gli strumenti supportati dal motore adottato.

**Output:** pagina di riferimento più collegamenti verificabili. **Controllo:** un visitatore identifica fonte, stato e ambito senza cercare altrove. È una proposta di pubblicazione, non un requisito di avere sempre HTML e PDF. [Google-File (2026/02)]; [Bing-Performance (2026/02), IndexNow].

### 6.3 Metodo 13: markup pertinente e validato

**Scopo:** descrivere correttamente i dati visibili della pagina.

1. Scegliere il tipo appropriato solo dopo verifica della documentazione corrente.
2. Usare proprietà vere; collegare gli identificativi coerenti dell’autore e dell’organizzazione.
3. Tenere le informazioni equivalenti nel testo visibile.
4. Validare sintassi e requisiti della specifica funzionalità; ricontrollare dopo la pubblicazione.
5. Distinguere vocabolario Schema.org, risultato avanzato Google e citazione AI.

**Output:** markup e registro di verifica. **Controllo:** nessun dato non presente o fuorviante. La sintassi valida non garantisce visualizzazione; Google raccomanda JSON-LD quando adatto al sito, non uno speciale “schema GEO”. Non inserire codice JSON-LD come testo decorativo dentro un PDF. [Google-Schema (2026/07), quality]; [Google-SchemaIntro (2025/12), formats / guidelines].

### 6.4 Metodo 14: presenza editoriale esterna autentica

**Scopo:** rendere disponibile il proprio contributo nei contesti pertinenti al pubblico.

1. Individuare testate, comunità, podcast, blog e video che trattano realmente il tema.
2. Proporre contributi sostanziali: prove, tutorial, ricerche o casi controllabili.
3. Dichiarare chi si è e gli interessi pertinenti.
4. Collegare alla fonte quando utile e consentito, senza invii promozionali ripetitivi.
5. Monitorare contesto e correttezza delle menzioni, oltre alla quantità.

**Output:** piano di distribuzione con ragione editoriale e risultato osservato. **Controllo:** il contributo è utile anche senza un beneficio GEO? Le correlazioni Ahrefs e i confronti Toronto motivano un’ipotesi da testare; non dimostrano un effetto garantito della PR. [Ahrefs-Menzioni (2025/05)]; [Toronto-GEO (2025/09)].

### 6.5 Metodo 15: mercati, lingue e attività locali

**Scopo:** mantenere il contenuto adatto al contesto in cui viene cercato.

1. Separare mercato, lingua, valuta, disponibilità e giurisdizione quando pertinenti.
2. Revisionare le traduzioni con competenza sul settore e sul paese.
3. Per sedi reali, allineare indirizzi, orari, telefoni e servizi su sito e profili pertinenti.
4. Creare pagine locali solo quando contengono informazioni utili e specifiche.
5. Testare query locali e generiche separatamente.

**Output:** matrice mercato / lingua / sede / dato / fonte. **Controllo:** nessuna sede o partnership inventata, nessuna traduzione con dati rimasti del mercato sbagliato. Le osservazioni Yext sono locali e non sostituiscono la verifica dei dati della singola attività. [Yext-Locale (2025/10)]; [Bing-Performance (2026/02), Local business].

## 7. Metodi per verifica e misurazione

### 7.1 Metodo 16: quattro prove con esiti separati

**Scopo:** localizzare il problema anziché assegnare un generico “punteggio GEO”.

| Prova | Procedura proposta | Esito |
|---|---|---|
| Comprensione | Fornire il documento e porre domande con risposte note | Correttezza, completezza, riferimenti |
| Accesso | Fornire URL e verificare lettura del contenuto | Fetch riuscito, testo estratto |
| Scoperta | Nuova sessione, domanda reale senza fornire documento, URL o nome del brand | Presenza e fonte spontaneamente recuperata |
| Uso corretto | Confrontare risposta e passaggio originale | Citazione pertinente, fatto e condizioni conservati |

I test non sono equivalenti: GEO originale, SAGEO e LIVE-GEO operano in condizioni differenti. [GEO-KDD (2024/06)]; [SAGEO-KDD (2026/08)]; [LIVE-GEO (2026/10)].

**Passi:** preparare risposte attese e fonti; usare domande dirette e parafrasi; registrare errori; ripetere dopo le modifiche; conservare prove grezze. Non chiamare “scoperta organica” una prova con il link suggerito.

### 7.2 Metodo 17: campione di prompt e registro delle osservazioni

**Scopo:** ottenere risultati confrontabili.

1. Definire prima un campione di domande; una partenza possibile è 20-30 prompt, senza valore statistico universale.
2. Segmentare per intento, lingua, paese, settore e brand/non-brand.
3. Registrare data, prodotto, modalità, modello se visibile, ricerca attiva, contesto della sessione e prompt esatto.
4. Ripetere in più momenti e sessioni pulite quando possibile; documentare ciò che non si può controllare.
5. Salvare risposta, brand nominati, URL, passaggio ripreso, correttezza e concorrenti.

**Output:** registro di test versionato. **Controllo:** non sostituire gli insuccessi con nuove formulazioni per migliorare il risultato. La variabilità osservata da AirOps motiva le repliche; il numero e la cadenza del test restano scelte del progetto. [AirOps-Drift (2025/09)].

### 7.3 Metodo 18: distinguere indicatori e denominatori

**Scopo:** misurare ciò che si vuole davvero ottenere.

| Indicatore proposto | Calcolo o osservazione | Limite |
|---|---|---|
| Tasso di menzione | Risposte valide con brand / risposte valide osservate | Campione, non quota di mercato |
| Tasso di citazione | Risposte valide con URL pertinente / risposte valide osservate | Non numero assoluto di link |
| Correttezza | Risposte valutabili corrette / risposte valutabili | Richiede criteri e revisione |
| Stabilità | Frequenza di presenza nelle repliche dello stesso prompt | Non ranking fisso |
| Traffico attribuibile | Visite riconoscibili dalla fonte / periodo | Attribuzione incompleta possibile |
| Conversione | Eventi di business verificati / visite attribuite | Evento e finestra devono essere espliciti |

Queste sono definizioni operative del rapporto. La Citation Share Microsoft usa invece le citazioni del sito sul totale delle citazioni per una grounding query; non equivale alle quote qui definite. Semrush mostra perché menzione e citazione vanno separate. [Bing-Share (2026/06), Citation Share]; [Semrush-Ghost (2026/06)].

### 7.4 Metodo 19: sperimentare senza attribuire tutto alla riscrittura

**Scopo:** ridurre conclusioni affrettate.

1. Fotografare situazione iniziale, contenuti e dati di misura.
2. Scegliere un intervento definito e un gruppo di pagine comparabili come controllo, quando fattibile.
3. Conservare domanda, modalità e regole di valutazione.
4. Annotare cambi di motore, stagionalità, nuove campagne e modifiche concorrenti.
5. Riportare conteggi assoluti, ampiezza del campione e differenze osservate; descrivere l’incertezza.
6. Senza disegno causale adeguato, usare “associato a” e non “causato da”.

**Output:** nota sperimentale con ipotesi, cambiamento, confronto, risultati e limiti. La raccomandazione di confrontare pagine e periodi compare anche nella documentazione del markup; questo protocollo più ampio è una proposta del rapporto. [Google-SchemaIntro (2025/12), Measuring effect].

### 7.5 Strumenti ufficiali e cambiamenti recenti

Bing AI Performance descrive citazioni, pagine e grounding query campionate. L’aggiornamento di giugno aggiunge classificazioni e Citation Share; Topics Portfolio di ottobre aggrega temi e opportunità con valori approssimati e richiede dati sufficienti. Non è una graduatoria mondiale dei brand. [Bing-Performance (2026/02)]; [Bing-Share (2026/06)]; [Bing-Topics (2026/10)].

Le due pagine Google consultate non sono perfettamente allineate: quella del dicembre 2025 descrive dati AI nel traffico Web aggregato; quella aggiornata a luglio 2026 menziona un report generativo e impostazioni di inclusione. Per questo rapporto non assumo disponibilità identica in ogni account: verificare interfaccia e documentazione corrente prima di impostare dashboard o requisiti. Non estrarre una quota AI precisa da un totale aggregato. [Google-AI (2025/12), Measuring]; [Google-Guida (2026/07), Technical structure / Measure].

## 8. Tecniche opzionali e cose da non confondere

### 8.1 llms.txt e Markdown

La proposta llms.txt v2 descrive un indice compatto e link a risorse per agenti; non è robots.txt né una promessa di ranking. Osmani tratta soprattutto documentazione per agenti di coding e dichiara di non parlare a nome di tutta Google. [llms-proposta (2026/08), Proposal]; [Osmani-Agenti (2026/04), Disclosure].

**Procedura facoltativa proposta:** usarli dove esiste un consumatore reale; mantenere coerenza con HTML; controllare richieste ai file e successo dei compiti; misurare il vantaggio rispetto al costo di manutenzione. Non prioritizzarli davanti a fatti corretti, accessibilità e contenuti utili.

### 8.2 RAG e segmentazione dei documenti

Anthropic sperimenta contesto aggiunto ai frammenti, recupero lessicale e semantico e reranking; riporta miglioramenti nel proprio test, non nelle citazioni web. [Anthropic-RAG (2024/09), Methodology].

**Procedura per un archivio controllato:** conservare ID documento, titolo, versione e pagina; segmentare per significato; portare con sé il contesto necessario; testare domande con riferimenti noti; confrontare strategie di recupero; validare le risposte. Dimensione e sovrapposizione dei frammenti dipendono dal sistema: non trasformarle in obblighi per pagine web pubbliche.

### 8.3 Tabella dei claim da evitare

| Claim | Trattamento corretto |
|---|---|
| “Questa formula garantisce citazioni” | Richiedere prove e condizioni; non promettere l’esito |
| “Ogni paragrafo deve avere X parole” | Scegliere la lunghezza in base a contenuto e lettore |
| “FAQPage è obbligatorio per GEO” | Verificare funzione, supporto e bisogno reale |
| “Un bot ha visitato il file, quindi l’AI lo usa” | Verificare separatamente accesso e risposta |
| “Abbiamo fornito il testo e siamo comparsi” | È un test di uso del testo fornito |
| “Ripetere il prompt addestra il motore sul brand” | Non è una prova di training permanente |
| “Il 40% dello studio è traffico in più” | Indicare benchmark e metrica effettiva |
| “Basta ottenere citazioni esterne” | Distinguere reputazione autentica, correlazione e causa |
| “Tutti i motori hanno la stessa preferenza” | Testare separatamente prodotti, mercati e modalità |
| “Un generico score 90/100 predice vendite” | Usarlo al massimo come rubrica interna esplicita |

Base: distinzione dei controlli [OpenAI-Bot], limiti [GEO-KDD], differenze di pipeline [SAGEO-KDD], assenza di lunghezza ideale e schema speciale [Google-Guida], risultati osservazionali [Ahrefs-Multi]. Le formulazioni della colonna sinistra sono esempi di claim da valutare, non citazioni di queste fonti.

## 9. Modelli pronti da applicare

Questa sezione contiene **modelli originali**, non formule ufficiali.

### 9.1 Scheda di lavoro per qualsiasi documento

```text
DOCUMENTO: titolo, formato, versione e data
PUBBLICO: chi legge, cosa sa e cosa vuole ottenere
DESTINAZIONE: chat / archivio privato / pubblicazione web
OBIETTIVO: comprendere / eseguire / scegliere / contattare / acquistare
DOMANDA PRINCIPALE:
DOMANDE SECONDARIE:
FATTI DA PRESERVARE:
AFFERMAZIONI DA VERIFICARE:
FONTI E PAGINE:
CONTRIBUTO ORIGINALE:
LIMITI ED ECCEZIONI:
STRUTTURA PROPOSTA:
ELEMENTI VISIVI DA DESCRIVERE:
CONTROLLI DI ESTRAZIONE:
CONTROLLI DI PUBBLICAZIONE, SE PERTINENTI:
TEST E RISPOSTE ATTESE:
MISURE INIZIALI:
RESPONSABILE E PROSSIMA REVISIONE:
```

### 9.2 Prompt di analisi e riscrittura

```text
Analizza il documento allegato per migliorarne utilità, verificabilità
 e comprensione nei sistemi AI, preservandone genere, significato e voce.

1. Identifica pubblico, bisogno, destinazione e obiettivo.
2. Mappa domande, risposte, entità, fatti, fonti e lacune.
3. Segnala ogni affermazione non supportata; non inventare informazioni.
4. Distingui osservazioni verificate, ipotesi e controlli impossibili con gli input.
5. Proponi modifiche ordinate per impatto e motivazione.
6. Riscrivi le parti pertinenti con struttura chiara e contesto sufficiente.
7. Conserva numeri, limiti e riferimenti; evidenzia i fatti da confermare.
8. Adatta il risultato al formato: non trasformare narrativa in FAQ.
9. Proponi test distinti di comprensione, accesso, scoperta e uso corretto.
10. Non dichiarare indicizzazione, citazioni o vendite senza osservazioni reali.

Output: diagnosi, tabella modifiche, testo revisionato, verifiche e limiti.
Se il documento non risponde a una domanda, dichiaralo esplicitamente.
```

### 9.3 Esempio applicato a una guida

**Prima, testo ipotetico:** “Con la nostra rivoluzionaria guida diventerai il migliore e tutte le AI parleranno di te”.

**Diagnosi:** pubblico non definito; risultati non dimostrati; contenuto reale non descritto; nessun criterio di verifica.

**Dopo, modello da completare con fatti reali:** “La guida spiega [argomenti verificati] a [pubblico]. Include [materiali realmente presenti] e una procedura per [compito]. Il risultato si verifica con [prova concreta]. Non garantisce la presenza nelle risposte AI”.

I campi tra parentesi sono dati da raccogliere, non testo da pubblicare senza revisione. Per un libro, aggiungere formato, edizione, tema e caratteristiche solo dopo controllo del file reale.

### 9.4 Checklist finale

- [ ] È chiaro chi deve usare il documento e per quale compito?
- [ ] La domanda principale trova risposta dove ci si aspetta?
- [ ] Titoli e contenuto corrispondono?
- [ ] I soggetti e le quantità sono identificabili anche nel singolo passaggio?
- [ ] I fatti importanti hanno prove pertinenti?
- [ ] Dati, opinioni ed esempi sono distinguibili?
- [ ] Il contributo originale è reale e controllabile?
- [ ] Eccezioni e condizioni restano visibili?
- [ ] Il testo estratto conserva il significato?
- [ ] Immagini e tabelle informative sono comprensibili?
- [ ] Autore, versione e data sono corretti?
- [ ] La pubblicazione è coerente con la destinazione scelta?
- [ ] Accesso, indicizzazione e citazione sono verificati separatamente?
- [ ] Il markup eventualmente presente descrive fatti visibili?
- [ ] Le osservazioni AI sono state registrate e ripetute?
- [ ] Menzione, citazione, correttezza, visite e conversioni sono separate?
- [ ] Gli interventi hanno una priorità e un responsabile?
- [ ] Le informazioni mancanti sono dichiarate?

## 10. Priorità, limiti e controlli completati

### 10.1 Ordine di lavoro proposto

1. **Prima:** errori fattuali, promesse infondate, blocchi reali, testo non leggibile, bisogno principale senza risposta.
2. **Poi:** struttura, prove, identità, esempi, confronti e versione.
3. **Successivamente:** collegamenti, pubblicazione, metadati pertinenti e distribuzione editoriale.
4. **Infine:** test comparabili, misure di business e miglioramento sulla base di dati osservati.
5. **Opzionale:** formati per agenti e interventi RAG, quando corrispondono all’uso effettivo.

Non serve ricominciare tutto per ogni documento: applicare i controlli pertinenti e registrare “non applicabile” dove necessario.

### 10.2 Limiti della ricerca

- Non esiste una ricerca che possa garantire di aver consultato ogni sito, blog, PDF e thread mondiale. Questo è un insieme ampio e selezionato di fonti accessibili, non un censimento completo.
- Ricognizione prevalentemente in inglese, con sintesi italiana; non copre integralmente ecosistemi chiusi o motori cinesi, russi e altri mercati locali.
- Algoritmi proprietari e pesi effettivi non sono pubblici nelle fonti esaminate. Non sono stati inferiti da brevetti o dichiarazioni promozionali.
- Nessun test su un sito dell’utente, log privato, dashboard autenticata o conversione reale è stato eseguito. Il rapporto è ricerca e progettazione di metodi.
- Nessuna meta-analisi numerica: campioni, date, piattaforme e metriche sono troppo diversi per sommare effetti.
- I fornitori di strumenti hanno interessi commerciali; i risultati non equivalgono a repliche indipendenti.
- Per sei paper sono disponibili metadati e fonti originali, ma non conteggi bibliometrici verificati. arXiv non implica peer review.
- Il preprint Assorbimento ha metadati discordanti: mantenuto solo come pista esplorativa, senza autorità aggiunta.
- Il campione Reddit è intenzionale e concentrato su controversie; alcune date indicizzate divergono dalle etichette relative. Un thread aggiuntivo sul chunking non è stato apribile ed è escluso dalle fonti utilizzate.
- Nessun consiglio di lunghezza, frequenza di aggiornamento o numero di prompt è un parametro universale dimostrato.
- Funzionalità e controlli cambiano: verificare le istruzioni del provider al momento dell’applicazione. Il disallineamento fra le due pagine Google è riportato, non risolto con un’assunzione.

### 10.3 Controlli completati

- Fonti ufficiali separate da studi proprietari, preprint e comunità.
- URL delle fonti utilizzate aperti; paper consultati in versioni identificate.
- Risultati e metodi originali distinti dalle proposte operative del rapporto.
- Campioni, metriche e limiti essenziali esplicitati.
- Citazioni testuali brevi, separate da parafrasi e accompagnate da traduzione.
- Deduplicati paper HTML/PDF e rilanci di studi su Reddit.
- Controllati riferimenti interni, indice e coerenza dei titoli.

## 11. Fonti e documenti originali

Le date “consultato” indicano assenza di una data editoriale esatta verificabile. Tutte le fonti sono state consultate nella ricognizione del 7 novembre 2026. I sei thread Reddit sono fonti primarie delle opinioni espresse, non degli studi esterni rilanciati.

**[Google-AI, 2025/12]** Google Search Central. “AI features and your website.” [Google-AI](https://developers.google.com/search/docs/appearance/ai-features). Ufficiale; requisiti e comportamento dichiarato di Google; non prova per altri motori.

**[Google-Guida, 2026/07]** Google Search Central. “Optimizing your website for generative AI features on Google Search.” [Google-Guida](https://developers.google.com/search/docs/fundamentals/ai-optimization-guide). Ufficiale; aggiornata 10 luglio 2026; alcune indicazioni di reporting differiscono dalla pagina precedente.

**[Google-Qualita, 2026/10]** Google Search Central. “Creating helpful, reliable, people-first content.” [Google-Qualita](https://developers.google.com/search/docs/fundamentals/creating-helpful-content). Ufficiale; aggiornata 5 ottobre 2026; criteri di autovalutazione, non punteggio GEO.

**[Google-Schema, 2026/07]** Google Search Central. “General structured data guidelines.” [Google-Schema](https://developers.google.com/search/docs/appearance/structured-data/sd-policies). Ufficiale; pertinenza, visibilità e qualità del markup.

**[Google-SchemaIntro, 2025/12]** Google Search Central. “Introduction to structured data markup in Google Search.” [Google-SchemaIntro](https://developers.google.com/search/docs/appearance/structured-data/intro-structured-data). Ufficiale; formati, verifica e risultati avanzati.

**[Google-Robots, 2026/03]** Google Search Central. “Robots meta tag, data-nosnippet, and X-Robots-Tag specifications.” [Google-Robots](https://developers.google.com/search/docs/crawling-indexing/robots-meta-tag). Ufficiale; regole di scansione, indicizzazione e anteprime da distinguere.

**[Google-File, 2026/02]** Google Search Central. “File types indexable by Google.” [Google-File](https://developers.google.com/search/docs/crawling-indexing/indexable-file-types). Ufficiale; supporto del formato non significa indicizzazione garantita.

**[OpenAI-Bot, consultato 2026/11]** OpenAI. “Overview of OpenAI Crawlers.” [OpenAI-Bot](https://developers.openai.com/api/docs/bots). Ufficiale; data editoriale non visibile; distingue ricerca, training e richieste utente.

**[Perplexity-Bot, consultato 2026/11]** Perplexity. “Perplexity Crawlers.” [Perplexity-Bot](https://docs.perplexity.ai/docs/resources/perplexity-crawlers). Ufficiale; data editoriale non visibile; crawler, fetcher e configurazione WAF.

**[Anthropic-Bot, consultato 2026/11]** Anthropic / Claude Help Center. “Does Anthropic crawl data from the web, and how can site owners block the crawler?.” [Anthropic-Bot](https://support.claude.com/en/articles/8896518-does-anthropic-crawl-data-from-the-web-and-how-can-site-owners-block-the-crawler). Ufficiale; data relativa, senza giorno editoriale verificabile.

**[Anthropic-RAG, 2024/09]** Anthropic Engineering. “Introducing Contextual Retrieval.” [Anthropic-RAG](https://www.anthropic.com/research/contextual-retrieval). Esperimento del fornitore sul recupero in knowledge base; non misura GEO sul web.

**[Microsoft-Contenuti, 2025/10]** Krishna Madhavan, Microsoft Advertising. “Optimizing Your Content for Inclusion in AI Search Answers.” [Microsoft-Contenuti](https://about.ads.microsoft.com/en/blog/post/october-2025/optimizing-your-content-for-inclusion-in-ai-search-answers). Autore Microsoft; guida del fornitore, non studio causale indipendente.

**[Bing-Performance, 2026/02]** Krishna Madhavan, Meenaz Merchant, Fabrice Canel, Saral Nigam; product manager Microsoft AI. “Introducing AI Performance in Bing Webmaster Tools Public Preview.” [Bing-Performance](https://blogs.bing.com/webmaster/2026/2/Introducing-AI-Performance-in-Bing-Webmaster-Tools-Public-Preview/). Ufficiale; funzioni e limiti della reportistica Microsoft.

**[Bing-Share, 2026/06]** Krishna Madhavan, Meenaz Merchant, Saral Nigam, Trishna Shah; product manager Microsoft AI. “New AI Visibility Insights in Bing Webmaster Tools: Intents, Topics, Citation Share, Compare.” [Bing-Share](https://blogs.bing.com/search/2026/6/New-AI-Visibility-Insights-in-Bing-Webmaster-Tools-Intents-Topics-Citation-Share-Compare/). Ufficiale; preview annunciata 16 giugno; metriche osservative.

**[Bing-Topics, 2026/10]** Microsoft Bing. “Introducing Topics Portfolio (Beta) in AI Performance.” [Bing-Topics](https://blogs.bing.com/webmaster/2026/10/introducing-topics-portfolio-beta-in-ai-performance/). Ufficiale; 13 ottobre; disponibilità subordinata a dati sufficienti.

**[W3C-PDF, consultato 2026/11]** W3C Web Accessibility Initiative. “PDF3: Ensuring correct tab and reading order in PDF documents.” [W3C-PDF](https://www.w3.org/WAI/WCAG22/Techniques/pdf/PDF3). Tecnica di accessibilità, non studio di ranking; data editoriale non verificata.

**[llms-proposta, 2026/08]** Jeremy Howard, autore della proposta llms.txt. “The /llms.txt file, v2.” [llms-proposta](https://llmstxt.org/). Proposta primaria: pubblicata 3 settembre 2024, modificata 10 agosto 2026; non standard universale dei motori.

**[Osmani-Agenti, 2026/04]** Addy Osmani, Director Google Cloud AI secondo la dichiarazione dell’articolo. “Agentic Engine Optimization (AEO).” [Osmani-Agenti](https://addyosmani.com/blog/agentic-engine-optimization/). Opinione personale per strumenti sviluppatori; dichiara che non è raccomandazione Google-wide.

**[GEO-KDD, 2024/06]** Pranjal Aggarwal (IIT Delhi), Vishvak Murahari, Karthik Narasimhan, Ameet Deshpande (Princeton), Tanmay Rajpurohit e Ashwin Kalyan (indipendenti). “GEO: Generative Engine Optimization.” [GEO-KDD](https://arxiv.org/html/2311.09735v3). KDD 2024; DOI 10.1145/3637528.3671900; citazioni bibliometriche non verificate.

**[SAGEO-KDD, 2026/08]** Sunghwan Kim, Serin Kim, Sangam Lee, Dongha Lee (Yonsei); Wooseok Jeong (Konkuk). “SAGEO Arena: A Realistic Environment for Evaluating Search-Augmented Generative Engine Optimization.” [SAGEO-KDD](https://arxiv.org/html/2602.12187v2). KDD 2026; DOI 10.1145/3770855.3818146; citazioni bibliometriche non verificate.

**[Toronto-GEO, 2025/09]** Mahe Chen, Xiaoxuan Wang, Kaiwen Chen, Nick Koudas; University of Toronto. “Generative Engine Optimization: How to Dominate AI Search.” [Toronto-GEO](https://arxiv.org/html/2509.08919v1). Preprint; peer review e citazioni bibliometriche non verificate.

**[Stanford-Verifica, 2023/12]** Nelson F. Liu, Tianyi Zhang, Percy Liang; Stanford Computer Science. “Evaluating Verifiability in Generative Search Engines.” [Stanford-Verifica](https://aclanthology.org/2023.findings-emnlp.467/). Findings EMNLP 2023, pp. 7001-7025; DOI 10.18653/v1/2023.findings-emnlp.467; citazioni bibliometriche non verificate.

**[Assorbimento, 2026/04]** Zhang Kai e Yao Jingang nella versione HTML; metadati indicizzati discordanti. “From Citation Selection to Citation Absorption: A Measurement Framework for Generative Engine Optimization Across AI Search Platforms.” [Assorbimento](https://arxiv.org/html/2604.25707v1). Preprint esplorativo; affiliazioni e citazioni bibliometriche non verificate; non usato per prescrizioni forti.

**[LIVE-GEO, 2026/10]** Runze Kong (Michigan), Haibo Jin, Xucheng Yu, Huimin Zeng, Haohan Wang (UIUC), Xiaoqi Wang (affiliazione non leggibile). “Do GEO Gains Survive the Live Web? Evaluating In-the-Wild Visibility Gains of Generative Engine Optimization via LIVE-GEO.” [LIVE-GEO](https://arxiv.org/html/2611.01126v1). Preprint del 31 ottobre 2026; peer review e citazioni bibliometriche non verificate.

**[Ahrefs-Menzioni, 2025/05]** Louise Linehan, Content Marketer Ahrefs; contributo dati Xibeijia Guan. “An Analysis of AI Overview Brand Visibility Factors (75K Brands Studied).” [Ahrefs-Menzioni](https://ahrefs.com/blog/ai-overview-brand-correlation/). Studio osservazionale proprietario; Ahrefs vende gli strumenti impiegati.

**[Ahrefs-Multi, 2025/12]** Louise Linehan, Content Marketer Ahrefs; contributo Xibeijia Guan, revisione Ryan Law. “Top Brand Visibility Factors in ChatGPT, AI Mode, and AI Overviews (75k Brands Studied).” [Ahrefs-Multi](https://ahrefs.com/blog/ai-brand-visibility-correlations/). Studio osservazionale proprietario; pool di domande differenti.

**[Semrush-Ghost, 2026/06]** Semrush, studio in collaborazione con Kevin Indig secondo il testo. “Why 62% of AI citations don’t lead to brand mentions [Study].” [Semrush-Ghost](https://www.semrush.com/blog/the-ghost-citations-study/). Studio proprietario; titolo e denominatore del corpo richiedono distinzione.

**[AirOps-Drift, 2025/09]** Oshen Davidson, autore del report AirOps; ruolo specifico non verificato. “Staying Seen In AI Search: How Citations & Mentions Impact Brand Visibility.” [AirOps-Drift](https://www.airops.com/report/how-citations-mentions-impact-visibility-in-ai-search). Studio del fornitore; metodologia parzialmente specificata.

**[Yext-Locale, 2025/10]** Yext Research / comunicato aziendale. “86% of AI Citations Come from Brand-Managed Sources.” [Yext-Locale](https://www.yext.com/about/news-media/ai-citations-release?facet=app&mode=light). Studio su sedi locali; definizione ampia di fonti gestibili dal brand.

**[Ahrefs-Conversioni, 2025/06]** Patrick Stox, Technical SEO Ahrefs. “Does AI Search Traffic Convert Better Than Traditional Search? For Ahrefs, Yes: 0.5% of Visitors Drove 12.1% of Signups.” [Ahrefs-Conversioni](https://ahrefs.com/blog/ai-search-traffic-conversions-ahrefs/). Caso aziendale singolo; iscrizioni, non ricavi; conflitto commerciale dichiarato dal contesto.

**[Reddit-Esperienze, 2025/05 indicizzato]** u/ccrrr2 e commentatori; ruoli e affiliazioni non verificati. “Did you see any improvements with LLMS.text?.” [Reddit-Esperienze](https://www.reddit.com/r/SEO/comments/1kn2l5c/did_you_see_any_improvements_with_llmstext/). Discussione r/SEO; data dall’indice, non dalle etichette relative.

**[Reddit-Ahrefs, 2026/06 indicizzato]** u/WebLinkr; ruolo e affiliazione non verificati. “We Analyzed 137K Sites: 97% of llms.txt Files Never Get Read.” [Reddit-Ahrefs](https://www.reddit.com/r/SEO/comments/1u6iqna/we_analyzed_137k_sites_97_of_llmstxt_files_never/). Ripubblicazione; non replica indipendente dello studio citato.

**[Reddit-Otterly, 2026/04 indicizzato]** u/WebLinkr; ruolo e affiliazione non verificati. “Otterly destroys LLMS.txt; Does it matter? Claims vs Evidence.” [Reddit-Otterly](https://www.reddit.com/r/SEO/comments/1sxd82t/otterly_destroys_llmstxt_does_it_matter_claims_vs/). Ripubblicazione di dati commerciali; conteggi non auditati.

**[Reddit-Markdown, consultato 2026/11]** u/annseosmarty; ruolo e affiliazione non verificati. “LLM.txt? Yes! .md files? Yes! Headings + short copy? Yes!.” [Reddit-Markdown](https://www.reddit.com/r/SEO_for_AI/comments/1skv2wu/llmtxt_yes_md_files_yes_headings_short_copy_yes/). r/SEO_for_AI; data esatta del thread non verificata; articolo rilanciato 11 aprile 2026.

**[Reddit-FAQ, 2026/04 indicizzato]** u/annseosmarty e commentatori; ruoli e affiliazioni non verificati. “Question-format and short headings are cited more [Study].” [Reddit-FAQ](https://www.reddit.com/r/SEO_for_AI/comments/1sr9jrr/questionformat_and_short_headings_are_cited_more/). Fonte LinkedIn originale non verificata; data indicizzata e relativa incoerenti.

**[Reddit-Prove, 2026/10 indicizzato]** u/CowPuzzleheaded; dichiara attività SEO, identità non verificata. “What actually gets a page cited in AI answers?.” [Reddit-Prove](https://www.reddit.com/r/SEO/comments/1xb5bds/what_actually_gets_a_page_cited_in_ai_answers/). r/SEO; checklist critica e domanda aperta; non evidenza sperimentale.

### 11.1 PDF accademici e documento di esempio

- [GEO, PDF originale v3](https://arxiv.org/pdf/2311.09735v3).
- [SAGEO Arena, PDF originale v2](https://arxiv.org/pdf/2602.12187v2).
- [Toronto GEO, PDF originale v1](https://arxiv.org/pdf/2509.08919v1).
- [Stanford, PDF editoriale EMNLP 2023](https://aclanthology.org/2023.findings-emnlp.467.pdf).
- [Assorbimento, PDF originale v1](https://arxiv.org/pdf/2604.25707v1).
- [LIVE-GEO, PDF originale v1](https://arxiv.org/pdf/2611.01126v1).
- [W3C, esempio PDF di ordine di lettura a due colonne](https://www.w3.org/WAI/WCAG22/working-examples/pdf-reading-order/reading-order-2cols-word.pdf): esempio pratico, non esperimento GEO.

I collegamenti PDF accademici rimandano alle stesse opere già schedate; non aumentano il numero di fonti indipendenti. Il PDF W3C è materiale illustrativo della tecnica già citata.
