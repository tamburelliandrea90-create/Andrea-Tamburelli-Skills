# Restituzione e verifica della ricostruzione

## Output predefinito

### Elaborato ottimizzato
Dare il contenuto finale completo. Usare un titolo significativo, coerente con il testo; organizzare il corpo per obiettivo e genere. Tenere note editoriali, score e ragionamento fuori dall’elaborato. Conservare fonti necessarie nel documento. Non inserire riempitivi o dati tra parentesi come se il testo fosse pronto alla pubblicazione.

### Interventi principali
Elencare poche modifiche effettive, per esempio: riorganizzazione, chiarimento di un termine, contestualizzazione di un dato, fusione di duplicati. Indicare esplicitamente fatti corretti o affermazioni commerciali attenuate. Non elencare genericamente tutti i metodi per ogni input breve.

### Verifiche e limiti
Separare acquisito, verificato sulla fonte, verificato esternamente e non verificabile. Non scrivere “fonti verificate” quando i link sono soltanto riportati nell’input. Dichiarare solo incertezze concrete. Per materiale senza lacune rilevanti è sufficiente una frase sul controllo editoriale.

### Eventuali prossimi interventi
Proporre pubblicazione, metadati o misure solo se pertinenti; non eseguirli senza autorizzazione. Una checklist di attività future non sostituisce l’elaborato.

## Registro interno di QA
Confrontare prima e dopo:
- Tutti i temi sostanziali conservati oppure rimozione motivata e visibile nel resoconto.
- Nomi, numeri, unità, periodi, negazioni e condizioni equivalenti.
- Corrispondenza fonti-fatti; riferimenti di pagina/lezione/timestamp non inventati.
- Nessuna promessa di risultato aggiunta o lasciata come fatto senza sostegno.
- Tono e genere rispettati; nessuna modifica arbitraria di pubblico o destinazione.
- Titoli coerenti con il corpo; paragrafi e liste non frammentati senza motivo.
- Esplicitazione del contesto sufficiente senza ripetizioni meccaniche.
- Nessun dato di pubblicazione, traffico o test mai osservato dichiarato come acquisito.
- Eventuali file finali verificati con procedura del formato.

## Prove editoriali interne
Formulare da tre a cinque domande se la lunghezza lo giustifica: una diretta, una parafrasi, una su eccezioni/condizioni, una richiesta non risolvibile e una procedurale se pertinente. Collegare ogni risposta a un passaggio. Verificare che l’elaborato mantenga sia la risposta sia il limite. Per testi minimi usare un controllo proporzionato senza fabbricare prove. Non presentare l’autoverifica come esperimento indipendente su agenti esterni.

## Score solo su richiesta
Se l’utente chiede un punteggio, definire una rubrica editoriale trasparente su chiarezza, completezza, contesto e verificabilità. Escludere dimensioni non osservabili. Chiamarlo valutazione interna; non attribuirlo a Google, OpenAI o probabilità di citazione.

## Esempio di fedeltà
Input ipotetico: “Corso per adulti. Dodici lezioni. Non è una certificazione professionale. Materiali aggiornati a giugno 2025”.
Nel risultato mantenere pubblico adulto, dodici lezioni, esclusione della certificazione e giugno 2025. Non aggiungere riconoscimenti, docenti, risultati, ore o aggiornamento al 2026.

## Esempio di lacuna
Input ipotetico: “Il servizio riduce i tempi del 70%”, senza prove.
Non inventare campioni o fonti. Riportare l’assenza di verifica; riformulare prudentemente il claim o sospenderne l’uso commerciale, spiegando la modifica. Non cambiare il 70% in un’altra percentuale arbitraria.
