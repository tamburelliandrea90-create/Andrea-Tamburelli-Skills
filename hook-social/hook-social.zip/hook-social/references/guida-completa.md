## Indice della fonte

- 1. Che cosa sono gli hook
- 2. Come possono suscitare interesse
- 3. Bias cognitivi e persuasione: usare i concetti con precisione
- 4. Le forme principali degli hook
- 5. Metodo pratico per progettare un hook
- 6. Ventuno tipologie di hook con esempi e applicazioni
- 7. CTA: collegare l’apertura a un’azione sensata
- 8. Adattare il gancio al formato
- 9. Vantaggi, limiti ed errori
- 10. Come misurare le prestazioni
- 11. Cinque campagne da studiare
- 12. Esercizio guidato
- 13. Checklist prima di pubblicare

---

# Hook nei social media: come progettare aperture efficaci, mantenerne la promessa e misurare i risultati

Guida ampliata e riorganizzata dal testo fornito. Gli esempi sono modelli editoriali originali da adattare; non sono testimonianze di risultati ottenuti. Verifica delle fonti: 7 novembre 2026.

## 1. Che cosa sono gli hook

Un hook è l’elemento iniziale che offre alla persona un motivo per fermarsi su un contenuto e continuare a leggerlo, guardarlo o ascoltarlo. In italiano si può chiamare gancio o apertura.

Può essere una frase, una domanda, un’immagine, un gesto, una dimostrazione, una situazione narrativa o un suono. Il suo valore dipende dal rapporto con ciò che segue: un’apertura interessante deve condurre a un contenuto che mantenga la promessa.

### 1.1 Le funzioni di un hook

1. Rendere riconoscibile l’argomento.
2. Far capire a chi si rivolge il contenuto.
3. Mostrare un problema, una possibilità o un risultato pertinente.
4. Aprire una domanda che il contenuto risolverà.
5. Preparare il tono: pratico, narrativo, ironico, tecnico o commerciale.

Non tutti gli hook devono svolgere tutte le funzioni contemporaneamente. Un tutorial può iniziare mostrando un risultato; un racconto può iniziare da una situazione insolita.

### 1.2 Hook, promessa, sviluppo e CTA

- Hook: attira l’attenzione iniziale.
- Promessa: chiarisce che cosa la persona ricaverà dal contenuto.
- Sviluppo: dimostra, spiega o racconta ciò che è stato anticipato.
- Payoff: soddisfa l’attesa e chiude il punto aperto.
- CTA, call to action: propone l’azione successiva, se serve.

Esempio originale:
- Hook: “Il tuo PDF è pieno di informazioni, ma trovare una risposta è un’impresa?”
- Promessa: “Ti mostro come riorganizzare una pagina senza perdere i dati”.
- Sviluppo: pagina iniziale, modifiche spiegate, pagina finale.
- Payoff: confronto verificabile fra prima e dopo.
- CTA: “Prova il controllo su una pagina del tuo documento”.

“Guarda fino alla fine” è una richiesta di attenzione, ma da sola non spiega perché valga la pena concederla.

## 2. Come possono suscitare interesse

### 2.1 Curiosità e lacuna informativa

La teoria della lacuna informativa di George Loewenstein descrive la curiosità come legata alla percezione di una distanza fra ciò che sappiamo e ciò che vorremmo sapere. Non è una formula che garantisce clic o vendite. [Fonte: Loewenstein, 1994](https://www.cmu.edu/dietrich/sds/docs/loewenstein/PsychofCuriosity.pdf).

Per applicarla alla scrittura, rendi comprensibile la domanda aperta. “C’è un errore in questa descrizione: riesci a individuarlo?” offre un compito più definito di “Non crederai a quello che sto per dirti”. Il contenuto deve poi mostrare l’errore e spiegarlo.

### 2.2 Rilevanza personale

Puoi progettare un’apertura partendo da una situazione riconoscibile:

- Un compito che la persona deve svolgere.
- Una difficoltà che incontra davvero.
- Una scelta per la quale cerca criteri.
- Un interesse o un’esperienza condivisa.

Esempio: “Hai registrato un vocale per spiegare un’idea e adesso devi trasformarlo in una guida?”. È un invito specifico, che permette di capire subito se il contenuto è pertinente.

### 2.3 Utilità, sorpresa ed emozione

L’interesse può nascere anche da:

1. Utilità: una spiegazione o una soluzione applicabile.
2. Sorpresa: un contrasto fra aspettativa e osservazione.
3. Identificazione: un’esperienza in cui riconoscersi.
4. Emozione: attesa, divertimento, stupore o partecipazione.
5. Dimostrazione: un risultato visibile che invita a capire il procedimento.

Sono possibili direzioni creative da testare, non leve infallibili. Il tono deve rispettare l’argomento e il pubblico.

## 3. Bias cognitivi e persuasione: usare i concetti con precisione

Il testo di partenza collega hook e bias cognitivi. È utile evitare una semplificazione: non ogni motivo di interesse è un bias. Curiosità, utilità e riconoscimento di un bisogno non richiedono necessariamente una distorsione del giudizio.

Puoi usare questi concetti come domande di progettazione, senza presentare il pubblico come programmabile.

### 3.1 Prova sociale

Domanda progettuale: posso mostrare un’esperienza reale e pertinente di altre persone?

- Usa testimonianze autentiche e fedeli.
- Specifica il contesto dei risultati.
- Non trasformare un caso individuale in una promessa per tutti.
- Non inventare numeri di clienti o recensioni.

Esempio: “Come una lettrice ha utilizzato questa tavola: il suo procedimento, passo per passo”, soltanto se hai realmente quel caso e puoi utilizzarlo.

### 3.2 Autorità

Domanda progettuale: chi sostiene questa affermazione, con quali competenze e su quali prove?

- Nomina professionisti e fonti pertinenti.
- Conserva il significato delle loro dichiarazioni.
- Evita titoli vaghi come “gli esperti confermano” senza indicare chi e dove.

Esempio: “Cosa controllare in una fonte prima di citarla in una guida”.

### 3.3 Rischio di perdita

Domanda progettuale: qual è un errore concreto che il lettore può prevenire?

- Descrivi conseguenze proporzionate e verificabili.
- Non creare paure arbitrarie.
- Proponi un controllo o una soluzione.

Esempio: “Prima di esportare il PDF, controlla che le note non siano rimaste fuori pagina”.

### 3.4 Scarsità e urgenza

Domanda progettuale: esiste una scadenza o una disponibilità realmente limitata?

- Indica date e condizioni effettive.
- Evita contatori che si azzerano e “ultimi posti” permanenti.
- Se non c’è urgenza reale, usa una ragione concreta per agire, come prepararsi a un appuntamento già fissato.

Queste applicazioni sono indicazioni editoriali prudenti. Non attribuiscono un aumento misurato di efficacia all’impiego di un bias.

## 4. Le forme principali degli hook

### 4.1 Hook testuale

È la prima frase di un post, il titolo di un articolo o la copertina di un carosello. Deve essere comprensibile anche prima dell’apertura del testo completo.

### 4.2 Hook verbale

È ciò che viene detto all’inizio del video o dell’audio. Evita presentazioni lunghe quando il contenuto promette una dimostrazione immediata. Introduci invece la situazione o il compito.

### 4.3 Hook visivo

Può mostrare una prova, un dettaglio, una trasformazione o un’azione già iniziata. La differenza visiva deve essere pertinente, non un effetto decorativo che promette un argomento diverso.

### 4.4 Hook sonoro

Un suono riconoscibile, una pausa o un attacco vocale possono contribuire all’apertura. Il significato essenziale dovrebbe comunque essere comprensibile anche a chi incontra il contenuto senza audio, quando possibile.

### 4.5 Combinazioni coerenti

Testo, immagine e voce possono sostenere la stessa promessa. Se uno annuncia un tutorial, un altro una polemica e un altro ancora un’offerta, la persona fatica a capire che cosa stai proponendo.

Esempio: immagine di una pagina disordinata, testo “Dove si nasconde la risposta?”, voce che avvia la dimostrazione. Tre elementi coordinati su un solo compito.

## 5. Metodo pratico per progettare un hook

### 5.1 Definisci il risultato

Scegli una priorità: lettura, comprensione, visione di una dimostrazione, salvataggio, conversazione, visita o contatto. Una singola apertura non deve chiedere tutte queste azioni.

### 5.2 Descrivi il destinatario

Annota:
- Che cosa sta cercando di fare.
- Quale problema incontra.
- Che cosa sa già.
- Quale linguaggio usa.
- Quali prove gli servono.

“Autori che stanno preparando la descrizione del primo libro” è un riferimento più concreto di “chiunque voglia avere successo”.

### 5.3 Trova una promessa sostenibile

Completa la frase: “Dopo questo contenuto, la persona potrà…”. Usa un risultato che puoi effettivamente offrire. “Confrontare tre aperture” è dimostrabile; “diventare virale” non è sotto il tuo controllo.

### 5.4 Scrivi più alternative

Prova angolazioni diverse: problema, dimostrazione, confronto, storia, domanda o procedimento. Evita di limitarti a cambiare aggettivi nello stesso titolo.

### 5.5 Verifica il legame con il contenuto

Domandati:
1. Il contenuto risponde a ciò che annuncio?
2. La persona capisce di che cosa si parla?
3. Ho promesso un risultato che non posso dimostrare?
4. Ho inserito numeri o testimonianze senza prova?
5. Sto ritardando artificialmente la risposta?

### 5.6 Pubblica, misura e correggi

Registra versione dell’apertura, contenuto, formato, data e risultato. Cambia una variabile importante per volta quando vuoi capire quale intervento sia associato a una differenza. Nei confronti organici resta prudente: pubblico, distribuzione e contesto possono cambiare.

## 6. Ventuno tipologie di hook con esempi e applicazioni

Gli esempi seguenti sono modelli originali. Le frasi in prima persona vanno usate soltanto se descrivono una tua esperienza reale.

### 1. Domanda su un problema riconoscibile

- Formula: “Ti succede [situazione concreta]?”
- Esempio: “Hai tante informazioni, ma il tuo articolo sembra non arrivare al punto?”.
- Applicazione: scegli una difficoltà e mostra come affrontarla.
- Evita: domande generiche come “Vuoi migliorare?”.

### 2. Beneficio specifico

- Formula: “Come [compito] con [procedura o vincolo]”.
- Esempio: “Come trasformare gli appunti di una lezione in una guida consultabile”.
- Applicazione: tutorial e contenuti pratici.
- Evita: vantaggi assoluti o risultati fuori dal tuo controllo.

### 3. Errore da riconoscere

- Formula: “Questo dettaglio rende [compito] più difficile”.
- Esempio: “Se il titolo promette un confronto, il testo deve offrire criteri per scegliere”.
- Applicazione: revisione di un caso concreto.
- Evita: “Stai sbagliando tutto” quando stai discutendo un dettaglio.

### 4. Credenze da verificare

- Formula: “Prima di seguire [consiglio diffuso], controlla [condizione]”.
- Esempio: “Prima di aggiungere altre keyword, controlla se hai risposto alla domanda del lettore”.
- Applicazione: argomenti in cui puoi mostrare ragionamento e prove.
- Evita: contraddire per provocare senza sostenere la tesi.

### 5. Dimostrazione immediata

- Formula: “Guarda [operazione o risultato osservabile]”.
- Esempio: “Prendo questo paragrafo e ti mostro come lo riorganizzo”.
- Applicazione: mostrare competenza mentre svolgi il lavoro.
- Evita: risultati preparati presentati come prove mai eseguite.

### 6. Prima e dopo

- Formula: “Stesso contenuto, [differenza concreta]”.
- Esempio: “La stessa descrizione prima e dopo aver chiarito a chi è destinato il libro”.
- Applicazione: revisioni editoriali e visive.
- Evita: confronti falsati da cambiamenti non dichiarati.

### 7. Confronto fra alternative

- Formula: “[A] oppure [B]: quale risponde a [bisogno]?”.
- Esempio: “Apertura con domanda o dimostrazione: come scegliere per un tutorial?”.
- Applicazione: aiutare una decisione con criteri.
- Evita: dichiarare un vincitore universale.

### 8. Curiosità con domanda precisa

- Formula: “Che cosa manca in [esempio]?”.
- Esempio: “Questa scheda descrive il libro. Quale informazione manca per aiutarti a sceglierlo?”.
- Applicazione: quiz editoriale seguito da spiegazione.
- Evita: misteri senza una risposta utile.

### 9. Dato documentato

- Formula: “[Dato verificato]: fonte, periodo e significato”.
- Esempio: “Nel nostro test, questa apertura ha ottenuto più clic: ecco numeri e condizioni”.
- Applicazione: soltanto con misure realmente raccolte.
- Evita: percentuali inventate come “il 90% delle persone non sa…”.

### 10. Esperienza personale reale

- Formula: “Quando [evento], ho capito [lezione]”.
- Esempio adattabile: “Alla prima revisione mi sono accorto che la risposta arrivava soltanto alla fine”.
- Applicazione: racconto di un’esperienza verificabile dell’autore.
- Evita: aneddoti creati e presentati come autobiografici.

### 11. Errore personale e correzione

- Formula: “Ho fatto [errore]; l’ho corretto così”.
- Esempio adattabile: “Avevo riempito l’introduzione di spiegazioni. Ho iniziato dal problema del lettore”.
- Applicazione: mostrare procedimento e limiti.
- Evita: vulnerabilità costruita per ottenere reazioni.

### 12. Dietro le quinte

- Formula: “Ecco cosa controllo prima di [azione]”.
- Esempio: “I controlli che faccio prima di consegnare una guida”.
- Applicazione: mostrare criteri e lavoro concreto.
- Evita: promettere segreti inesistenti.

### 13. Sfida pratica

- Formula: “Riesci a [compito pertinente]?”.
- Esempio: “Riesci a capire il destinatario del libro leggendo solo queste due righe?”.
- Applicazione: partecipazione seguita da spiegazione.
- Evita: sfide scollegate dall’obiettivo del contenuto.

### 14. Quiz o autoverifica

- Formula: “Quale di queste opzioni [criterio]?”.
- Esempio: “Quale titolo chiarisce meglio il problema affrontato?”.
- Applicazione: formazione e verifica di comprensione.
- Evita: risposte arbitrarie o test presentati come diagnosi scientifiche.

### 15. Ironia riconoscibile

- Formula: esasperare con misura una situazione reale.
- Esempio: “Il tuo PDF ha bisogno di un interprete? Prima controlliamo se ha un indice”.
- Applicazione: rendere vicino un problema senza umiliare chi lo affronta.
- Evita: battute che sostituiscono completamente l’informazione.

### 16. Anteprima concreta

- Formula: “Ti mostro [parte specifica] prima di [uscita o approfondimento]”.
- Esempio: “Ecco la prima tavola e il passaggio della storia a cui è collegata”.
- Applicazione: presentare materiale realmente disponibile.
- Evita: chiamare esclusivo ciò che è già pubblico ovunque.

### 17. Esperienza del cliente

- Formula: “[Persona o caso reale]: problema, uso, osservazione”.
- Esempio adattabile: “Come un autore ha riorganizzato la presentazione del suo manuale”.
- Applicazione: con caso autentico, contesto e materiale utilizzabile.
- Evita: recensioni inventate e risultati individuali estesi a tutti.

### 18. Risposta a una domanda frequente

- Formula: “Come si risolve [domanda realmente ricorrente]?”.
- Esempio: “Un PDF scansionato si può riscrivere? Prima serve leggere correttamente il testo”.
- Applicazione: assistenza, tutorial e contenuti salvabili.
- Evita: chiamare frequente una domanda solo per darle autorevolezza.

### 19. Checklist o infografica

- Formula: “[Numero] controlli per [compito]”.
- Esempio: “Cinque controlli per capire se l’apertura mantiene la promessa”.
- Applicazione: schemi pratici e confronti visivi.
- Evita: numeri decorativi senza contenuti distinti.

### 20. Attualità o contributo di un esperto

- Formula: “[Novità o intervento verificato]: che cosa cambia per [pubblico]?”.
- Esempio: “Una nuova funzione può essere utile al tuo corso? Vediamo cosa permette davvero”.
- Applicazione: quando la fonte è attuale e pertinente; attribuire chiaramente contributi e citazioni.
- Evita: notizie non controllate, tendenze irrilevanti e autorità fuori dal proprio ambito.

### 21. Risorsa, contest o giveaway

- Formula: “Puoi ottenere [risorsa o premio reale] seguendo [condizioni chiare]”.
- Esempio: “Vuoi usare questa checklist? Nel post trovi come richiederla”.
- Applicazione: rendere immediatamente comprensibile cosa viene offerto. Se è un concorso, distinguere chiaramente partecipazione e assegnazione del premio.
- Evita: annunciare un premio inesistente o confondere interesse per il regalo con interesse per il prodotto. Questa guida non contiene istruzioni normative per organizzare concorsi.

## 7. CTA: collegare l’apertura a un’azione sensata

La call to action dovrebbe seguire il valore effettivamente offerto. Una proposta concreta è più chiara di “Devi assolutamente vedere questo”.

Esempi:
- Per un tutorial: “Prova il controllo sul primo paragrafo”.
- Per un confronto: “Quale criterio pesa di più nella tua scelta?”.
- Per una risorsa: “Commenta AI GEO per richiedere la skill e la guida”.
- Per una dimostrazione: “Nel post trovi il procedimento completo”.
- Per un contatto: “Descrivimi il documento e il risultato che ti serve”.

Scegli un’azione principale. Specifica cosa riceverà la persona e non promettere un invio automatico se non esiste un sistema che lo esegue.

## 8. Adattare il gancio al formato

- Post testuale: rendi la prima frase pertinente e comprensibile prima dell’espansione del testo.
- Immagine: usa un messaggio leggibile e coerente con il post; conserva dettagli e condizioni nella descrizione.
- Carosello: la copertina introduce una promessa, le pagine successive la sviluppano; evita di ripetere lo stesso titolo senza avanzare.
- Video breve: inizia dalla situazione o dall’azione utile e rendi comprensibile l’argomento anche visivamente.
- Video lungo: presenta scopo e motivo per continuare, poi costruisci la spiegazione senza trattenere artificialmente la soluzione.
- Diretta: chiarisci il tema e riprendi periodicamente il contesto per chi arriva dopo.
- Audio: usa un’apertura verbale autosufficiente; non affidarti a elementi visivi assenti.

Non esiste in questa guida una durata universale dei primi secondi che garantisca risultati. Parti da un’apertura essenziale e verifica i dati del tuo contenuto.

## 9. Vantaggi, limiti ed errori

### 9.1 Risultati da perseguire e verificare

- Rendere evidente il valore del contenuto.
- Attirare persone pertinenti, non soltanto reazioni.
- Aumentare la probabilità che venga avviata una lettura o una visione.
- Rendere riconoscibile il modo in cui il brand presenta i propri argomenti.
- Collegare attenzione a comprensione e azioni utili.

Questi sono obiettivi di progetto, non effetti assicurati. Un hook da solo non dimostra aumento di fedeltà, vendite o viralità.

### 9.2 Rischi da controllare

1. Promessa esagerata rispetto al contenuto.
2. Tono accusatorio che svaluta il destinatario.
3. Domanda troppo vaga per riconoscere l’argomento.
4. Percentuali e testimonianze senza prova.
5. Attesa artificiale prima di una risposta semplice.
6. Tendenza inseguita senza pertinenza.
7. Troppi messaggi concorrenti nell’apertura.
8. Copia di formule senza adattamento al pubblico.
9. Ottimizzazione dei clic mentre diminuisce la qualità dei contatti.
10. Lettura dei risultati come prova certa di causalità.

## 10. Come misurare le prestazioni

Scegli indicatori coerenti con l’obiettivo e controlla le definizioni del sistema usato.

| Obiettivo | Misura possibile | Domanda da porre |
|---|---|---|
| Avvio del consumo | Avvii o interazioni di apertura, se disponibili | Le persone iniziano a leggere o guardare? |
| Tenuta del video | Curva di permanenza e abbandoni | Dove si interrompe la visione? |
| Approfondimento | Visite alla risorsa o clic pertinenti | La promessa invita il pubblico giusto? |
| Utilità percepita | Salvataggi, condivisioni e feedback contestualizzati | Quale utilità viene riconosciuta? |
| Conversazione | Domande e commenti pertinenti | Il contenuto genera un dialogo sul tema? |
| Obiettivo commerciale | Contatti qualificati o acquisti attribuibili | L’attenzione si collega al risultato desiderato? |

Per il CTR indica sempre la definizione scelta: clic pertinenti divisi per le impression considerate, moltiplicati per cento. Non mescolare clic totali, clic sul link e altre azioni.

### Procedura di confronto proposta

1. Scegli un contenuto e due aperture con promesse equivalenti.
2. Definisci prima indicatore e periodo di osservazione.
3. Mantieni comparabili pubblico, formato, offerta e durata per quanto possibile.
4. Registra esposizioni e risultati assoluti, oltre alle percentuali.
5. Ripeti prima di trasformare un episodio in regola.
6. Documenta fattori non controllati, soprattutto nei post organici.

Un’apertura con più clic e meno contatti pertinenti può essere peggiore per il tuo obiettivo. I like, isolati dal contesto, non bastano a stabilire efficacia.

## 11. Cinque campagne da studiare

Queste sono letture editoriali di casi pubblicitari. La descrizione del meccanismo creativo non dimostra che l’apertura, da sola, abbia causato tutti i risultati della campagna. Spot televisivi, eventi dal vivo e video social hanno contesti di distribuzione diversi.

### 11.1 Dove - Real Beauty Sketches

Dove descrive due ritratti della stessa donna: uno ricavato dall’autodescrizione e uno dalla descrizione di un’altra persona. [Fonte ufficiale Dove](https://www.dove.com/it/stories/campaigns/real-beauty-sketches.html).

Lettura editoriale: il dispositivo apre una domanda sulla differenza fra le due rappresentazioni. Il confronto finale soddisfa l’attesa e collega il racconto al messaggio del brand. Come esercizio, prova a mostrare due interpretazioni dello stesso materiale, spiegando su quali criteri differiscono. Non presentare un dispositivo pubblicitario come prova scientifica generale sulla percezione.

### 11.2 Old Spice - The Man Your Man Could Smell Like

Wieden+Kennedy presenta la campagna del 2010 come un progetto rivolto alla conversazione fra coppie, accompagnato da distribuzione pubblicitaria e successivi video di risposta agli utenti. [Fonte dell’agenzia](https://www.wk.com/work/old-spice-smell-like-a-man-man/).

Lettura editoriale: tono, personaggio e cambiamenti di situazione costruiscono un’identità riconoscibile. La lezione pratica è coordinare sorpresa e messaggio. Eventuali risultati commerciali del caso non vanno attribuiti esclusivamente alla battuta iniziale o al singolo video.

### 11.3 Apple - 1984

La ricostruzione del National Museum of American History descrive il concept distopico per il Macintosh e la regia di Ridley Scott. [Fonte museale](https://americanhistory.si.edu/explore/stories/remembering-apples-1984-super-bowl-ad). La pagina ha restituito un errore nell’apertura diretta durante questa verifica; i dettagli essenziali erano disponibili nel risultato indicizzato. Non vengono aggiunti dati di performance.

Lettura editoriale: una situazione visiva con conflitto può introdurre il tema prima della spiegazione del prodotto. È un caso di narrazione pubblicitaria, non un modello che ogni piccolo creator debba riprodurre con effetti cinematografici.

### 11.4 Always - #LikeAGirl

Always descrive la campagna come una rilettura dell’espressione “come una ragazza” e un lavoro sulla fiducia delle ragazze. [Fonte ufficiale Always](https://www.always.co.uk/en-gb/about-us/campaigns-and-initiatives/our-epic-battle-like-a-girl/).

Lettura editoriale: una domanda su un’espressione familiare può aprire un tema più ampio. Per applicare il principio, scegli un luogo comune pertinente e costruisci una dimostrazione rispettosa, senza cercare polemica fine a sé stessa.

### 11.5 Red Bull - Stratos

La FAI documenta il salto di Felix Baumgartner da circa 39 chilometri e la ratifica dei record. È un salto dalla stratosfera: “salto dallo spazio” è una formulazione promozionale poco precisa. [Fonte FAI](https://old.fai.org/fai-slider-news/37012-baumgartners-records-ratified-by-fai).

Lettura editoriale: attesa di un evento reale, obiettivo chiaro e posta in gioco visibile costruiscono una struttura narrativa. Per un contenuto ordinario puoi mostrare una prova o un esperimento sicuro con esito da verificare; non serve imitare il rischio dell’impresa.

## 12. Esercizio guidato

Tema: spiegare una skill che riorganizza documenti.

1. Destinatario: chi ha appunti o materiali disordinati.
2. Problema: trovare le informazioni e trasformarle in un testo comprensibile.
3. Promessa: mostrare una riorganizzazione concreta.
4. Prova: una pagina prima e dopo, con controllo dei dati.
5. Tre aperture da confrontare:
   - Problema: “Hai un documento pieno di informazioni e nessuna risposta facile da trovare?”.
   - Dimostrazione: “Questa è la stessa pagina prima e dopo averla riorganizzata”.
   - Ironia: “Il tuo PDF ha bisogno di un interprete? Partiamo dall’indice”.
6. Sviluppo: tre modifiche osservabili, spiegate brevemente.
7. Chiusura: mostrare il risultato mantenendo informazioni e limiti.
8. CTA: invitare a richiedere la risorsa o provare il procedimento, secondo l’obiettivo reale.

Valutazione: chiarezza dell’argomento, coerenza della promessa, prova disponibile, corrispondenza con il pubblico e qualità dell’azione successiva.

## 13. Checklist prima di pubblicare

- [ ] È chiaro a chi parlo?
- [ ] Il tema è riconoscibile nell’apertura?
- [ ] La promessa è specifica e sostenibile?
- [ ] Il contenuto offre ciò che il titolo annuncia?
- [ ] Ho conservato condizioni ed eccezioni importanti?
- [ ] Numeri, citazioni e testimonianze sono veri e contestualizzati?
- [ ] Immagine, testo e voce comunicano lo stesso punto?
- [ ] L’apertura rispetta il pubblico?
- [ ] La CTA è pertinente e realizzabile?
- [ ] Ho definito come valutare il risultato?

L’intero percorso va progettato insieme: apertura, promessa, sviluppo, soddisfazione dell’attesa e azione successiva. Un buon punto di partenza è una domanda concreta del pubblico e un contenuto capace di risponderle.
