# Adattamento alle piattaforme e ai formati

Questa matrice contiene scelte editoriali, non specifiche tecniche garantite né regole universali degli algoritmi. Rispettare il formato chiesto. Se assente, scegliere il formato predefinito e dirlo brevemente. Verificare limiti e politiche attuali sui siti ufficiali quando la richiesta richiede conformità, pubblicità, novità o conteggi esatti.

| Destinazione | Impostazione editoriale | Elaborato completo da restituire |
|---|---|---|
| Facebook | Situazione riconoscibile, tono conversazionale, spiegazione e utilità concreta | Cinque aperture alternative e un post completo; domanda o CTA pertinente soltanto se utile |
| Instagram, post | Coordinare messaggio visivo e apertura della caption | Cinque aperture, testo breve per la creatività e caption completa; hashtag soltanto se richiesti o pertinenti |
| Instagram, carosello | Copertina con promessa unica, pagine che avanzano la spiegazione | Cinque proposte di copertina, testo effettivo di ogni slide e caption; numero di slide motivato dalla sostanza |
| Instagram Reels, TikTok, Facebook Reels | Azione o situazione iniziale riconoscibile e significato comprensibile anche senza audio | Cinque aperture con parlato e testo a schermo; copione completo della variante scelta, indicazioni visive e caption; eventuali tempi sono stime |
| LinkedIn | Compito o decisione professionale, ragionamento, esempi e limiti | Cinque aperture e un post completo con implicazioni pratiche; evitare risultati aziendali inventati e finta autobiografia |
| YouTube, video lungo | Titolo, eventuale miniatura e apertura devono promettere lo stesso contenuto | Cinque titoli/aperture coerenti; proposta di testo miniatura; copione completo della variante scelta con introduzione, sezioni, esempi, risposta e chiusura; descrizione se richiesta |
| YouTube Shorts | Situazione concreta, dimostrazione e chiusura entro il formato richiesto | Cinque aperture e copione completo con parlato, testo a schermo e indicazioni visive; non applicare automaticamente il modello video lungo |
| X o Threads | Un'idea riconoscibile per post, continuità logica per una sequenza | Cinque aperture e post completo oppure intera sequenza numerata; controllare i limiti correnti solo se occorre rispettarli esattamente |
| Pinterest | Oggetto o risultato chiaro, collegamento coerente con la risorsa | Cinque titoli alternativi, testo della creatività e descrizione completa; non inventare destinazioni o URL |
| Podcast o audio | Apertura verbale autosufficiente, contesto e risposta senza immagini necessarie | Cinque aperture parlate e copione completo, con sezioni se occorre |
| Diretta | Tema subito riconoscibile e riprese di contesto per chi entra dopo | Cinque aperture, introduzione parlata, sviluppo con punti concreti, transizioni, richiamo contestuale e chiusura |

## Google: identificare l'uso

Google comprende servizi e contesti diversi; non trattarlo come un'unica piattaforma social.

- **Ricerca Google / articolo web**: se l'utente dice soltanto «hook per Google» con un testo editoriale, assumere che voglia titolo e apertura di un contenuto web e dichiararlo. Dare cinque titoli alternativi, title proposto, meta description proposta e testo completo con apertura e paragrafi coerenti con la domanda del lettore. Non promettere che Google mostrerà esattamente titolo o descrizione né garantire ranking. Se chiede solo snippet, non generare un articolo inutile.
- **Profilo dell'attività su Google**: quando il contesto è un'attività locale, un'offerta o un aggiornamento del profilo, dare cinque aperture e un post informativo completo, con condizioni e azione disponibili. Non inventare indirizzo, zona, orari o promozioni.
- **Google Ads**: se vengono richiesti annunci, produrre varianti pubblicitarie distinte e coerenti con offerta e destinazione; verificare prima limiti correnti e politiche ufficiali del formato. Se la verifica è impossibile, chiamarle bozze da controllare, non annunci conformi verificati. Non inventare estensioni, prezzi o garanzie.

Per una piattaforma non elencata identificare formato, contesto di fruizione, intento e azione realizzabile; usare gli stessi principi. Non riciclare la stessa copia cambiando il nome del servizio.

## Regole trasversali

- Post testuale: apertura autosufficiente prima dell'espansione; paragrafi leggibili, senza spezzare ogni frase in una riga artificiale.
- Immagine: una promessa leggibile; dettagli e condizioni nella didascalia quando appropriato.
- Carosello: ogni slide aggiunge informazione, senza rinviare tutto all'ultima.
- Video: evitare presentazioni dilatate e attesa artificiale; mostrare ciò che si può davvero dimostrare. Non fingere di aver girato il video.
- Risorsa lunga: se serve un formato breve, spiegare il tema selezionato e proporre una serie per coprire il resto quando richiesto.
- CTA: una prioritaria, coerente con l'obiettivo. Richiedere commenti per una risorsa solo quando esiste ed è ottenibile; non attribuire proprietà magiche a parole nei commenti.
- Nessun numero universale di secondi, hashtag, parole o pubblicazioni settimanali come garanzia. La durata del copione dipende da testo e ritmo; segnalarla come stima.
