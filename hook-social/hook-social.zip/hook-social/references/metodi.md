# Metodi per derivare hook originali

## Indice
1. Principi e processo
2. Repertorio delle 21 tipologie
3. Apprendere dai casi senza copiarli
4. Dalla lettura alla bozza

## 1. Principi e processo

Un hook può essere testuale, verbale, visivo, sonoro o narrativo. Deve rendere riconoscibile il tema e offrire un motivo pertinente per proseguire. Distinguere apertura, promessa, sviluppo, payoff e CTA. Una richiesta come «resta fino alla fine» non offre da sola un motivo.

Curiosità: aprire una domanda delimitata e risolverla. Rilevanza: partire da un compito reale, una scelta o un ostacolo del pubblico. Utilità: offrire un risultato applicabile. Sorpresa: mostrare un contrasto pertinente. Identificazione ed emozione: usare situazioni credibili rispettando il tema. Dimostrazione: mostrare un risultato e spiegare il procedimento. Questi sono criteri creativi, non garanzie di efficacia.

Non chiamare automaticamente ogni interesse «bias». Applicare prova sociale soltanto con casi veri; autorità con competenza e fonti pertinenti; prevenzione di errori con conseguenze proporzionate; urgenza soltanto con scadenze reali. Non inventare percentuali, clienti o scarsità.

## 2. Repertorio delle 21 tipologie

Gli esempi seguenti servono a mostrare la logica; NON riutilizzarli come frasi pronte. Generare contenuti specifici del nuovo input. I tipi personali e commerciali restano subordinati alla disponibilità dei fatti necessari.

| N. | Tipologia | Ragionamento da trasferire | Nuovo esempio illustrativo | Requisito o limite |
|---|---|---|---|---|
| 1 | Problema riconoscibile | Nominare una difficoltà osservabile e delimitata | La ricetta riesce, ma al momento di servirla è già fredda? | Spiegare una soluzione pertinente, senza inventare la frequenza del problema |
| 2 | Beneficio specifico | Unire compito, procedimento e risultato controllabile | Prepara la lista della spesa partendo dai pasti che hai deciso di cucinare. | Nessun risultato assoluto o tempo risparmiato non misurato |
| 3 | Errore riconoscibile | Mostrare un dettaglio, conseguenza e correzione | Le etichette sullo scaffale si leggono da vicino. E dalla porta del negozio? | Rispettare il lettore e motivare la correzione |
| 4 | Credenza da verificare | Mettere alla prova un consiglio con una condizione | Più ripiani risolvono il disordine? Prima misura gli oggetti che devi riporre. | Non costruire una polemica senza dimostrazione |
| 5 | Dimostrazione immediata | Iniziare dall'azione e mostrarne i passaggi | Partiamo da questo mazzo di cavi: separo quelli che uso ogni giorno. | Distinguere una dimostrazione proposta da una realmente eseguita |
| 6 | Prima e dopo | Confrontare lo stesso oggetto con criteri dichiarati | Due versioni dello stesso menù: cerca subito le opzioni vegetariane. | Non falsare il confronto o inventare risultati |
| 7 | Alternative | Rendere esplicito il criterio di scelta | Agenda cartacea o calendario condiviso: chi deve poter aggiornare gli impegni? | Non dichiarare un vincitore universale |
| 8 | Curiosità precisa | Mostrare un'informazione mancante e prometterne la spiegazione | In questo invito c'è data, luogo e orario. Che cosa serve ancora per partecipare? | Risolvere effettivamente il punto aperto |
| 9 | Dato documentato | Collegare misura, fonte, periodo e contesto | Due percorsi di acquisto a confronto: leggiamo insieme i dati del test. | Usare solo dati disponibili; non simulare un test effettuato |
| 10 | Esperienza personale | Partire da un evento autentico e ricavarne una lezione | Quel trasloco mi ha insegnato a scrivere sulle scatole la stanza di destinazione. | Solo se il trasloco appartiene davvero all'autore |
| 11 | Errore personale | Mostrare la correzione oltre alla confessione | Avevo messo il contatto sul retro del volantino. L'ho spostato accanto alla prenotazione. | Solo se il caso è reale; altrimenti proporre un esercizio impersonale |
| 12 | Dietro le quinte | Rendere visibili criteri e controlli di lavoro | Prima di allestire il banco, controllo che il percorso del visitatore sia libero. | Processo reale o chiaramente proposto, nessun segreto inventato |
| 13 | Sfida pratica | Offrire un compito pertinente con soluzione | Riesci a trovare il pulsante per prenotare senza scorrere questa pagina? | Evitare prove umilianti o scollegate dal tema |
| 14 | Quiz e autoverifica | Presentare opzioni e spiegare il criterio | Quale delle due istruzioni ti dice dove consegnare il modulo? | Non vendere il quiz come diagnosi o prova scientifica |
| 15 | Ironia riconoscibile | Esagerare con misura un piccolo attrito quotidiano | Il gruppo organizza la cena. Il giorno è ancora un'indagine aperta. | La battuta deve introdurre contenuto utile, senza deridere persone |
| 16 | Anteprima | Mostrare una parte concreta di materiale disponibile | Apriamo la confezione e guardiamo come sono protetti gli angoli. | Nessuna esclusività o uscita inventata |
| 17 | Esperienza del cliente | Narrare bisogno, uso e osservazione contestualizzati | Il percorso di una cliente dalla scelta del tessuto alla prova della tenda. | Caso autentico utilizzabile, niente testimonial inventati |
| 18 | Risposta utile | Formulare una domanda precisa e rispondere subito | Dove segnare gli ingredienti già presenti in dispensa? | Chiamarla «frequente» soltanto se la ricorrenza è nota |
| 19 | Checklist o infografica | Distinguere controlli azionabili e contarli correttamente | Tre dettagli da verificare prima di stampare gli inviti. | Fornire esattamente tre controlli distinti |
| 20 | Novità o esperto | Collegare un aggiornamento verificato alla decisione del pubblico | È cambiata la modalità di prenotazione: vediamo dove trovare i nuovi orari. | Verificare attualità, fonte e ambito di competenza |
| 21 | Risorsa o premio | Esplicitare valore reale e modalità per ottenerlo | Vuoi preparare il laboratorio? La scheda elenca il materiale necessario. | Confermare risorsa, disponibilità e condizioni; non inventare concorsi |

## 3. Apprendere dai casi senza copiarli

Trattare i cinque casi della guida come letture editoriali, non prove causali di performance:

- Dove: due rappresentazioni dello stesso soggetto creano una domanda, risolta dal confronto. Trasferire il confronto trasparente, non la storia o conclusioni scientifiche generali.
- Old Spice: personaggio, sorpresa e trasformazioni sostengono un messaggio riconoscibile. Trasferire coerenza fra tono e promessa; non imitare battute o attribuire vendite al solo hook.
- Apple 1984: conflitto visivo introduce un tema prima del prodotto. Trasferire una tensione narrativa pertinente, senza richiedere spettacolarità o ricreare lo spot.
- Always: un'espressione comune viene interrogata e reinterpretata. Trasferire una domanda rispettosa sostenuta da esempi, evitando polarizzazione artificiale.
- Red Bull Stratos: obiettivo reale, attesa e risultato osservabile. Trasferire una prova sicura con esito da verificare, senza imitare rischi né chiamare spazio la stratosfera.

Per i fatti storici consultare le fonti nella guida; evitare risultati economici, numeri o citazioni aggiuntivi senza verifica.

## 4. Dalla lettura alla bozza

1. Mappare destinatario, bisogno, promessa e prova del materiale.
2. Selezionare cinque angolazioni supportate, preferendo differenze di prospettiva.
3. Scrivere aperture contestuali, senza incollare esempi del repertorio.
4. Scegliere un'apertura per chiarezza e coerenza, poi svilupparne tutti i passaggi.
5. Chiudere l'attesa e proporre un'azione reale, se utile.
6. Verificare copertura dei punti importanti, formato e fedeltà.

La guida contiene un esercizio sui documenti: trasferire questa procedura a qualsiasi argomento, non usare sempre documenti, PDF o AI come tema del contenuto finale.
