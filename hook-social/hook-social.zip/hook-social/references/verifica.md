# Controlli editoriali e misurazione

## Prima della consegna

- Il tema, il destinatario e il vantaggio concreto sono riconoscibili?
- Sono stati letti tutti i punti della fonte, inclusi condizioni, eccezioni ed esempi?
- Le alternative cambiano angolazione invece di sostituire soltanto aggettivi?
- Gli hook sono originali e specifici dell'input, senza copia degli esempi della guida?
- Il corpo mantiene la promessa di ciascuna alternativa proposta come sostituibile?
- C'è una spiegazione completa con un payoff, non solo titoli o suggerimenti da sviluppare?
- Numeri, date, fonti, testimonianze e risultati appartengono a materiale disponibile e utilizzabile?
- Le parti ipotetiche sono esplicite, senza diventare autobiografia o testimonianza reale?
- La lista contiene esattamente il numero di elementi annunciati?
- Voce, miniatura, immagine e testo a schermo sono coerenti con l'apertura?
- Il testo rispetta il pubblico senza accuse, paure arbitrarie o scarsità inventata?
- La CTA è realizzabile, pertinente e proporzionata?
- La piattaforma e il formato corrispondono alla richiesta? Google è stato identificato correttamente?
- Se si promette copertura integrale, tutti i punti essenziali compaiono nel risultato o nella serie?
- Le specifiche attuali eventualmente dichiarate sono state verificate?

Correggere i problemi direttamente. Aggiungere poche note esterne alla copia solo quando restano informazioni essenziali da verificare. Non allegare questa checklist a ogni post.

## Rischi da prevenire

Promessa esagerata; domanda vaga; tono accusatorio; numeri inventati; suspense artificiale; tendenze irrilevanti; messaggi concorrenti; formule copiate; clic scollegati da contatti utili; correlazioni presentate come cause. Attenzione e comprensione vanno valutate insieme. Un'apertura da sola non prova aumento di fedeltà, vendite o viralità.

## Se viene richiesto di valutare risultati

Scegliere una metrica collegata all'obiettivo e verificarne la definizione nella piattaforma:

| Obiettivo | Segnale possibile | Controllo |
|---|---|---|
| Avvio | Avvii o aperture disponibili | Verificare che cosa viene contato |
| Tenuta video | Curva di permanenza e abbandoni | Guardare dove il contenuto perde spettatori |
| Approfondimento | Clic pertinenti o visite | Separare clic sul link e altre azioni |
| Utilità | Salvataggi, condivisioni, feedback | Contestualizzare con esposizioni e qualità |
| Conversazione | Domande e commenti sul tema | Non contare solo il volume |
| Commerciale | Contatti qualificati o acquisti attribuibili | Dichiarare finestra e limiti di attribuzione |

Per CTR: dichiarare numeratore e denominatore, poi calcolare clic pertinenti / impression considerate × 100. Non confondere percentuali di aumento relativo e punti percentuali. Riportare valori assoluti quando disponibili. Non inventare metriche assenti o campioni di utenti.

Confrontare due aperture con promesse equivalenti; definire prima obiettivo e periodo; rendere comparabili pubblico, formato, contenuto e offerta per quanto possibile; registrare esposizioni e azioni; ripetere prima di generalizzare; dichiarare confondenti della distribuzione organica. Non cambiare insieme titolo, offerta e pubblico e attribuire l'effetto al titolo.

Se non esistono dati, proporre un confronto da effettuare o una valutazione editoriale dichiarata. Non dichiarare un vincitore statistico o un effetto causale. Non pubblicare per raccogliere dati senza richiesta dell'utente.
