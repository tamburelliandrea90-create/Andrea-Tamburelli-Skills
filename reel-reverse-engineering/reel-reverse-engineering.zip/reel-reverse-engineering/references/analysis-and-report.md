# Griglia di analisi e report

## Evidenze e granularità

Aprire con il meccanismo creativo più rilevante e il livello di accesso: video con audio, solo video, trascrizione o pagina. Non presentare ipotesi come cause certe delle views.

Per clip brevi usare una riga per inquadratura/passaggio significativo; per video lunghi raggruppare in sequenze e dettagliare apertura, payoff e transizioni decisive. Annotare eventi anche senza tagli.

| Intervallo osservato | Immagine/azione | Parlato o parafrasi | Testo a schermo | Audio | Taglio/cambiamento | Funzione | Evidenza/limite |
| --- | --- | --- | --- | --- | --- | --- | --- |

Scrivere «non udibile», «non leggibile» o «non accessibile» quando necessario. Non completare per intuizione.

## Misurare il ritmo

- Distinguere tagli, dissolvenze, zoom, testo, inserti e movimento nella stessa ripresa.
- Riportare durata totale e numero di tagli con definizione adottata. Il numero delle inquadrature è tagli+1 soltanto per una sequenza semplice di tagli netti; non applicare automaticamente a compositing, loop o transizioni ambigue.
- Calcolare durata media delle inquadrature dalla lista effettivamente segmentata. Aggiungere mediana o range solo se utili. Non estrapolare il totale da un campione.
- Con trascrizione e tempi misurati stimare parole/minuto specificando se si usa tutto il video o il solo parlato.
- Con campionamento di fotogrammi dichiarare risoluzione temporale e tagli potenzialmente mancati; dare indicazioni qualitative, non precisione al frame.
- Spiegare dove si aggiunge informazione e dove una pausa facilita la comprensione. Un video senza tagli può avere un ritmo efficace.

## Formato del report

1. **Sintesi**: meccanismo trasferibile e limite principale in poche righe.
2. **Materiale verificato**: link/file, autore, date, durata e contatori disponibili; distinguere dati riferiti dall'utente e osservati; dichiarare parti non viste/ascoltate.
3. **Scomposizione temporale**: tabella delle sequenze e spiegazione di apertura, progressione e payoff.
4. **Gancio, ritmo e comunicazione**: spiegazioni con timecode; metriche tecniche solo se misurate.
5. **Ipotesi di diffusione**: tabella «elemento osservato | possibile effetto | spiegazione alternativa | dato necessario». Evitare punteggi di viralità inventati.
6. **Mappa di adattamento**: tabella «meccanismo | cosa mantenere | adattamento alla nicchia | cosa creare da zero».
7. **Reel originale**: obiettivo, pubblico, durata proposta, tre ganci e storyboard.

| Tempo proposto | Parlato originale | Ripresa/azione | Testo a schermo | Audio e montaggio |
| --- | --- | --- | --- | --- |

8. **Produzione**: riprese, oggetti, sequenza di montaggio, copertina, didascalia e CTA.
9. **Test**: ipotesi, variabile, metrica, dati disponibili, finestra uniforme e decisione. Terminare con tre azioni prioritarie.

Se il video è inaccessibile consegnare solo sezioni supportate e richiedere il materiale mancante. Etichettare eventuali bozze creative come proposte indipendenti, non reverse engineering del video non visto.

## Metriche

Calcolare tassi solo con numeratori e denominatori disponibili e comparabili: ad esempio salvataggi/account raggiunti × 100. Se si usano views dichiararlo e non chiamarlo tasso per reach. Il rapporto tempo medio/durata non è la percentuale di persone arrivate alla fine e può superare il 100% per ripetizioni.

Non promettere che più commenti, un brano popolare, un numero di hashtag o una durata fissa producano diffusione. Separare risposta del pubblico e risultato aziendale. Per acquisire clienti KDP le sole views non dimostrano il risultato.
