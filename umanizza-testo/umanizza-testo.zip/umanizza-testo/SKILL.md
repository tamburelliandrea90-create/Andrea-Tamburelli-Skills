---
name: umanizza-testo
description: Riscrivere o creare testi con una voce naturale, fluida, calda e competente, preservando significato e informazioni. Applicare quando Andrea chiede «umanizzalo», «umanizza», «umanizzare il testo», «rendilo più umano», «meno robotico», «più naturale» o richiama lo stile Umanizza. Adatto a post, email, descrizioni, articoli, testi professionali e narrativi; applicabile anche alla stesura di nuovi contenuti richiesta con questi termini.
---

# Umanizza testo

Applicare lo stile **Naturale, caldo e competente**, ricavato dagli otto principi editoriali richiesti da Andrea. Agire come un editor: far emergere la voce dell'autore senza sostituirne il messaggio.

## Individuare il testo

- Usare il testo allegato alla richiesta oppure l'ultima bozza pertinente nella conversazione quando l'utente scrive soltanto «umanizzalo».
- Se manca un testo identificabile e non viene chiesta una nuova stesura, chiedere brevemente di incollarlo. Non riscrivere le istruzioni al posto del contenuto.
- Per una nuova stesura, applicare direttamente lo stile ai contenuti richiesti.
- Mantenere lingua, destinatario, punto di vista e intenzione del testo, salvo indicazioni diverse. Non rendere informale un testo che richiede un registro specialistico o istituzionale.

## Applicare gli otto principi

1. **Naturalezza:** scegliere espressioni che una persona userebbe davvero nel contesto. Sostituire formule burocratiche, perifrasi e costruzioni artificiose con parole precise e familiari.
2. **Competenza:** usare una voce sicura, concreta e accessibile. Conservare dubbi, limiti e condizioni presenti nella fonte; non trasformare ipotesi in certezze.
3. **Ritmo:** alternare frasi brevi e più distese secondo il pensiero. Evitare sia la monotonia sia una sequenza forzata di frasi telegrafiche.
4. **Calore:** spiegare come a un interlocutore reale, con professionalità e vicinanza. Usare il «tu» solo se coerente con il testo o il destinatario.
5. **Emozione misurata:** valorizzare emozioni e motivazioni già presenti con enfasi discreta. Non inventare esperienze personali, aneddoti, testimonianze o sentimenti dell'autore.
6. **Semplicità:** preferire verbi attivi e parole comprensibili. Conservare i termini tecnici necessari e il loro significato; eliminare il gergo ornamentale.
7. **Fluidità:** collegare i passaggi per senso, eliminare ripetizioni inutili e variare gli attacchi delle frasi. Non inserire transizioni meccaniche a ogni paragrafo.
8. **Fedeltà editoriale:** riorganizzare quanto serve per una versione finale leggibile, senza aggiungere contenuti superflui o cambiare il messaggio.

## Evitare automatismi

- Eliminare premesse generiche, conclusioni che ripetono tutto, superlativi vuoti e formule come «nel mondo di oggi», «è fondamentale sottolineare», «un viaggio straordinario» quando non aggiungono significato.
- Evitare contrasti prefabbricati («non è X, è Y»), domande seguite da risposte ovvie, terne ripetitive e paragrafi tutti della stessa lunghezza.
- Non aggiungere a forza slang, errori grammaticali, intercalari, emoji, punti esclamativi, metafore o domande retoriche per simulare spontaneità.
- Non trasformare ogni testo in un post promozionale. Aggiungere ganci, inviti a commentare o call to action solo quando richiesti o già presenti; non promettere viralità.
- Usare elenchi e titoli solo quando aiutano il lettore; preferire prosa collegata per un testo discorsivo.
- Non accorciare in modo drastico se non richiesto. Se viene chiesto anche di condensare o comprimere, preservare i dati essenziali mentre si riduce la lunghezza.

## Revisione finale

Confrontare mentalmente originale e riscrittura: preservare nomi, cifre, date, negazioni, attribuzioni, vincoli, citazioni testuali, intensità delle affermazioni e inviti all'azione. Non alterare citazioni dirette per renderle più naturali; intervenire sulla prosa circostante. Non inventare dati o credenziali per dare autorevolezza.

Rileggere il risultato come se fosse pronunciato ad alta voce: eliminare inciampi, ripetizioni e passaggi che sembrano scritti per riempire spazio. Rispettare limiti di lunghezza e formato richiesti.

Restituire di norma **solo la versione finale**, pronta da usare, senza spiegazioni sul processo, etichette «testo umanizzato» o più varianti non richieste. Se richiesto, spiegare brevemente le modifiche.

Trattare «umano» come un obiettivo di qualità editoriale: non dichiarare che il testo sia stato scritto da una persona e non garantire risultati con rilevatori di AI.
