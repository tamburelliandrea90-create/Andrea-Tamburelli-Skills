AGENCY AGENTS MASTER IT — MANUALE DI INSTALLAZIONE E UTILIZZO
Versione: 1.0 | 14 novembre 2026

1. ORIGINE E CONTENUTO
Fonte: archivio agency-agents-main.zip fornito dall'utente.
Repository originale: https://github.com/msitarzewski/agency-agents
Licenza originale: MIT, riprodotta nel pacchetto.
Il pacchetto comprende 268 profili agente Markdown originali, divisi per area:
- academic: 6 agenti
- design: 10 agenti
- engineering: 66 agenti
- finance: 5 agenti
- game-development: 6 agenti
- gis: 13 agenti
- healthcare: 3 agenti
- marketing: 37 agenti
- paid-media: 7 agenti
- product: 6 agenti
- project-management: 7 agenti
- research: 1 agenti
- sales: 9 agenti
- security: 12 agenti
- spatial-computing: 6 agenti
- specialized: 59 agenti
- support: 6 agenti
- testing: 9 agenti

2. COSA FA
Agency Agents Master IT è una skill di coordinamento che:
- interpreta un obiettivo e sceglie uno o più profili professionali pertinenti;
- consulta le istruzioni originali dell'agente selezionato;
- applica processi, deliverable e criteri di controllo al lavoro richiesto;
- produce analisi, piani, testi, specifiche, checklist e revisioni in italiano;
- può simulare un team con ruoli distinti nella stessa conversazione;
- evidenzia ipotesi, dati mancanti e limiti operativi.
Non è un sistema di subagenti autonomi; non effettua accessi a piattaforme esterne senza strumenti collegati e autorizzati.

3. STRUTTURA DEL FILE ZIP
agency-agents-master-it/SKILL.md: istruzioni principali della skill.
agency-agents-master-it/references/CATALOGO_AGENTI.csv: elenco dei profili e percorsi.
agency-agents-master-it/references/agents/: profili Markdown originali, ordinati per categoria.
agency-agents-master-it/LICENSE: licenza MIT originale.
agency-agents-master-it/README_ITALIANO.txt: guida sintetica.

4. INSTALLAZIONE IN CHATGPT — PERCORSO MANUALE
A) Scaricare ed estrarre lo ZIP sul proprio dispositivo.
B) Creare un progetto o un GPT personalizzato, se disponibile nel proprio piano/interfaccia.
C) Inserire il contenuto di SKILL.md nelle istruzioni del progetto/GPT, adattandolo ai limiti di lunghezza.
D) Caricare CATALOGO_AGENTI.csv e i profili Markdown delle categorie necessarie tra i file di conoscenza, rispettando i limiti della piattaforma. Non è garantito che si possano caricare tutti i profili insieme.
E) Avviare una chat con un comando di prova e verificare che venga nominato un profilo presente nel catalogo.
NOTA: il caricamento dello ZIP in una chat NON installa automaticamente una skill nell'account. Non posso confermare l'installazione nel tuo account.

5. UTILIZZO COME SKILL IN AMBIENTI COMPATIBILI
Per ambienti che supportano cartelle SKILL.md, estrarre la directory agency-agents-master-it nella posizione prevista dalla documentazione del prodotto e riavviare/rileggere le skill secondo le istruzioni di quell'ambiente. Non tutti gli ambienti ChatGPT o Codex adottano le stesse convenzioni.
Il progetto originale fornisce inoltre uno script dedicato per Codex: ./scripts/install.sh --tool codex, da eseguire nel repository originale su un computer dopo averne verificato lo script. Il presente ZIP non esegue quello script.

6. COME SI USA
Esempio 1: "Usa Agency Agents Master IT: seleziona lo specialista migliore per il lancio di un libro KDP e crea una strategia di 30 giorni con KPI e budget."
Esempio 2: "Usa due agenti Agency Agents per sviluppare il posizionamento e il copy di una community AI."
Esempio 3: "Trova l'agente più adatto a verificare un progetto web e produci un audit con priorità e controlli."
Esempio 4: "Mostrami gli agenti della categoria marketing presenti nel catalogo e spiegami quando usarli."

7. PROCEDURA OPERATIVA
1) Descrivere obiettivo e materiale disponibile.
2) Chiedere la selezione motivata di un agente.
3) Fornire il profilo Markdown se non è stato caricato come conoscenza.
4) Richiedere un deliverable concreto (report, strategia, testo, tabella, checklist).
5) Chiedere una revisione finale con criteri di qualità e limiti.

8. DIFFERENZA FRA PROFILO, SKILL E AGENTE AUTONOMO
I file originali sono soprattutto profili agente e procedure testuali. La skill Master è una nuova struttura di selezione e coordinamento. L'autonomia operativa, la navigazione, l'esecuzione di codice e le automazioni richiedono strumenti separati.

9. SICUREZZA E LICENZA
La licenza MIT consente modifiche e ridistribuzione mantenendo il copyright e la licenza originale. Verificare licenze di eventuali risorse esterne prima dell'uso commerciale. Non eseguire codice non esaminato, non inserire chiavi API nei prompt e non trattare i profili come fonte di fatti verificati.

10. RISOLUZIONE PROBLEMI
Se la skill non viene riconosciuta: controllare il nome SKILL.md, la cartella e il supporto dell'ambiente.
Se l'agente non viene trovato: verificare il CSV e allegare il relativo file Markdown.
Se la risposta è generica: specificare obiettivo, destinatari, vincoli, formato e criteri di successo.
Se il caricamento supera i limiti: caricare solo una categoria o pochi agenti per volta.

11. VERIFICA DEL PACCHETTO
Il file ZIP è stato costruito dai profili presenti nell'archivio caricato, senza eseguire script originali. Contiene i testi originali e la licenza. Non risulta installato nell'account ChatGPT dell'utente.
